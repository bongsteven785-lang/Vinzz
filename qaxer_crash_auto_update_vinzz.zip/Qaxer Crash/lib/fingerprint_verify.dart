import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

// ═══════════════════════════════════════════════════════════════════
// PALETTE — DEEP NAVY + NEON
// ═══════════════════════════════════════════════════════════════════
class _FP {
  static const bg         = Color(0xFF03060E);
  static const surface    = Color(0xFF080D18);
  static const card       = Color(0xFF0E1524);
  static const cardLit    = Color(0xFF162035);

  static const neon       = Color(0xFF9B6DFF);   // cyan neon
  static const violet     = Color(0xFF9B6DFF);   // purple
  static const pink       = Color(0xFF8B5CF6);
  static const success    = Color(0xFFB79CFF);
  static const warn       = Color(0xFF9B6DFF);
  static const danger     = Color(0xFFFF4D6D);

  static const text       = Color(0xFFF5F8FF);
  static const textSub    = Color(0xFF8899B8);
  static const textDim    = Color(0xFF4A5878);

  static const border     = Color(0xFF1A2540);
  static const borderLit  = Color(0xFF2A3D68);

  static const LinearGradient scanGrad = LinearGradient(
    colors: [Colors.transparent, Color(0xFF9B6DFF), Colors.transparent],
    stops: [0.0, 0.5, 1.0],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient barGrad = LinearGradient(
    colors: [Color(0xFF9B6DFF), Color(0xFF9B6DFF), Color(0xFF8B5CF6)],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );

  static const LinearGradient titleGrad = LinearGradient(
    colors: [Color(0xFF9B6DFF), Color(0xFF9B6DFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static List<BoxShadow> glow(Color c, {double blur = 24, double spread = 0}) => [
    BoxShadow(color: c.withOpacity(0.5), blurRadius: blur, spreadRadius: spread),
    BoxShadow(color: c.withOpacity(0.2), blurRadius: blur * 1.8, spreadRadius: spread + 2),
  ];
}

// ═══════════════════════════════════════════════════════════════════
// FINGERPRINT VERIFY PAGE — REDESIGN TOTAL
// ═══════════════════════════════════════════════════════════════════
class FingerprintVerifyPage extends StatefulWidget {
  final VoidCallback onVerified;
  final VoidCallback? onCancel;
  final Duration duration;
  final String title;
  final String subtitle;

  const FingerprintVerifyPage({
    super.key,
    required this.onVerified,
    this.onCancel,
    this.duration = const Duration(milliseconds: 1800),
    this.title = 'SECURE ACCESS',
    this.subtitle = 'Verifikasi identitas Anda',
  });

  @override
  State<FingerprintVerifyPage> createState() => _FingerprintVerifyPageState();
}

class _FingerprintVerifyPageState extends State<FingerprintVerifyPage>
    with TickerProviderStateMixin {
  // ── State
  double _progress = 0.0;
  bool _pressing = false;
  bool _verified = false;
  bool _error = false;
  Timer? _timer;
  DateTime? _pressStartTime;
  int _lastPercent = 0;

  // ── Controllers
  late VideoPlayerController _videoCtrl;
  bool _videoReady = false;

  late AnimationController _scanCtrl;    // scan line sweep
  late AnimationController _breathCtrl;  // breathing glow
  late AnimationController _shakeCtrl;   // error shake
  late AnimationController _successCtrl; // success burst
  late AnimationController _particleCtrl; // floating particles

  late Animation<double> _shakeAnim;
  late Animation<double> _successAnim;

  @override
  void initState() {
    super.initState();

    // Video
    _videoCtrl = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _videoReady = true);
        _videoCtrl.setLooping(true);
        _videoCtrl.setVolume(0.0);
        _videoCtrl.play();
      }).catchError((e) => debugPrint('Video error: $e'));

    // Animations
    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    )..repeat();

    _breathCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _shakeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _shakeAnim = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.elasticIn));

    _successCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _successAnim = CurvedAnimation(parent: _successCtrl, curve: Curves.easeOutBack);

    _particleCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _videoCtrl.dispose();
    _scanCtrl.dispose();
    _breathCtrl.dispose();
    _shakeCtrl.dispose();
    _successCtrl.dispose();
    _particleCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════
  // PRESS LOGIC (UTUH)
  // ═══════════════════════════════════════════════════════════════
  void _startPress() {
    if (_verified || _pressing) return;
    HapticFeedback.mediumImpact();
    _pressStartTime = DateTime.now();

    setState(() {
      _pressing = true;
      _progress = 0.0;
      _lastPercent = 0;
      _error = false;
    });

    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted || !_pressing || _verified) { t.cancel(); return; }

      final elapsed = DateTime.now().difference(_pressStartTime!);
      final totalMs = widget.duration.inMilliseconds;
      final newProgress = (elapsed.inMilliseconds / totalMs).clamp(0.0, 1.0);

      final currentPercent = (newProgress * 100).toInt();
      if (currentPercent ~/ 10 > _lastPercent ~/ 10) {
        HapticFeedback.selectionClick();
      }
      _lastPercent = currentPercent;

      setState(() => _progress = newProgress);

      if (newProgress >= 1.0) {
        t.cancel();
        _onComplete();
      }
    });
  }

  void _endPress() {
    if (_verified) return;
    _timer?.cancel();
    _pressStartTime = null;
    if (_progress >= 1.0) return;

    if (_progress > 0.0 && _progress < 1.0) {
      HapticFeedback.lightImpact();
      _animateReset();
    }

    if (mounted) setState(() => _pressing = false);
  }

  void _animateReset() {
    final start = _progress;
    const resetMs = 250;
    final startTime = DateTime.now();

    Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted) { t.cancel(); return; }
      final elapsed = DateTime.now().difference(startTime).inMilliseconds;
      final factor = (1.0 - (elapsed / resetMs)).clamp(0.0, 1.0);
      setState(() => _progress = start * factor);
      if (elapsed >= resetMs) {
        t.cancel();
        if (mounted) setState(() => _progress = 0.0);
      }
    });
  }

  void _onComplete() {
    if (_verified) return;
    _verified = true;
    _pressing = false;
    HapticFeedback.heavyImpact();

    setState(() => _progress = 1.0);
    _successCtrl.forward();

    Future.delayed(const Duration(milliseconds: 700), () {
      if (mounted) widget.onVerified();
    });
  }

  void _cancel() {
    _timer?.cancel();
    if (widget.onCancel != null) {
      widget.onCancel!();
    } else {
      Navigator.pop(context);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _cancel();
      },
      child: Scaffold(
        backgroundColor: _FP.bg,
        body: Stack(
          children: [
            // ── Background base
            Positioned.fill(
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF03060E), Color(0xFF080D18), Color(0xFF03060E)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            ),

            // ── Floating particles
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _particleCtrl,
                builder: (_, __) => CustomPaint(
                  painter: _ParticleBgPainter(_particleCtrl.value),
                ),
              ),
            ),

            // ── Main layout
            SafeArea(
              child: Column(
                children: [
                  // ── HEADER
                  _buildHeader(),

                  // ── VIDEO PANEL (rounded top)
                  Expanded(
                    flex: 5,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: _buildVideoPanel(),
                    ),
                  ),

                  // ── CONTROL PANEL
                  Expanded(
                    flex: 6,
                    child: _buildControlPanel(),
                  ),

                  // ── FOOTER
                  _buildFooter(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Row(
        children: [
          // Back btn
          _GlassBtn(
            icon: Icons.arrow_back_ios_new_rounded,
            onTap: _cancel,
          ),

          const Spacer(),

          // Security badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: _FP.card.withOpacity(0.85),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _FP.success.withOpacity(0.5), width: 1.2),
              boxShadow: _FP.glow(_FP.success, blur: 14, spread: 0),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 6, height: 6,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _FP.success,
                    boxShadow: [
                      BoxShadow(color: _FP.success, blurRadius: 8, spreadRadius: 1),
                    ],
                  ),
                ),
                const SizedBox(width: 7),
                const Text('ENCRYPTED',
                  style: TextStyle(
                    color: _FP.success,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // VIDEO PANEL — split layout
  // ═══════════════════════════════════════════════════════════════
  Widget _buildVideoPanel() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: Container(
        decoration: BoxDecoration(
          color: _FP.card,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: _FP.borderLit.withOpacity(0.5), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: _FP.neon.withOpacity(0.3),
              blurRadius: 40, spreadRadius: -8, offset: const Offset(0, 12),
            ),
            BoxShadow(
              color: _FP.violet.withOpacity(0.15),
              blurRadius: 60, spreadRadius: -12,
            ),
          ],
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Video
            if (_videoReady)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoCtrl.value.size.width,
                  height: _videoCtrl.value.size.height,
                  child: Opacity(
                    opacity: 0.75,
                    child: VideoPlayer(_videoCtrl),
                  ),
                ),
              )
            else
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF0E1524), Color(0xFF162035)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),

            // Glass tint
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      _FP.bg.withOpacity(0.3),
                      _FP.bg.withOpacity(0.65),
                    ],
                  ),
                ),
              ),
            ),

            // Scan line animation
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _scanCtrl,
                builder: (_, __) => IgnorePointer(
                  child: Align(
                    alignment: Alignment(0, -1.2 + _scanCtrl.value * 2.4),
                    child: Container(
                      height: 2,
                      decoration: const BoxDecoration(gradient: _FP.scanGrad),
                    ),
                  ),
                ),
              ),
            ),

            // Grid overlay
            Positioned.fill(
              child: IgnorePointer(
                child: CustomPaint(painter: _GridPainter()),
              ),
            ),

            // Corner brackets
            ..._buildCorners(),

            // Top-left badge
            Positioned(
              top: 14, left: 14,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: _FP.bg.withOpacity(0.75),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _FP.neon.withOpacity(0.4), width: 1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.videocam_rounded, color: _FP.neon, size: 11),
                    const SizedBox(width: 5),
                    const Text('LIVE FEED',
                      style: TextStyle(color: _FP.neon, fontSize: 8.5,
                        fontWeight: FontWeight.w900, letterSpacing: 1.2),
                    ),
                  ],
                ),
              ),
            ),

            // Top-right signal
            Positioned(
              top: 14, right: 14,
              child: AnimatedBuilder(
                animation: _breathCtrl,
                builder: (_, __) => Row(
                  children: List.generate(4, (i) {
                    final active = _breathCtrl.value > (i / 4);
                    return Container(
                      margin: const EdgeInsets.only(left: 3),
                      width: 3,
                      height: 4.0 + i * 3,
                      decoration: BoxDecoration(
                        color: active ? _FP.neon : _FP.textDim,
                        borderRadius: BorderRadius.circular(2),
                        boxShadow: active
                            ? [BoxShadow(color: _FP.neon.withOpacity(0.6), blurRadius: 6)]
                            : null,
                      ),
                    );
                  }),
                ),
              ),
            ),

            // Bottom overlay — status
            Positioned(
              bottom: 14, left: 14, right: 14,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: _FP.bg.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _FP.borderLit.withOpacity(0.5), width: 1),
                ),
                child: Row(
                  children: [
                    Icon(
                      _verified ? Icons.verified_user_rounded : Icons.shield_outlined,
                      color: _verified ? _FP.success : _FP.neon,
                      size: 14,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _verified
                            ? 'IDENTITAS TERVERIFIKASI'
                            : 'MENUNGGU VERIFIKASI',
                        style: TextStyle(
                          color: _verified ? _FP.success : _FP.textSub,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ),
                    Text(
                      _verified ? '✓' : '●',
                      style: TextStyle(
                        color: _verified ? _FP.success : _FP.warn,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildCorners() {
    return [
      Positioned(
        top: 0, left: 0,
        child: _CornerBracket(
          color: _FP.neon,
          topLeft: true,
        ),
      ),
      Positioned(
        top: 0, right: 0,
        child: _CornerBracket(
          color: _FP.neon,
          topRight: true,
        ),
      ),
      Positioned(
        bottom: 0, left: 0,
        child: _CornerBracket(
          color: _FP.neon,
          bottomLeft: true,
        ),
      ),
      Positioned(
        bottom: 0, right: 0,
        child: _CornerBracket(
          color: _FP.neon,
          bottomRight: true,
        ),
      ),
    ];
  }

  // ═══════════════════════════════════════════════════════════════
  // CONTROL PANEL — fingerprint + progress bar
  // ═══════════════════════════════════════════════════════════════
  Widget _buildControlPanel() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // ── TITLE
          ShaderMask(
            shaderCallback: (b) => _FP.titleGrad.createShader(b),
            child: Text(
              widget.title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                letterSpacing: 2.5,
                shadows: [
                  Shadow(color: Color(0xFF9B6DFF), blurRadius: 20),
                ],
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            widget.subtitle,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: _FP.textSub,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.3,
            ),
          ),

          const SizedBox(height: 32),

          // ── FINGERPRINT TOUCH AREA
          Listener(
            behavior: HitTestBehavior.opaque,
            onPointerDown: (_) => _startPress(),
            onPointerUp: (_) => _endPress(),
            onPointerCancel: (_) => _endPress(),
            child: AnimatedBuilder(
              animation: Listenable.merge([_breathCtrl, _successCtrl]),
              builder: (_, __) => Transform.scale(
                scale: _verified ? (1.0 + _successAnim.value * 0.08) : 1.0,
                child: _buildFingerprintTouch(),
              ),
            ),
          ),

          const SizedBox(height: 28),

          // ── PROGRESS BAR (linear, baru!)
          _buildProgressBar(),

          const SizedBox(height: 16),

          // ── STATUS TEXT
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: Text(
              key: ValueKey('$_pressing-$_progress-$_verified'),
              _verified
                  ? '✓ VERIFIKASI BERHASIL'
                  : _pressing && _progress < 1.0
                      ? 'TAHAN TERUS... ${(_progress * 100).toInt()}%'
                      : _progress > 0
                          ? 'JANGAN DILEPAS!'
                          : 'TEKAN & TAHAN',
              style: TextStyle(
                color: _verified
                    ? _FP.success
                    : _pressing
                        ? _FP.neon
                        : _FP.textDim,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFingerprintTouch() {
    return AnimatedBuilder(
      animation: Listenable.merge([_breathCtrl, _scanCtrl]),
      builder: (_, __) {
        final breath = _breathCtrl.value;
        final active = _pressing || _verified;

        return SizedBox(
          width: 160, height: 160,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Outer glow breathing
              Container(
                width: 160, height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      (active ? _FP.neon : _FP.neon.withOpacity(0.3))
                          .withOpacity(0.15 + breath * 0.15 + _progress * 0.2),
                      Colors.transparent,
                    ],
                    stops: const [0.4, 1.0],
                  ),
                  boxShadow: active
                      ? _FP.glow(_FP.neon, blur: 30 + _progress * 30, spread: 2)
                      : [],
                ),
              ),

              // Rotating ring 1
              AnimatedBuilder(
                animation: _scanCtrl,
                builder: (_, __) => Transform.rotate(
                  angle: _scanCtrl.value * 2 * math.pi,
                  child: Container(
                    width: 140, height: 140,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: (active ? _FP.neon : _FP.borderLit).withOpacity(0.5),
                        width: 1.5,
                      ),
                    ),
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Transform.translate(
                        offset: const Offset(0, -3),
                        child: Container(
                          width: 6, height: 6,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _FP.neon,
                            boxShadow: [
                              BoxShadow(color: _FP.neon, blurRadius: 10, spreadRadius: 1),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // Rotating ring 2 (counter)
              AnimatedBuilder(
                animation: _scanCtrl,
                builder: (_, __) => Transform.rotate(
                  angle: -_scanCtrl.value * 2 * math.pi * 0.7,
                  child: Container(
                    width: 118, height: 118,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: (active ? _FP.violet : _FP.border).withOpacity(0.4),
                        width: 1,
                      ),
                    ),
                  ),
                ),
              ),

              // Progress arc
              SizedBox(
                width: 132, height: 132,
                child: CustomPaint(
                  painter: _ProgressArcPainter(progress: _progress),
                ),
              ),

              // Core circle
              Container(
                width: 96, height: 96,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: active
                        ? [
                            _FP.neon.withOpacity(0.2),
                            _FP.card,
                          ]
                        : [
                            _FP.card,
                            _FP.surface,
                          ],
                    stops: const [0.0, 1.0],
                  ),
                  border: Border.all(
                    color: active
                        ? _FP.neon.withOpacity(0.7)
                        : _FP.borderLit.withOpacity(0.5),
                    width: 2,
                  ),
                  boxShadow: active
                      ? _FP.glow(_FP.neon, blur: 20, spread: 2)
                      : [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.4),
                            blurRadius: 20, offset: const Offset(0, 8),
                          ),
                        ],
                ),
                child: Center(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: Icon(
                      key: ValueKey(_verified),
                      _verified
                          ? Icons.check_rounded
                          : Icons.fingerprint_rounded,
                      size: 44,
                      color: _verified ? _FP.success : _FP.neon,
                      shadows: [
                        Shadow(
                          color: (_verified ? _FP.success : _FP.neon)
                              .withOpacity(0.7),
                          blurRadius: 20,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildProgressBar() {
    return Container(
      height: 8,
      decoration: BoxDecoration(
        color: _FP.card,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: _FP.borderLit.withOpacity(0.5), width: 1),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: Stack(
          children: [
            // Base
            Container(color: _FP.surface),
            // Fill
            AnimatedContainer(
              duration: const Duration(milliseconds: 100),
              width: double.infinity,
              alignment: Alignment.centerLeft,
              child: FractionallySizedBox(
                widthFactor: _progress.clamp(0.0, 1.0),
                child: Container(
                  decoration: const BoxDecoration(gradient: _FP.barGrad),
                ),
              ),
            ),
            // Shimmer
            if (_progress > 0 && _progress < 1.0)
              AnimatedBuilder(
                animation: _scanCtrl,
                builder: (_, __) => FractionallySizedBox(
                  widthFactor: _progress.clamp(0.0, 1.0),
                  child: Align(
                    alignment: Alignment(-1 + _scanCtrl.value * 2, 0),
                    child: Container(
                      width: 30,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            Colors.white.withOpacity(0.4),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // FOOTER
  // ═══════════════════════════════════════════════════════════════
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
      child: Row(
        children: [
          // Cancel button
          Expanded(
            child: GestureDetector(
              onTap: _cancel,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: _FP.card,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _FP.borderLit.withOpacity(0.5), width: 1.2),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.close_rounded, color: _FP.textSub, size: 16),
                    const SizedBox(width: 8),
                    Text('BATAL',
                      style: TextStyle(
                        color: _FP.textSub,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          // Security info
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                _FP.neon.withOpacity(0.15),
                _FP.violet.withOpacity(0.1),
              ]),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _FP.neon.withOpacity(0.5), width: 1.2),
              boxShadow: _FP.glow(_FP.neon, blur: 12, spread: 0),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.lock_rounded, color: _FP.neon, size: 14),
                const SizedBox(width: 6),
                Text('AES-256',
                  style: TextStyle(
                    color: _FP.neon,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET: GLASS BUTTON
// ═══════════════════════════════════════════════════════════════════
class _GlassBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _GlassBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
          color: _FP.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _FP.borderLit.withOpacity(0.5), width: 1.2),
          boxShadow: _FP.glow(_FP.neon, blur: 10, spread: 0),
        ),
        child: Icon(icon, color: _FP.neon, size: 18),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET: CORNER BRACKET
// ═══════════════════════════════════════════════════════════════════
class _CornerBracket extends StatelessWidget {
  final Color color;
  final bool topLeft, topRight, bottomLeft, bottomRight;
  const _CornerBracket({
    required this.color,
    this.topLeft = false,
    this.topRight = false,
    this.bottomLeft = false,
    this.bottomRight = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 22, height: 22,
      child: CustomPaint(
        painter: _CornerPainter(
          color: color,
          topLeft: topLeft,
          topRight: topRight,
          bottomLeft: bottomLeft,
          bottomRight: bottomRight,
        ),
      ),
    );
  }
}

class _CornerPainter extends CustomPainter {
  final Color color;
  final bool topLeft, topRight, bottomLeft, bottomRight;
  _CornerPainter({
    required this.color,
    required this.topLeft,
    required this.topRight,
    required this.bottomLeft,
    required this.bottomRight,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    const len = 14.0;

    if (topLeft) {
      canvas.drawLine(const Offset(0, len), const Offset(0, 0), paint);
      canvas.drawLine(const Offset(0, 0), const Offset(len, 0), paint);
    }
    if (topRight) {
      canvas.drawLine(Offset(size.width - len, 0), Offset(size.width, 0), paint);
      canvas.drawLine(Offset(size.width, 0), Offset(size.width, len), paint);
    }
    if (bottomLeft) {
      canvas.drawLine(Offset(0, size.height - len), Offset(0, size.height), paint);
      canvas.drawLine(Offset(0, size.height), Offset(len, size.height), paint);
    }
    if (bottomRight) {
      canvas.drawLine(Offset(size.width - len, size.height), Offset(size.width, size.height), paint);
      canvas.drawLine(Offset(size.width, size.height - len), Offset(size.width, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _CornerPainter old) => false;
}

// ═══════════════════════════════════════════════════════════════════
// PAINTER: PROGRESS ARC (thin, di belakang fingerprint)
// ═══════════════════════════════════════════════════════════════════
class _ProgressArcPainter extends CustomPainter {
  final double progress;
  _ProgressArcPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 6;

    // Track
    canvas.drawCircle(
      center, radius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = _FP.border.withOpacity(0.5),
    );

    if (progress > 0) {
      // Progress arc
      final rect = Rect.fromCircle(center: center, radius: radius);
      canvas.drawArc(
        rect,
        -math.pi / 2,
        progress * 2 * math.pi,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3.5
          ..strokeCap = StrokeCap.round
          ..shader = const SweepGradient(
            colors: [Color(0xFF9B6DFF), Color(0xFF9B6DFF), Color(0xFF8B5CF6)],
          ).createShader(rect)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2),
      );

      // End dot
      final endAngle = -math.pi / 2 + progress * 2 * math.pi;
      final dotX = center.dx + radius * math.cos(endAngle);
      final dotY = center.dy + radius * math.sin(endAngle);

      canvas.drawCircle(
        Offset(dotX, dotY), 5,
        Paint()
          ..color = _FP.neon
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(Offset(dotX, dotY), 3, Paint()..color = Colors.white);
    }
  }

  @override
  bool shouldRepaint(_ProgressArcPainter old) => old.progress != progress;
}

// ═══════════════════════════════════════════════════════════════════
// PAINTER: GRID
// ═══════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _FP.neon.withOpacity(0.06)
      ..strokeWidth = 0.5;
    const step = 32.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }

  @override
  bool shouldRepaint(CustomPainter old) => false;
}

// ═══════════════════════════════════════════════════════════════════
// PAINTER: BACKGROUND PARTICLES
// ═══════════════════════════════════════════════════════════════════
class _ParticleBgPainter extends CustomPainter {
  final double t;
  _ParticleBgPainter(this.t);

  static final _rand = math.Random(42);
  static final _particles = List.generate(30, (i) => _P(
    x: _rand.nextDouble(),
    y: _rand.nextDouble(),
    size: 0.6 + _rand.nextDouble() * 1.8,
    speed: 0.02 + _rand.nextDouble() * 0.08,
    phase: _rand.nextDouble(),
    opacity: 0.1 + _rand.nextDouble() * 0.3,
  ));

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in _particles) {
      final px = p.x * size.width;
      final rawY = (p.y + t * p.speed) % 1.0;
      final py = rawY * size.height;
      final osc = math.sin((t * 2 + p.phase) * math.pi * 2);
      final opacity = p.opacity * (0.4 + osc * 0.6);

      canvas.drawCircle(
        Offset(px, py), p.size,
        Paint()..color = _FP.neon.withOpacity(opacity * 0.6),
      );
    }
  }

  @override
  bool shouldRepaint(_ParticleBgPainter old) => old.t != t;
}

class _P {
  final double x, y, size, speed, phase, opacity;
  const _P({
    required this.x, required this.y, required this.size,
    required this.speed, required this.phase, required this.opacity,
  });
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET: FINGERPRINT VERIFY WIDGET (untuk dialog)
// ═══════════════════════════════════════════════════════════════════
class FingerprintVerifyWidget extends StatefulWidget {
  final VoidCallback onVerified;
  final double size;
  final Duration duration;

  const FingerprintVerifyWidget({
    super.key,
    required this.onVerified,
    this.size = 220,
    this.duration = const Duration(milliseconds: 1800),
  });

  @override
  State<FingerprintVerifyWidget> createState() => _FingerprintVerifyWidgetState();
}

class _FingerprintVerifyWidgetState extends State<FingerprintVerifyWidget>
    with TickerProviderStateMixin {
  double _progress = 0.0;
  bool _pressing = false;
  bool _verified = false;
  Timer? _timer;
  DateTime? _pressStartTime;
  int _lastPercent = 0;

  late AnimationController _scanCtrl;
  late AnimationController _breathCtrl;

  @override
  void initState() {
    super.initState();
    _scanCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2500))..repeat();
    _breathCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _scanCtrl.dispose();
    _breathCtrl.dispose();
    super.dispose();
  }

  void _startPress() {
    if (_verified || _pressing) return;
    HapticFeedback.mediumImpact();
    _pressStartTime = DateTime.now();
    setState(() { _pressing = true; _progress = 0.0; _lastPercent = 0; });

    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted || !_pressing || _verified) { t.cancel(); return; }
      final elapsed = DateTime.now().difference(_pressStartTime!);
      final totalMs = widget.duration.inMilliseconds;
      final newProgress = (elapsed.inMilliseconds / totalMs).clamp(0.0, 1.0);

      final cp = (newProgress * 100).toInt();
      if (cp ~/ 10 > _lastPercent ~/ 10) HapticFeedback.selectionClick();
      _lastPercent = cp;
      setState(() => _progress = newProgress);

      if (newProgress >= 1.0) { t.cancel(); _onComplete(); }
    });
  }

  void _endPress() {
    if (_verified) return;
    _timer?.cancel();
    _pressStartTime = null;
    if (_progress >= 1.0) return;

    if (_progress > 0.0) {
      HapticFeedback.lightImpact();
      final start = _progress;
      const resetMs = 200;
      final st = DateTime.now();
      Timer.periodic(const Duration(milliseconds: 16), (t) {
        if (!mounted) { t.cancel(); return; }
        final e = DateTime.now().difference(st).inMilliseconds;
        final f = (1.0 - (e / resetMs)).clamp(0.0, 1.0);
        setState(() => _progress = start * f);
        if (e >= resetMs) {
          t.cancel();
          if (mounted) setState(() => _progress = 0.0);
        }
      });
    }
    if (mounted) setState(() => _pressing = false);
  }

  void _onComplete() {
    if (_verified) return;
    _verified = true;
    _pressing = false;
    HapticFeedback.heavyImpact();
    setState(() => _progress = 1.0);
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) widget.onVerified();
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.size;

    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (_) => _startPress(),
      onPointerUp: (_) => _endPress(),
      onPointerCancel: (_) => _endPress(),
      child: AnimatedBuilder(
        animation: Listenable.merge([_scanCtrl, _breathCtrl]),
        builder: (_, __) {
          final active = _pressing || _verified;

          return SizedBox(
            width: size, height: size,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Outer glow
                Container(
                  width: size, height: size,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        (active ? _FP.neon : _FP.neon.withOpacity(0.3))
                            .withOpacity(0.12 + _breathCtrl.value * 0.15 + _progress * 0.2),
                        Colors.transparent,
                      ],
                      stops: const [0.4, 1.0],
                    ),
                    boxShadow: active
                        ? _FP.glow(_FP.neon, blur: 30 + _progress * 30, spread: 2)
                        : [],
                  ),
                ),
                // Rotating ring
                Transform.rotate(
                  angle: _scanCtrl.value * 2 * math.pi,
                  child: Container(
                    width: size * 0.85, height: size * 0.85,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: (active ? _FP.neon : _FP.borderLit).withOpacity(0.5),
                        width: 1.5,
                      ),
                    ),
                  ),
                ),
                // Progress arc
                SizedBox(
                  width: size * 0.8, height: size * 0.8,
                  child: CustomPaint(painter: _ProgressArcPainter(progress: _progress)),
                ),
                // Core
                Container(
                  width: size * 0.58, height: size * 0.58,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: active
                          ? [_FP.neon.withOpacity(0.2), _FP.card]
                          : [_FP.card, _FP.surface],
                    ),
                    border: Border.all(
                      color: active
                          ? _FP.neon.withOpacity(0.7)
                          : _FP.borderLit.withOpacity(0.5),
                      width: 2,
                    ),
                    boxShadow: active ? _FP.glow(_FP.neon, blur: 20, spread: 2) : [],
                  ),
                  child: Center(
                    child: Icon(
                      _verified ? Icons.check_rounded : Icons.fingerprint_rounded,
                      size: size * 0.24,
                      color: _verified ? _FP.success : _FP.neon,
                    ),
                  ),
                ),
                // Percent
                Positioned(
                  bottom: size * 0.08,
                  child: Text(
                    '${(_progress * 100).toInt()}%',
                    style: TextStyle(
                      color: _verified ? _FP.success : _FP.neon,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
