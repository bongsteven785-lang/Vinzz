import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'Qaxer/.dart';

/// Global color palettes for QAXER SIGNATURE.
/// The selected palette is persisted and applied to the Material theme so
/// standard components across every route stay visually consistent.
class QaxerPalette {
  final String id;
  final String name;
  final String description;
  final Color primary;
  final Color accent;
  final Color background;
  final Color surface;
  final Color card;
  final Color border;
  final Color text;

  const QaxerPalette({
    required this.id,
    required this.name,
    required this.description,
    required this.primary,
    required this.accent,
    required this.background,
    required this.surface,
    required this.card,
    required this.border,
    required this.text,
  });
}

class QaxerThemeManager {
  QaxerThemeManager._();

  static const List<QaxerPalette> palettes = [
    QaxerPalette(
      id: 'aurora', name: 'Bumble Purple', description: 'Purple + white with red effects',
      primary: Color(0xFF8B5CF6), accent: Color(0xFFB79CFF),
      background: Color(0xFF090612), surface: Color(0xFF130D22),
      card: Color(0xFF1B1230), border: Color(0xFF49316F), text: Color(0xFFFFFFFF),
    ),
    QaxerPalette(
      id: 'crimson', name: 'Crimson Elite', description: 'Merah + silver',
      primary: Color(0xFFEF4444), accent: Color(0xFFF8FAFC),
      background: Color(0xFF10090D), surface: Color(0xFF211118),
      card: Color(0xFF2B1720), border: Color(0xFF6D3444), text: Color(0xFFFFF7F8),
    ),
    QaxerPalette(
      id: 'ocean', name: 'Ocean Pulse', description: 'Biru + aqua',
      primary: Color(0xFF3B82F6), accent: Color(0xFF2DD4BF),
      background: Color(0xFF06101A), surface: Color(0xFF0B1B2B),
      card: Color(0xFF10263A), border: Color(0xFF24506B), text: Color(0xFFF1F8FF),
    ),
    QaxerPalette(
      id: 'emerald', name: 'Emerald Luxe', description: 'Hijau + mint',
      primary: Color(0xFF10B981), accent: Color(0xFF6EE7B7),
      background: Color(0xFF06130F), surface: Color(0xFF0B2119),
      card: Color(0xFF103026), border: Color(0xFF28634D), text: Color(0xFFF0FFF7),
    ),
    QaxerPalette(
      id: 'sunset', name: 'Sunset Gold', description: 'Amber + coral',
      primary: Color(0xFFF59E0B), accent: Color(0xFFFB7185),
      background: Color(0xFF140D08), surface: Color(0xFF25180F),
      card: Color(0xFF332116), border: Color(0xFF73502D), text: Color(0xFFFFFAF2),
    ),
    QaxerPalette(
      id: 'ice', name: 'Ice Platinum', description: 'Silver + electric blue',
      primary: Color(0xFF94A3B8), accent: Color(0xFF60A5FA),
      background: Color(0xFF080D15), surface: Color(0xFF121C2A),
      card: Color(0xFF1A293A), border: Color(0xFF3D5872), text: Color(0xFFF5F9FF),
    ),
    QaxerPalette(
      id: 'royal', name: 'Royal Amethyst', description: 'Ungu kerajaan',
      primary: Color(0xFFA855F7), accent: Color(0xFFC4B5FD),
      background: Color(0xFF10091D), surface: Color(0xFF201236),
      card: Color(0xFF2B1947), border: Color(0xFF654A91), text: Color(0xFFFBF7FF),
    ),
    QaxerPalette(
      id: 'matrix', name: 'Matrix Green', description: 'Hijau neon',
      primary: Color(0xFF39FF14), accent: Color(0xFF00FFA3),
      background: Color(0xFF050D08), surface: Color(0xFF0B1C11),
      card: Color(0xFF10281A), border: Color(0xFF24683C), text: Color(0xFFF0FFF2),
    ),
    QaxerPalette(
      id: 'cyberpink', name: 'Cyber Pink', description: 'Pink neon + ungu',
      primary: Color(0xFFFF4FD8), accent: Color(0xFFA78BFA),
      background: Color(0xFF150817), surface: Color(0xFF260F2C),
      card: Color(0xFF35143C), border: Color(0xFF853B83), text: Color(0xFFFFF4FD),
    ),
    QaxerPalette(
      id: 'tangerine', name: 'Tangerine Pop', description: 'Oranye + peach',
      primary: Color(0xFFF97316), accent: Color(0xFFFDBA74),
      background: Color(0xFF160B05), surface: Color(0xFF291509),
      card: Color(0xFF3A1E0D), border: Color(0xFF8C4B20), text: Color(0xFFFFF7ED),
    ),
    QaxerPalette(
      id: 'sapphire', name: 'Sapphire Night', description: 'Biru safir',
      primary: Color(0xFF2563EB), accent: Color(0xFF93C5FD),
      background: Color(0xFF050B1C), surface: Color(0xFF0B1630),
      card: Color(0xFF122244), border: Color(0xFF294D86), text: Color(0xFFF3F7FF),
    ),
    QaxerPalette(
      id: 'ruby', name: 'Ruby Noir', description: 'Merah ruby',
      primary: Color(0xFFE11D48), accent: Color(0xFFFDA4AF),
      background: Color(0xFF16070D), surface: Color(0xFF270D18),
      card: Color(0xFF381321), border: Color(0xFF85314A), text: Color(0xFFFFF1F4),
    ),
    QaxerPalette(
      id: 'lavender', name: 'Lavender Mist', description: 'Lavender lembut',
      primary: Color(0xFFA78BFA), accent: Color(0xFFE9D5FF),
      background: Color(0xFF100E1B), surface: Color(0xFF1D1930),
      card: Color(0xFF292340), border: Color(0xFF5C527D), text: Color(0xFFFAF7FF),
    ),
    QaxerPalette(
      id: 'mint', name: 'Mint Condition', description: 'Mint + teal',
      primary: Color(0xFF2DD4BF), accent: Color(0xFF99F6E4),
      background: Color(0xFF041310), surface: Color(0xFF08231E),
      card: Color(0xFF0D3029), border: Color(0xFF24685B), text: Color(0xFFEEFFFC),
    ),
    QaxerPalette(
      id: 'copper', name: 'Copper Forge', description: 'Tembaga + bronze',
      primary: Color(0xFFC08457), accent: Color(0xFFF6C89F),
      background: Color(0xFF120D0A), surface: Color(0xFF241913),
      card: Color(0xFF332319), border: Color(0xFF76513B), text: Color(0xFFFFF7F0),
    ),
    QaxerPalette(
      id: 'mono', name: 'Monochrome Pro', description: 'Hitam putih minimal',
      primary: Color(0xFFE5E7EB), accent: Color(0xFF9CA3AF),
      background: Color(0xFF090A0C), surface: Color(0xFF17181B),
      card: Color(0xFF222429), border: Color(0xFF4B4F57), text: Color(0xFFFFFFFF),
    ),
    QaxerPalette(
      id: 'gold', name: 'Golden Empire', description: 'Emas mewah',
      primary: Color(0xFFEAB308), accent: Color(0xFFFDE68A),
      background: Color(0xFF120F05), surface: Color(0xFF211B08),
      card: Color(0xFF30280E), border: Color(0xFF776324), text: Color(0xFFFFFCED),
    ),
    QaxerPalette(
      id: 'arctic', name: 'Arctic Blue', description: 'Biru es terang',
      primary: Color(0xFF38BDF8), accent: Color(0xFFBAE6FD),
      background: Color(0xFF06111A), surface: Color(0xFF0B202D),
      card: Color(0xFF123044), border: Color(0xFF2B607B), text: Color(0xFFF2FBFF),
    ),
    QaxerPalette(
      id: 'volcano', name: 'Volcano', description: 'Merah lava + orange',
      primary: Color(0xFFF43F5E), accent: Color(0xFFFB923C),
      background: Color(0xFF160806), surface: Color(0xFF28100C),
      card: Color(0xFF3A1710), border: Color(0xFF87382A), text: Color(0xFFFFF5F1),
    ),
    QaxerPalette(
      id: 'plasma', name: 'Plasma Wave', description: 'Magenta + cyan',
      primary: Color(0xFFD946EF), accent: Color(0xFF22D3EE),
      background: Color(0xFF120719), surface: Color(0xFF210D2D),
      card: Color(0xFF30123F), border: Color(0xFF753B89), text: Color(0xFFFFF5FF),
    ),
    QaxerPalette(
      id: 'forest', name: 'Forest Shadow', description: 'Hijau hutan',
      primary: Color(0xFF15803D), accent: Color(0xFF86EFAC),
      background: Color(0xFF061009), surface: Color(0xFF0D2013),
      card: Color(0xFF14301D), border: Color(0xFF2B6840), text: Color(0xFFF2FFF4),
    ),
    QaxerPalette(
      id: 'lagoon', name: 'Blue Lagoon', description: 'Teal + ocean',
      primary: Color(0xFF0891B2), accent: Color(0xFF67E8F9),
      background: Color(0xFF041116), surface: Color(0xFF09242B),
      card: Color(0xFF10323B), border: Color(0xFF246773), text: Color(0xFFF0FDFF),
    ),
    QaxerPalette(
      id: 'orchid', name: 'Orchid Bloom', description: 'Orchid + pink',
      primary: Color(0xFFC026D3), accent: Color(0xFFF0ABFC),
      background: Color(0xFF160818), surface: Color(0xFF290F2D),
      card: Color(0xFF3A1640), border: Color(0xFF813D88), text: Color(0xFFFFF4FF),
    ),
    QaxerPalette(
      id: 'sandstone', name: 'Sandstone', description: 'Pasir + cream',
      primary: Color(0xFFD97706), accent: Color(0xFFFDE68A),
      background: Color(0xFF171109), surface: Color(0xFF282014),
      card: Color(0xFF39301E), border: Color(0xFF79653B), text: Color(0xFFFFFAF0),
    ),
    QaxerPalette(
      id: 'storm', name: 'Storm Grey', description: 'Slate + electric blue',
      primary: Color(0xFF64748B), accent: Color(0xFF38BDF8),
      background: Color(0xFF080C12), surface: Color(0xFF151C26),
      card: Color(0xFF202B38), border: Color(0xFF485B70), text: Color(0xFFF5F9FF),
    ),
    QaxerPalette(
      id: 'berry', name: 'Berry Smoothie', description: 'Berry + rose',
      primary: Color(0xFFBE185D), accent: Color(0xFFFDA4AF),
      background: Color(0xFF170711), surface: Color(0xFF2B0F1E),
      card: Color(0xFF3C172A), border: Color(0xFF8B355C), text: Color(0xFFFFF3F8),
    ),
    QaxerPalette(
      id: 'lime', name: 'Lime Circuit', description: 'Lime + emerald',
      primary: Color(0xFF84CC16), accent: Color(0xFFBEF264),
      background: Color(0xFF0C1105), surface: Color(0xFF192009),
      card: Color(0xFF252F0D), border: Color(0xFF526D25), text: Color(0xFFFAFFE9),
    ),
    QaxerPalette(
      id: 'indigo', name: 'Indigo Dream', description: 'Indigo + periwinkle',
      primary: Color(0xFF6366F1), accent: Color(0xFFA5B4FC),
      background: Color(0xFF090A1D), surface: Color(0xFF141631),
      card: Color(0xFF1D2044), border: Color(0xFF414782), text: Color(0xFFF5F5FF),
    ),
    QaxerPalette(
      id: 'coral', name: 'Coral Reef', description: 'Coral + turquoise',
      primary: Color(0xFFFB7185), accent: Color(0xFF5EEAD4),
      background: Color(0xFF16090D), surface: Color(0xFF281319),
      card: Color(0xFF3A1B25), border: Color(0xFF864453), text: Color(0xFFFFF5F6),
    ),
    QaxerPalette(
      id: 'neon', name: 'Neon Spectrum', description: 'Cyan + violet',
      primary: Color(0xFF06B6D4), accent: Color(0xFFA78BFA),
      background: Color(0xFF050B17), surface: Color(0xFF0B1728),
      card: Color(0xFF122238), border: Color(0xFF2B5277), text: Color(0xFFF2FBFF),
    ),
  ];

  static final ValueNotifier<QaxerPalette> current =
      ValueNotifier<QaxerPalette>(palettes.first);
  static Timer? _remoteSyncTimer;
  static bool _remoteSyncInProgress = false;

  /// Loads the user's last local selection first, then asynchronously checks
  /// the API-managed global palette so startup does not wait on the network.
  static Future<void> loadSaved() async {
    final prefs = await SharedPreferences.getInstance();
    final savedId = prefs.getString('qaxer_global_palette') ?? 'aurora';
    current.value = palettes.firstWhere(
      (palette) => palette.id == savedId,
      orElse: () => palettes.first,
    );
    unawaited(syncRemote());
    startRemoteSync();
  }

  /// Reads the global palette selected by the developer in the Telegram bot.
  /// If the API is unavailable, the app keeps its last locally saved palette.
  static Future<void> syncRemote() async {
    if (_remoteSyncInProgress) return;
    _remoteSyncInProgress = true;
    try {
      final response = await http
          .get(Uri.parse('${Api.api}/api/theme-config'))
          .timeout(const Duration(seconds: 5));
      if (response.statusCode != 200) return;
      final decoded = jsonDecode(response.body);
      if (decoded is! Map<String, dynamic> || decoded['success'] != true) {
        return;
      }
      if (decoded['enabled'] != true) return;
      final remoteId = decoded['themeId']?.toString();
      QaxerPalette? palette;
      for (final item in palettes) {
        if (item.id == remoteId) {
          palette = item;
          break;
        }
      }
      final selectedPalette = palette;
      if (selectedPalette == null || current.value.id == selectedPalette.id) return;
      current.value = selectedPalette;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('qaxer_global_palette', selectedPalette.id);
    } catch (_) {
      // Keep the last saved palette when offline or when the API is unavailable.
    } finally {
      _remoteSyncInProgress = false;
    }
  }

  /// Rechecks periodically so changes made through the bot reach open apps too.
  static void startRemoteSync() {
    _remoteSyncTimer ??= Timer.periodic(
      const Duration(seconds: 60),
      (_) => unawaited(syncRemote()),
    );
  }

  static Future<void> select(
    QaxerPalette palette, {
    String? sessionKey,
    bool syncToServer = false,
  }) async {
    current.value = palette;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('qaxer_global_palette', palette.id);

    // A developer selection is also published to the API, making it the
    // global default for other installations. Non-developer choices stay local.
    if (syncToServer && sessionKey != null && sessionKey.trim().isNotEmpty) {
      try {
        await http
            .post(
              Uri.parse('${Api.api}/api/theme-config').replace(
                queryParameters: {'key': sessionKey},
              ),
              headers: const {'Content-Type': 'application/json'},
              body: jsonEncode({'themeId': palette.id, 'enabled': true}),
            )
            .timeout(const Duration(seconds: 5));
      } catch (_) {
        // Local selection remains available if the server cannot be reached.
      }
    }
  }

  static ThemeData apply(ThemeData base, QaxerPalette palette) {
    final scheme = base.colorScheme.copyWith(
      primary: palette.primary,
      secondary: palette.accent,
      surface: palette.surface,
      onSurface: palette.text,
      outline: palette.border,
      outlineVariant: palette.border.withOpacity(0.72),
      primaryContainer: palette.primary.withOpacity(0.22),
      onPrimaryContainer: palette.text,
      secondaryContainer: palette.accent.withOpacity(0.18),
      onSecondaryContainer: palette.text,
      surfaceContainerHighest: palette.card,
      shadow: palette.primary.withOpacity(0.28),
    );

    final radius = BorderRadius.circular(15);
    final inputBorder = OutlineInputBorder(
      borderRadius: radius,
      borderSide: BorderSide(color: palette.border, width: 1.1),
    );

    return base.copyWith(
      primaryColor: palette.primary,
      scaffoldBackgroundColor: Colors.transparent,
      canvasColor: palette.surface,
      cardColor: palette.card,
      colorScheme: scheme,
      appBarTheme: base.appBarTheme.copyWith(
        backgroundColor: palette.background.withOpacity(0.96),
        foregroundColor: palette.text,
        iconTheme: IconThemeData(color: palette.accent),
        actionsIconTheme: IconThemeData(color: palette.text.withOpacity(0.85)),
      ),
      cardTheme: base.cardTheme.copyWith(
        color: palette.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: palette.border.withOpacity(0.8)),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: base.elevatedButtonTheme.style?.copyWith(
          backgroundColor: WidgetStatePropertyAll(palette.primary),
          foregroundColor: WidgetStatePropertyAll(palette.text),
          overlayColor: WidgetStatePropertyAll(palette.accent.withOpacity(0.16)),
          shape: WidgetStatePropertyAll(RoundedRectangleBorder(borderRadius: radius)),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: base.outlinedButtonTheme.style?.copyWith(
          foregroundColor: WidgetStatePropertyAll(palette.accent),
          side: WidgetStatePropertyAll(BorderSide(color: palette.border, width: 1.2)),
          overlayColor: WidgetStatePropertyAll(palette.primary.withOpacity(0.12)),
          shape: WidgetStatePropertyAll(RoundedRectangleBorder(borderRadius: radius)),
        ),
      ),
      inputDecorationTheme: base.inputDecorationTheme.copyWith(
        filled: true,
        fillColor: palette.surface,
        border: inputBorder,
        enabledBorder: inputBorder,
        focusedBorder: inputBorder.copyWith(
          borderSide: BorderSide(color: palette.accent, width: 1.8),
        ),
        labelStyle: TextStyle(color: palette.text.withOpacity(0.78)),
        prefixIconColor: palette.accent,
        suffixIconColor: palette.accent,
      ),
      iconTheme: IconThemeData(color: palette.accent, size: base.iconTheme.size),
      dividerTheme: DividerThemeData(color: palette.border.withOpacity(0.8)),
      bottomNavigationBarTheme: base.bottomNavigationBarTheme.copyWith(
        backgroundColor: palette.surface,
        selectedItemColor: palette.accent,
        unselectedItemColor: palette.text.withOpacity(0.48),
      ),
      navigationBarTheme: base.navigationBarTheme.copyWith(
        backgroundColor: palette.surface,
        indicatorColor: palette.primary.withOpacity(0.25),
      ),
      drawerTheme: base.drawerTheme.copyWith(backgroundColor: palette.surface),
      dialogTheme: base.dialogTheme.copyWith(
        backgroundColor: palette.card,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
          side: BorderSide(color: palette.border, width: 1.1),
        ),
      ),
      bottomSheetTheme: base.bottomSheetTheme.copyWith(
        backgroundColor: palette.surface,
        modalBackgroundColor: palette.surface,
      ),
      snackBarTheme: base.snackBarTheme.copyWith(
        backgroundColor: palette.card,
        actionTextColor: palette.accent,
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: palette.accent,
        linearTrackColor: palette.border.withOpacity(0.55),
        circularTrackColor: palette.border.withOpacity(0.55),
      ),
      floatingActionButtonTheme: base.floatingActionButtonTheme.copyWith(
        backgroundColor: palette.primary,
        foregroundColor: palette.text,
      ),
      textSelectionTheme: TextSelectionThemeData(
        cursorColor: palette.accent,
        selectionColor: palette.primary.withOpacity(0.35),
        selectionHandleColor: palette.accent,
      ),
      splashColor: palette.accent.withOpacity(0.12),
      highlightColor: palette.primary.withOpacity(0.08),
      focusColor: palette.primary.withOpacity(0.1),
    );
  }
}
