import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'cek_ban_wa.dart';

// ======================== PALETTE — AURORA ========================
class _C {
  static const bg         = Color(0xFF060918);
  static const bgAlt      = Color(0xFF0A0D24);
  static const surface    = Color(0xFF0F1530);
  static const card       = Color(0xFF141C3D);
  static const cardAlt    = Color(0xFF1A2450);
  static const border     = Color(0xFF2A3566);
  static const borderLit  = Color(0xFF4A5DA8);

  static const violet     = Color(0xFF8B5CF6);
  static const cyan       = Color(0xFF9B6DFF);
  static const pink       = Color(0xFF8B5CF6);
  static const gold       = Color(0xFF9B6DFF);
  static const mint       = Color(0xFFB79CFF);

  static const text       = Color(0xFFF8FAFF);
  static const textSub    = Color(0xFFB4C0E0);
  static const textDim    = Color(0xFF6B78A0);

  static const auroraGrad = LinearGradient(
    colors: [
      Color(0xFF6D28D9), Color(0xFF8B5CF6),
      Color(0xFF9B6DFF), Color(0xFFB79CFF),
      Color(0xFF9B6DFF), Color(0xFF8B5CF6),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const neonGrad = LinearGradient(
    colors: [Color(0xFF9B6DFF), Color(0xFF8B5CF6), Color(0xFF8B5CF6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const surfaceGrad = LinearGradient(
    colors: [Color(0xFF141C3D), Color(0xFF0F1530)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const bgGrad = LinearGradient(
    colors: [Color(0xFF060918), Color(0xFF0F1530), Color(0xFF0A0D24)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}

// ======================== CUSTOM CLIPPER ========================
class _ClippedCornerClipper extends CustomClipper<Path> {
  final double cut;
  const _ClippedCornerClipper({this.cut = 14});

  @override
  Path getClip(Size size) {
    final p = Path();
    final c = cut;
    p.moveTo(c, 0);
    p.lineTo(size.width - c, 0);
    p.lineTo(size.width, c);
    p.lineTo(size.width, size.height - c);
    p.lineTo(size.width - c, size.height);
    p.lineTo(c, size.height);
    p.lineTo(0, size.height - c);
    p.lineTo(0, c);
    p.close();
    return p;
  }

  @override
  bool shouldReclip(_ClippedCornerClipper old) => cut != old.cut;
}

// ======================== CUSTOM PAINTERS ========================
class _AuroraGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _C.borderLit.withOpacity(0.1)
      ..strokeWidth = 0.6;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }

  @override
  bool shouldRepaint(CustomPainter old) => false;
}

class _ScanLinePainter extends CustomPainter {
  final double position;
  _ScanLinePainter({required this.position});

  @override
  void paint(Canvas canvas, Size size) {
    final y = position * (size.height + 80) - 40;
    final rect = Rect.fromLTWH(0, y - 35, size.width, 70);
    final shader = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        Colors.transparent,
        _C.cyan.withOpacity(0.06),
        _C.violet.withOpacity(0.12),
        _C.pink.withOpacity(0.08),
        Colors.transparent,
      ],
      stops: const [0.0, 0.3, 0.5, 0.7, 1.0],
    ).createShader(rect);
    canvas.drawRect(rect, Paint()..shader = shader);
  }

  @override
  bool shouldRepaint(_ScanLinePainter old) => position != old.position;
}

class _RadarPainter extends CustomPainter {
  final double angle;
  _RadarPainter({required this.angle});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2 - 2;

    // Rings
    for (int i = 1; i <= 3; i++) {
      final circlePaint = Paint()
        ..color = _C.cyan.withOpacity(0.25 - i * 0.05)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8;
      canvas.drawCircle(center, r * i / 3, circlePaint);
    }

    // Cross
    final linePaint = Paint()
      ..color = _C.violet.withOpacity(0.2)
      ..strokeWidth = 0.5;
    canvas.drawLine(
        Offset(center.dx - r, center.dy), Offset(center.dx + r, center.dy), linePaint);
    canvas.drawLine(
        Offset(center.dx, center.dy - r), Offset(center.dx, center.dy + r), linePaint);

    // Sweep
    final sweepShader = SweepGradient(
      startAngle: angle - 0.6,
      endAngle: angle,
      colors: [_C.violet.withOpacity(0.0), _C.cyan.withOpacity(0.5)],
    ).createShader(Rect.fromCircle(center: center, radius: r));
    canvas.drawCircle(center, r, Paint()..shader = sweepShader);

    // Line
    final endPt = Offset(
        center.dx + math.cos(angle) * r, center.dy + math.sin(angle) * r);
    canvas.drawLine(center, endPt,
        Paint()
          ..shader = _C.neonGrad.createShader(Rect.fromCircle(center: center, radius: r))
          ..strokeWidth = 1.5);

    // Dot
    canvas.drawCircle(center, 2.5, Paint()..color = _C.cyan);
    canvas.drawCircle(center, 5, Paint()..color = _C.violet.withOpacity(0.3));
  }

  @override
  bool shouldRepaint(_RadarPainter old) => angle != old.angle;
}

class _DiagonalStripePainter extends CustomPainter {
  final Color color;
  _DiagonalStripePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    for (double i = -size.height; i < size.width + size.height; i += 18) {
      canvas.drawLine(Offset(i, 0), Offset(i + size.height, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(_DiagonalStripePainter old) => color != old.color;
}

// ======================== TOOL ITEM MODEL ========================
class _ToolItem {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool locked;
  final Color? accentColor;

  const _ToolItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.locked = false,
    this.accentColor,
  });
}

// ======================== MAIN WIDGET ========================
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _scanCtrl;
  late AnimationController _radarCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _tickerCtrl;
  late AnimationController _bgCtrl;
  late AnimationController _shineCtrl;

  @override
  void initState() {
    super.initState();
    _scanCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 4))
      ..repeat();
    _radarCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))
      ..repeat();
    _pulseCtrl =
        AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))
          ..repeat(reverse: true);
    _tickerCtrl =
        AnimationController(vsync: this, duration: const Duration(seconds: 25))
          ..repeat();
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 20))
      ..repeat();
    _shineCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))
      ..repeat();
  }

  @override
  void dispose() {
    _scanCtrl.dispose();
    _radarCtrl.dispose();
    _pulseCtrl.dispose();
    _tickerCtrl.dispose();
    _bgCtrl.dispose();
    _shineCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // Aurora background
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _bgCtrl,
              builder: (_, __) => CustomPaint(
                painter: _AuroraBgPainter(_bgCtrl.value),
              ),
            ),
          ),
          // Grid subtle
          Positioned.fill(child: CustomPaint(painter: _AuroraGridPainter())),
          // Scan line
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _scanCtrl,
              builder: (context, _) => CustomPaint(
                painter: _ScanLinePainter(position: _scanCtrl.value),
              ),
            ),
          ),
          // Content
          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: _buildDataTicker()),
                SliverToBoxAdapter(child: _buildHeader()),
                SliverToBoxAdapter(child: _buildStatusBar()),
                const SliverToBoxAdapter(child: SizedBox(height: 16)),
                SliverToBoxAdapter(child: _animateEntry(0, _buildHeroCard())),
                const SliverToBoxAdapter(child: SizedBox(height: 12)),
                SliverToBoxAdapter(
                  child: _animateEntry(
                    1,
                    Row(
                      children: [
                        Expanded(child: _buildNetworkCard()),
                        const SizedBox(width: 12),
                        Expanded(child: _buildOsintCard()),
                      ],
                    ),
                  ),
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 12)),
                SliverToBoxAdapter(
                  child: _animateEntry(
                    2,
                    Row(
                      children: [
                        Expanded(flex: 3, child: _buildDownloaderCard()),
                        const SizedBox(width: 12),
                        Expanded(flex: 2, child: _buildUtilityCard()),
                      ],
                    ),
                  ),
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 12)),
                SliverToBoxAdapter(child: _animateEntry(3, _buildQuickAccess())),
                const SliverToBoxAdapter(child: SizedBox(height: 32)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==================== DATA TICKER ====================
  Widget _buildDataTicker() {
    final text =
        "SYS.ONLINE  //  TOOLS:7  //  NODE:ACTIVE  //  ENCRYPTED:AES-256  //  LATENCY:12ms  //  UPTIME:99.9%  //  ";
    final textStyle = TextStyle(
      color: _C.cyan.withOpacity(0.7),
      fontSize: 10,
      fontFamily: 'Orbitron',
      letterSpacing: 1.5,
      fontWeight: FontWeight.w700,
    );

    return SizedBox(
      height: 22,
      child: ClipRect(
        child: AnimatedBuilder(
          animation: _tickerCtrl,
          builder: (context, _) {
            return Transform.translate(
              offset: Offset(-_tickerCtrl.value * 600, 0),
              child: Row(
                children: [
                  Text(text, style: textStyle),
                  Text(text, style: textStyle),
                  Text(text, style: textStyle),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ==================== HEADER ====================
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Row(
        children: [
          // Radar dengan glow
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  _C.violet.withOpacity(0.15),
                  Colors.transparent,
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: _C.violet.withOpacity(0.3),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: AnimatedBuilder(
              animation: _radarCtrl,
              builder: (context, _) {
                return CustomPaint(
                  painter: _RadarPainter(angle: _radarCtrl.value * 2 * math.pi),
                );
              },
            ),
          ),
          const SizedBox(width: 16),
          // Title
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (bounds) => _C.auroraGrad.createShader(bounds),
                  child: const Text(
                    "TOOLS DASHBOARD",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      shadows: [
                        Shadow(color: Color(0xFF8B5CF6), blurRadius: 12),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  "Advanced Security & OSINT Suite",
                  style: TextStyle(
                    color: _C.textSub.withOpacity(0.8),
                    fontSize: 10,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
          // Online indicator
          Column(
            children: [
              AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (context, _) {
                  return Container(
                    width: 9,
                    height: 9,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _C.mint,
                      boxShadow: [
                        BoxShadow(
                          color: _C.mint.withOpacity(0.5 + _pulseCtrl.value * 0.5),
                          blurRadius: 10 + _pulseCtrl.value * 5,
                          spreadRadius: 1 + _pulseCtrl.value * 2,
                        ),
                      ],
                    ),
                  );
                },
              ),
              const SizedBox(height: 5),
              ShaderMask(
                shaderCallback: (b) => _C.neonGrad.createShader(b),
                child: const Text(
                  "ONLINE",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 8,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ==================== STATUS BAR ====================
  Widget _buildStatusBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
      child: Row(
        children: [
          _buildStatusChip(Icons.widgets, "7 TOOLS", _C.violet),
          const SizedBox(width: 8),
          _buildStatusChip(Icons.bolt, "PRIORITY", _C.pink),
          const SizedBox(width: 8),
          _buildStatusChip(Icons.shield, "SECURED", _C.mint),
        ],
      ),
    );
  }

  Widget _buildStatusChip(IconData icon, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            color.withOpacity(0.15),
            color.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.4), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.25),
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 12),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 9,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ==================== HERO CARD ====================
  Widget _buildHeroCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          // ═══ CEK BAN WA (PRIORITAS) ═══
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CekBanWaPage(sessionKey: widget.sessionKey),
                ),
              );
            },
            child: ClipPath(
              clipper: const _ClippedCornerClipper(cut: 18),
              child: Container(
                height: 130,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF141C3D),
                      Color(0xFF1A2450),
                      Color(0xFF141C3D),
                    ],
                  ),
                  border: Border.all(color: _C.violet.withOpacity(0.6), width: 1.8),
                  boxShadow: [
                    BoxShadow(
                      color: _C.violet.withOpacity(0.4),
                      blurRadius: 30,
                      spreadRadius: 2,
                      offset: const Offset(0, 10),
                    ),
                    BoxShadow(
                      color: _C.pink.withOpacity(0.15),
                      blurRadius: 40,
                      spreadRadius: -4,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    // Diagonal stripes
                    Positioned.fill(
                      child: CustomPaint(
                        painter: _DiagonalStripePainter(
                            color: _C.violet.withOpacity(0.06)),
                      ),
                    ),
                    // Shine sweep
                    Positioned.fill(
                      child: ClipPath(
                        clipper: const _ClippedCornerClipper(cut: 18),
                        child: AnimatedBuilder(
                          animation: _shineCtrl,
                          builder: (_, __) => Transform.translate(
                            offset: Offset(-300 + (_shineCtrl.value * 900), 0),
                            child: Container(
                              width: 100,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.transparent,
                                    Colors.white.withOpacity(0.15),
                                    Colors.transparent,
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    // Pulse border
                    AnimatedBuilder(
                      animation: _pulseCtrl,
                      builder: (context, _) {
                        return ClipPath(
                          clipper: const _ClippedCornerClipper(cut: 18),
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: _C.cyan.withOpacity(
                                    0.3 + _pulseCtrl.value * 0.4),
                                width: 1.5,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                    // Content
                    Padding(
                      padding: const EdgeInsets.all(18),
                      child: Row(
                        children: [
                          Container(
                            width: 62,
                            height: 62,
                            decoration: BoxDecoration(
                              gradient: _C.auroraGrad,
                              borderRadius: BorderRadius.circular(18),
                              boxShadow: [
                                BoxShadow(
                                  color: _C.violet.withOpacity(0.6),
                                  blurRadius: 20,
                                  spreadRadius: 2,
                                ),
                                BoxShadow(
                                  color: _C.pink.withOpacity(0.3),
                                  blurRadius: 30,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.verified_user_rounded,
                              color: Colors.white,
                              size: 30,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Row(
                                  children: [
                                    const Text(
                                      "CEK BAN WA",
                                      style: TextStyle(
                                        color: _C.text,
                                        fontSize: 17,
                                        fontFamily: 'Orbitron',
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 1.5,
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 3),
                                      decoration: BoxDecoration(
                                        gradient: _C.neonGrad,
                                        borderRadius: BorderRadius.circular(6),
                                        boxShadow: [
                                          BoxShadow(
                                            color: _C.cyan.withOpacity(0.5),
                                            blurRadius: 10,
                                          ),
                                        ],
                                      ),
                                      child: const Text(
                                        "REAL",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 9,
                                          fontFamily: 'Orbitron',
                                          fontWeight: FontWeight.w900,
                                          letterSpacing: 1,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  "Deteksi nomor WhatsApp aman / kena ban",
                                  style: TextStyle(
                                    color: _C.textSub.withOpacity(0.8),
                                    fontSize: 11,
                                    fontFamily: 'Orbitron',
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    Container(
                                      width: 7,
                                      height: 7,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: _C.mint,
                                        boxShadow: [
                                          BoxShadow(
                                            color: _C.mint.withOpacity(0.8),
                                            blurRadius: 8,
                                            spreadRadius: 1,
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    ShaderMask(
                                      shaderCallback: (b) =>
                                          _C.neonGrad.createShader(b),
                                      child: const Text(
                                        "CEK SEKARANG",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 9,
                                          fontFamily: 'Orbitron',
                                          fontWeight: FontWeight.w900,
                                          letterSpacing: 1.5,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Icon(Icons.chevron_right,
                              color: _C.cyan.withOpacity(0.5), size: 28),
                        ],
                      ),
                    ),
                    _buildCornerMarks(color: _C.violet, size: 18),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ═══ DDoS CARD ═══
          GestureDetector(
            onTap: () => _showDDoSTools(context),
            child: ClipPath(
              clipper: const _ClippedCornerClipper(cut: 18),
              child: Container(
                height: 110,
                decoration: BoxDecoration(
                  gradient: _C.surfaceGrad,
                  border: Border.all(color: _C.pink.withOpacity(0.5), width: 1.8),
                  boxShadow: [
                    BoxShadow(
                      color: _C.pink.withOpacity(0.3),
                      blurRadius: 24,
                      spreadRadius: 1,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  _C.pink.withOpacity(0.3),
                                  _C.gold.withOpacity(0.15),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                  color: _C.pink.withOpacity(0.6), width: 1.5),
                              boxShadow: [
                                BoxShadow(
                                  color: _C.pink.withOpacity(0.4),
                                  blurRadius: 16,
                                ),
                              ],
                            ),
                            child: const Icon(Icons.flash_on,
                                color: _C.pink, size: 26),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text(
                                  "DDoS TOOLS",
                                  style: TextStyle(
                                    color: _C.text,
                                    fontSize: 15,
                                    fontFamily: 'Orbitron',
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.2,
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  "Attack Panel & Server Management",
                                  style: TextStyle(
                                    color: _C.textSub.withOpacity(0.7),
                                    fontSize: 10,
                                    fontFamily: 'Orbitron',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Icon(Icons.chevron_right,
                              color: _C.pink.withOpacity(0.5), size: 26),
                        ],
                      ),
                    ),
                    _buildCornerMarks(color: _C.pink, size: 18),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== NETWORK CARD ====================
  Widget _buildNetworkCard() {
    final toolCount = (widget.userRole == "vip" || widget.userRole == "owner") ? 4 : 3;
    return _buildClippedCard(
      icon: Icons.wifi,
      title: "NETWORK",
      subtitle: "WiFi & Spam",
      toolCount: toolCount,
      color: _C.cyan,
      gradient: const LinearGradient(
        colors: [Color(0xFF9B6DFF), Color(0xFF8B5CF6)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      onTap: () => _showNetworkTools(context),
      cut: 14,
    );
  }

  // ==================== OSINT CARD ====================
  Widget _buildOsintCard() {
    return _buildClippedCard(
      icon: Icons.search,
      title: "OSINT",
      subtitle: "Investigation",
      toolCount: 4,
      color: _C.mint,
      gradient: const LinearGradient(
        colors: [Color(0xFFB79CFF), Color(0xFF9B6DFF)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      onTap: () => _showOSINTTools(context),
      cut: 14,
    );
  }

  // ==================== DOWNLOADER CARD ====================
  Widget _buildDownloaderCard() {
    return Padding(
      padding: const EdgeInsets.only(left: 20),
      child: GestureDetector(
        onTap: () => _showDownloaderTools(context),
        child: ClipPath(
          clipper: const _ClippedCornerClipper(cut: 14),
          child: Container(
            height: 120,
            decoration: BoxDecoration(
              gradient: _C.surfaceGrad,
              border: Border.all(color: _C.violet.withOpacity(0.5), width: 1.8),
              boxShadow: [
                BoxShadow(
                  color: _C.violet.withOpacity(0.3),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              _C.violet.withOpacity(0.3),
                              _C.pink.withOpacity(0.15),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: _C.violet.withOpacity(0.6), width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color: _C.violet.withOpacity(0.4),
                              blurRadius: 14,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.download,
                            color: _C.violet, size: 22),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text(
                              "DOWNLOADER",
                              style: TextStyle(
                                color: _C.text,
                                fontSize: 13,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.2,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              "Social Media",
                              style: TextStyle(
                                color: _C.textSub.withOpacity(0.7),
                                fontSize: 10,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                _buildPlatformBadge("TT", _C.pink),
                                const SizedBox(width: 6),
                                _buildPlatformBadge("IG", _C.gold),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Icon(Icons.chevron_right,
                          color: _C.violet.withOpacity(0.5), size: 24),
                    ],
                  ),
                ),
                _buildCornerMarks(color: _C.violet, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPlatformBadge(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.3), color.withOpacity(0.1)],
        ),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.6), width: 1),
        boxShadow: [
          BoxShadow(color: color.withOpacity(0.4), blurRadius: 8),
        ],
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 9,
          fontFamily: 'Orbitron',
          fontWeight: FontWeight.w900,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  // ==================== UTILITY CARD ====================
  Widget _buildUtilityCard() {
    return Padding(
      padding: const EdgeInsets.only(right: 20),
      child: GestureDetector(
        onTap: () => _showUtilityTools(context),
        child: ClipPath(
          clipper: const _ClippedCornerClipper(cut: 14),
          child: Container(
            height: 120,
            decoration: BoxDecoration(
              gradient: _C.surfaceGrad,
              border: Border.all(color: _C.gold.withOpacity(0.5), width: 1.8),
              boxShadow: [
                BoxShadow(
                  color: _C.gold.withOpacity(0.3),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              _C.gold.withOpacity(0.3),
                              _C.gold.withOpacity(0.1),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: _C.gold.withOpacity(0.6), width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color: _C.gold.withOpacity(0.4),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.build,
                            color: _C.gold, size: 20),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "UTILS",
                        style: TextStyle(
                          color: _C.text,
                          fontSize: 12,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        "3 Tools",
                        style: TextStyle(
                          color: _C.textSub.withOpacity(0.7),
                          fontSize: 9,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                ),
                _buildCornerMarks(color: _C.gold, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== QUICK ACCESS ====================
  Widget _buildQuickAccess() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 12),
            child: Row(
              children: [
                ShaderMask(
                  shaderCallback: (b) => _C.auroraGrad.createShader(b),
                  child: const Text(
                    "QUICK ACCESS",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 40,
                  height: 1.5,
                  decoration: BoxDecoration(
                    gradient: _C.auroraGrad,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ],
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: Row(
              children: [
                _buildQuickPill(Icons.verified_user, "Cek Ban", _C.mint, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CekBanWaPage(sessionKey: widget.sessionKey),
                    ),
                  );
                }),
                const SizedBox(width: 10),
                _buildQuickPill(Icons.flash_on, "DDoS", _C.pink,
                    () => _showDDoSTools(context)),
                const SizedBox(width: 10),
                _buildQuickPill(Icons.wifi, "Network", _C.cyan,
                    () => _showNetworkTools(context)),
                const SizedBox(width: 10),
                _buildQuickPill(Icons.search, "OSINT", _C.violet,
                    () => _showOSINTTools(context)),
                const SizedBox(width: 10),
                _buildQuickPill(Icons.download, "Download", _C.gold,
                    () => _showDownloaderTools(context)),
                const SizedBox(width: 10),
                _buildQuickPill(Icons.build, "Utils", _C.gold,
                    () => _showUtilityTools(context)),
                const SizedBox(width: 10),
                _buildQuickPill(Icons.qr_code, "QR Gen", _C.cyan, () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickPill(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              color.withOpacity(0.15),
              color.withOpacity(0.05),
            ],
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.5), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.3),
              blurRadius: 12,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 14),
            const SizedBox(width: 6),
            Text(
              label,
              style: const TextStyle(
                color: _C.text,
                fontSize: 10,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== GENERIC CLIPPED CARD ====================
  Widget _buildClippedCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required int toolCount,
    required Color color,
    required LinearGradient gradient,
    required VoidCallback onTap,
    required double cut,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: GestureDetector(
        onTap: onTap,
        child: ClipPath(
          clipper: _ClippedCornerClipper(cut: cut),
          child: Container(
            height: 120,
            decoration: BoxDecoration(
              gradient: _C.surfaceGrad,
              border: Border.all(color: color.withOpacity(0.5), width: 1.8),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.3),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              color.withOpacity(0.3),
                              color.withOpacity(0.1),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: color.withOpacity(0.6), width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color: color.withOpacity(0.4),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                        child: Icon(icon, color: color, size: 20),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        title,
                        style: const TextStyle(
                          color: _C.text,
                          fontSize: 13,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              subtitle,
                              style: TextStyle(
                                color: _C.textSub.withOpacity(0.7),
                                fontSize: 10,
                                fontFamily: 'Orbitron',
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          ShaderMask(
                            shaderCallback: (b) => gradient.createShader(b),
                            child: Text(
                              "$toolCount",
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Positioned(
                  right: 12,
                  top: 0,
                  bottom: 0,
                  child: Center(
                    child: Icon(Icons.chevron_right,
                        color: color.withOpacity(0.5), size: 22),
                  ),
                ),
                _buildCornerMarks(color: color, size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== CORNER MARKS ====================
  Widget _buildCornerMarks({required Color color, required double size}) {
    final markSize = size * 0.4;
    final linePaint = Paint()
      ..shader = LinearGradient(
        colors: [color, color.withOpacity(0.3)],
      ).createShader(Rect.fromLTWH(0, 0, size, size))
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    return CustomPaint(
      size: Size(double.infinity, double.infinity),
      painter: _CornerMarkPainter(markSize: markSize, linePaint: linePaint),
    );
  }

  // ==================== ENTRY ANIMATION ====================
  Widget _animateEntry(int index, Widget child) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 600 + index * 120),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 24 * (1 - value)),
            child: child,
          ),
        );
      },
      child: child,
    );
  }

  // ==================== CATEGORY SHEET ====================
  void _showCategorySheet(
    BuildContext context, {
    required String title,
    required IconData icon,
    required List<_ToolItem> tools,
  }) {
    final sheetHeight = tools.length <= 2
        ? 0.42
        : tools.length == 3
            ? 0.54
            : 0.62;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * sheetHeight,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF141C3D), Color(0xFF0F1530)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(28),
            topRight: Radius.circular(28),
          ),
          border: Border.all(color: _C.borderLit.withOpacity(0.5), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: _C.violet.withOpacity(0.3),
              blurRadius: 40,
              spreadRadius: 4,
              offset: const Offset(0, -10),
            ),
            BoxShadow(
              color: _C.pink.withOpacity(0.15),
              blurRadius: 60,
              spreadRadius: -4,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(28),
            topRight: Radius.circular(28),
          ),
          child: Column(
            children: [
              // Top drag handle
              Container(
                margin: const EdgeInsets.only(top: 10),
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  gradient: _C.neonGrad,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              // Header
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 14),
                child: Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        gradient: _C.auroraGrad,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: _C.violet.withOpacity(0.5),
                            blurRadius: 16,
                          ),
                        ],
                      ),
                      child: Icon(icon, color: Colors.white, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ShaderMask(
                        shaderCallback: (b) => _C.auroraGrad.createShader(b),
                        child: Text(
                          title.toUpperCase(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              _C.pink.withOpacity(0.2),
                              _C.pink.withOpacity(0.05),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: _C.pink.withOpacity(0.5), width: 1.2),
                        ),
                        child: const Icon(Icons.close, color: _C.pink, size: 16),
                      ),
                    ),
                  ],
                ),
              ),
              // Status line
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _C.mint.withOpacity(0.08),
                      Colors.transparent,
                    ],
                  ),
                  border: Border(
                    top: BorderSide(color: _C.borderLit.withOpacity(0.3), width: 0.8),
                    bottom: BorderSide(color: _C.borderLit.withOpacity(0.3), width: 0.8),
                  ),
                ),
                child: Row(
                  children: [
                    AnimatedBuilder(
                      animation: _pulseCtrl,
                      builder: (context, _) {
                        return Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _C.mint,
                            boxShadow: [
                              BoxShadow(
                                color: _C.mint
                                    .withOpacity(0.5 + _pulseCtrl.value * 0.5),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                    const SizedBox(width: 8),
                    Text(
                      "SECURE CONNECTION ESTABLISHED",
                      style: TextStyle(
                        color: _C.textSub.withOpacity(0.6),
                        fontSize: 8,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const Spacer(),
                    ShaderMask(
                      shaderCallback: (b) => _C.neonGrad.createShader(b),
                      child: Text(
                        "${tools.length} MODULES",
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 8,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Tools grid
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: GridView.count(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: tools.length <= 2 ? 2.4 : 1.55,
                    physics: const NeverScrollableScrollPhysics(),
                    children: tools.map((t) => _buildSheetButton(t)).toList(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSheetButton(_ToolItem item) {
    final color = item.accentColor ?? _C.violet;
    return GestureDetector(
      onTap: item.locked ? () => _showComingSoon(context) : item.onTap,
      child: ClipPath(
        clipper: const _ClippedCornerClipper(cut: 12),
        child: Container(
          decoration: BoxDecoration(
            gradient: item.locked
                ? LinearGradient(
                    colors: [
                      _C.card.withOpacity(0.5),
                      _C.surface.withOpacity(0.3),
                    ],
                  )
                : LinearGradient(
                    colors: [
                      color.withOpacity(0.12),
                      _C.card,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
            border: Border.all(
              color: item.locked
                  ? _C.borderLit.withOpacity(0.3)
                  : color.withOpacity(0.6),
              width: 1.5,
            ),
            boxShadow: item.locked
                ? null
                : [
                    BoxShadow(
                      color: color.withOpacity(0.3),
                      blurRadius: 16,
                      spreadRadius: 1,
                    ),
                  ],
          ),
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: item.locked
                            ? LinearGradient(
                                colors: [
                                  _C.borderLit.withOpacity(0.15),
                                  _C.borderLit.withOpacity(0.05),
                                ],
                              )
                            : LinearGradient(
                                colors: [
                                  color.withOpacity(0.3),
                                  color.withOpacity(0.1),
                                ],
                              ),
                        border: Border.all(
                          color: item.locked
                              ? _C.borderLit.withOpacity(0.3)
                              : color.withOpacity(0.6),
                          width: 1.5,
                        ),
                        boxShadow: item.locked
                            ? null
                            : [
                                BoxShadow(
                                  color: color.withOpacity(0.4),
                                  blurRadius: 12,
                                ),
                              ],
                      ),
                      child: Icon(
                        item.locked ? Icons.lock_outline : item.icon,
                        color: item.locked
                            ? _C.textDim
                            : color,
                        size: 18,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      item.label,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: item.locked ? _C.textDim : _C.text,
                        fontSize: 10,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.5,
                        height: 1.3,
                      ),
                    ),
                    if (item.locked) ...[
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              _C.gold.withOpacity(0.3),
                              _C.gold.withOpacity(0.1),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text(
                          "SOON",
                          style: TextStyle(
                            color: _C.gold,
                            fontSize: 7,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              if (!item.locked) _buildCornerMarks(color: color, size: 10),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== CATEGORY METHODS ====================
  void _showDDoSTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "DDoS Tools",
      icon: Icons.flash_on,
      tools: [
        _ToolItem(
          icon: Icons.flash_on,
          label: "Attack\nPanel",
          accentColor: _C.pink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AttackPanel(
                  sessionKey: widget.sessionKey,
                  listDoos: widget.listDoos,
                ),
              ),
            );
          },
        ),
        _ToolItem(
          icon: Icons.dns,
          label: "Manage\nServer",
          accentColor: _C.gold,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ManageServerPage(keyToken: widget.sessionKey),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showNetworkTools(BuildContext context) {
    final tools = <_ToolItem>[
      _ToolItem(
        icon: Icons.verified_user_rounded,
        label: "Cek Ban\nWhatsApp",
        accentColor: _C.mint,
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CekBanWaPage(sessionKey: widget.sessionKey),
            ),
          );
        },
      ),
      _ToolItem(
        icon: Icons.newspaper_outlined,
        label: "Spam\nNGL",
        accentColor: _C.pink,
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => const NglPage()));
        },
      ),
      _ToolItem(
        icon: Icons.wifi_off,
        label: "WiFi Killer\n(Internal)",
        accentColor: _C.cyan,
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => const WifiKillerPage()));
        },
      ),
      if (widget.userRole == "vip" || widget.userRole == "owner")
        _ToolItem(
          icon: Icons.router,
          label: "WiFi Killer\n(External)",
          accentColor: _C.violet,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => WifiInternalPage(sessionKey: widget.sessionKey),
              ),
            );
          },
        ),
    ];
    _showCategorySheet(
      context,
      title: "Network Tools",
      icon: Icons.wifi,
      tools: tools,
    );
  }

  void _showOSINTTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "OSINT Tools",
      icon: Icons.search,
      tools: [
        _ToolItem(
          icon: Icons.badge,
          label: "NIK\nDetail",
          accentColor: _C.violet,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const NikCheckerPage()));
          },
        ),
        _ToolItem(
          icon: Icons.domain,
          label: "Domain\nOSINT",
          accentColor: _C.cyan,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const DomainOsintPage()));
          },
        ),
        _ToolItem(
          icon: Icons.person_search,
          label: "Phone\nLookup",
          locked: true,
          onTap: () {},
        ),
        _ToolItem(
          icon: Icons.email,
          label: "Email\nOSINT",
          locked: true,
          onTap: () {},
        ),
      ],
    );
  }

  void _showDownloaderTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "Media Downloader",
      icon: Icons.download,
      tools: [
        _ToolItem(
          icon: Icons.video_library,
          label: "TikTok\nDownloader",
          accentColor: _C.pink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
          },
        ),
        _ToolItem(
          icon: Icons.camera_alt,
          label: "Instagram\nDownloader",
          accentColor: _C.gold,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
          },
        ),
      ],
    );
  }

  void _showUtilityTools(BuildContext context) {
    _showCategorySheet(
      context,
      title: "Utility Tools",
      icon: Icons.build,
      tools: [
        _ToolItem(
          icon: Icons.qr_code,
          label: "QR\nGenerator",
          accentColor: _C.cyan,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
          },
        ),
        _ToolItem(
          icon: Icons.security,
          label: "IP\nScanner",
          locked: true,
          onTap: () {},
        ),
        _ToolItem(
          icon: Icons.network_check,
          label: "Port\nScanner",
          locked: true,
          onTap: () {},
        ),
      ],
    );
  }

  // ==================== COMING SOON ====================
  void _showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_C.gold, Color(0xFFB79CFF)],
                ),
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(color: _C.gold.withOpacity(0.5), blurRadius: 10),
                ],
              ),
              child: const Icon(Icons.hourglass_top, color: Colors.white, size: 14),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Feature Coming Soon!',
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w800,
                  color: _C.text,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: _C.card,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: _C.gold.withOpacity(0.5), width: 1.2),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

// ======================== CORNER MARK PAINTER ========================
class _CornerMarkPainter extends CustomPainter {
  final double markSize;
  final Paint linePaint;

  _CornerMarkPainter({
    required this.markSize,
    required this.linePaint,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final s = markSize;
    final p = linePaint;

    // Kiri atas
    canvas.drawLine(const Offset(2, 2), Offset(2 + s, 2), p);
    canvas.drawLine(const Offset(2, 2), Offset(2, 2 + s), p);

    // Kanan atas
    canvas.drawLine(Offset(size.width - 2 - s, 2), Offset(size.width - 2, 2), p);
    canvas.drawLine(Offset(size.width - 2, 2), Offset(size.width - 2, 2 + s), p);

    // Kiri bawah
    canvas.drawLine(Offset(2, size.height - 2), Offset(2 + s, size.height - 2), p);
    canvas.drawLine(Offset(2, size.height - 2 - s), Offset(2, size.height - 2), p);

    // Kanan bawah
    canvas.drawLine(
        Offset(size.width - 2 - s, size.height - 2), Offset(size.width - 2, size.height - 2), p);
    canvas.drawLine(
        Offset(size.width - 2, size.height - 2 - s), Offset(size.width - 2, size.height - 2), p);
  }

  @override
  bool shouldRepaint(covariant _CornerMarkPainter oldDelegate) {
    return markSize != oldDelegate.markSize ||
        linePaint.color != oldDelegate.linePaint.color ||
        linePaint.strokeWidth != oldDelegate.linePaint.strokeWidth;
  }
}

// ======================== AURORA BG PAINTER ========================
class _AuroraBgPainter extends CustomPainter {
  final double t;
  _AuroraBgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    // Base gradient
    final bgPaint = Paint()
      ..shader = _C.bgGrad.createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    // Orb 1
    final orb1X = size.width * 0.15 + math.cos(t * 2 * math.pi) * 60;
    final orb1Y = size.height * 0.15 + math.sin(t * 2 * math.pi) * 50;
    final orb1 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.violet.withOpacity(0.35 + math.sin(t * 2 * math.pi) * 0.1),
          _C.pink.withOpacity(0.12),
          Colors.transparent,
        ],
        stops: const [0.0, 0.4, 0.8],
      ).createShader(Rect.fromCircle(center: Offset(orb1X, orb1Y), radius: 320));
    canvas.drawCircle(Offset(orb1X, orb1Y), 320, orb1);

    // Orb 2
    final orb2X = size.width * 0.85 + math.cos(t * 2 * math.pi + 1.5) * 60;
    final orb2Y = size.height * 0.4 + math.sin(t * 2 * math.pi + 1.5) * 70;
    final orb2 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.cyan.withOpacity(0.3 + math.sin(t * 2 * math.pi + 1) * 0.1),
          _C.violet.withOpacity(0.12),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: Offset(orb2X, orb2Y), radius: 280));
    canvas.drawCircle(Offset(orb2X, orb2Y), 280, orb2);

    // Orb 3
    final orb3X = size.width * 0.5 + math.cos(t * 2 * math.pi + 3) * 80;
    final orb3Y = size.height * 0.85 + math.sin(t * 2 * math.pi + 3) * 60;
    final orb3 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.gold.withOpacity(0.2 + math.sin(t * 2 * math.pi + 2) * 0.08),
          _C.mint.withOpacity(0.1),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: Offset(orb3X, orb3Y), radius: 260));
    canvas.drawCircle(Offset(orb3X, orb3Y), 260, orb3);

    // Particles
    for (int i = 0; i < 25; i++) {
      final angle = t * math.pi * 2 + (i * 0.25);
      final radius = size.width * (0.15 + (i % 5) * 0.14);
      final px = size.width / 2 + math.cos(angle) * radius;
      final py = size.height / 2 + math.sin(angle) * radius;

      final particleColor = i % 4 == 0
          ? _C.cyan
          : i % 4 == 1
              ? _C.pink
              : i % 4 == 2
                  ? _C.gold
                  : _C.violet;

      final dot = Paint()
        ..color = particleColor.withOpacity(0.3 + math.sin(t * 4 + i) * 0.15)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);

      canvas.drawCircle(Offset(px, py), 1.5 + math.sin(t * 6 + i) * 1, dot);
    }
  }

  @override
  bool shouldRepaint(_AuroraBgPainter old) => old.t != t;
}
