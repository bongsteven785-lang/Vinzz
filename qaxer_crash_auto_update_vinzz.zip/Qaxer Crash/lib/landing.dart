import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'fingerprint_verify.dart';

// ═══════════════════════════════════════════════════════════════════
// PALETTE — AURORA MODERN v2
// ═══════════════════════════════════════════════════════════════════
class _C {
  static const bg         = Color(0xFF04060F);
  static const bgAlt      = Color(0xFF080C1C);
  static const surface    = Color(0xFF0D1226);
  static const card       = Color(0xFF121932);
  static const cardLit    = Color(0xFF1A2447);

  static const neon       = Color(0xFF8B5CF6);
  static const violet     = Color(0xFF8B5CF6);
  static const pink       = Color(0xFF8B5CF6);
  static const gold       = Color(0xFF8B5CF6);
  static const mint       = Color(0xFFB79CFF);
  static const danger     = Color(0xFFFF4D6D);

  static const text       = Color(0xFFF5F8FF);
  static const textSub    = Color(0xFFC7B8F5);
  static const textDim    = Color(0xFF8D7BAF);

  static const border     = Color(0xFF49316F);
  static const borderLit  = Color(0xFF6D4C9E);

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF8B5CF6), Color(0xFF8B5CF6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient hotGrad = LinearGradient(
    colors: [Color(0xFF8B5CF6), Color(0xFF8B5CF6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient auroraGrad = LinearGradient(
    colors: [Color(0xFF6D28D9), Color(0xFF8B5CF6), Color(0xFFB79CFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient bgGrad = LinearGradient(
    colors: [Color(0xFF04060F), Color(0xFF080C1C), Color(0xFF04060F)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static List<BoxShadow> glow(Color c, {double blur = 24, double spread = 0}) => [
    BoxShadow(color: c.withOpacity(0.45), blurRadius: blur, spreadRadius: spread),
    BoxShadow(color: c.withOpacity(0.15), blurRadius: blur * 1.6, spreadRadius: spread + 2),
  ];
}

// ═══════════════════════════════════════════════════════════════════
// LANDING PAGE — REDESIGN TOTAL
// ═══════════════════════════════════════════════════════════════════
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  bool _fingerprintVerified = false;
  bool _showFingerprintGate = false;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _marqueeCtrl;
  late AnimationController _particleCtrl;
  late AnimationController _heroCtrl;
  late AnimationController _orbitCtrl;

  late Animation<double> _entranceFade;
  late Animation<Offset> _entranceSlide;

  final ScrollController _scrollCtrl = ScrollController();
  double _scrollOffset = 0;

  // ─── Data
  static const List<Map<String, dynamic>> _features = [
    {
      'icon': Icons.flash_on_rounded,
      'title': 'ULTRA FAST',
      'metric': '0.2ms',
      'desc': 'Lightning speed execution & low latency',
      'color': _C.neon,
    },
    {
      'icon': Icons.shield_rounded,
      'title': 'SECURE',
      'metric': 'AES-256',
      'desc': 'End-to-end encryption & anti-tamper',
      'color': _C.violet,
    },
    {
      'icon': Icons.track_changes_rounded,
      'title': 'POWERFUL',
      'metric': '50+',
      'desc': 'Advanced tools & remote features',
      'color': _C.pink,
    },
    {
      'icon': Icons.update_rounded,
      'title': 'UPDATED',
      'metric': 'v17',
      'desc': 'Weekly fresh updates & fixes',
      'color': _C.gold,
    },
  ];

  static const List<Map<String, dynamic>> _reviews = [
    {'name': '@user_kai', 'role': 'VIP', 'text': 'GG banget, cepat & stabil parah!', 'rating': 5, 'color': _C.neon},
    {'name': '@alpha_owner', 'role': 'OWNER', 'text': 'Support responsif, recommended.', 'rating': 5, 'color': _C.violet},
    {'name': '@partner_x', 'role': 'PARTNER', 'text': 'Fitur lengkap, worth every penny!', 'rating': 5, 'color': _C.gold},
    {'name': '@vip_king', 'role': 'VIP', 'text': 'Update konsisten, top markotop!', 'rating': 5, 'color': _C.pink},
  ];

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 30))..repeat();
    _particleCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 12))..repeat();
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000))..repeat(reverse: true);
    _marqueeCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 22))..repeat();
    _heroCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 10))..repeat();
    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 8))..repeat();

    _entranceCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1200));
    _entranceFade = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _entranceSlide = Tween<Offset>(
      begin: const Offset(0, 0.08), end: Offset.zero,
    ).animate(CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic));

    _entranceCtrl.forward();

    _scrollCtrl.addListener(() {
      setState(() => _scrollOffset = _scrollCtrl.offset);
    });

    // Show fingerprint gate after short delay
    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) setState(() => _showFingerprintGate = true);
    });
  }

  @override
  void dispose() {
    _scrollCtrl.dispose();
    _bgCtrl.dispose();
    _particleCtrl.dispose();
    _pulseCtrl.dispose();
    _marqueeCtrl.dispose();
    _heroCtrl.dispose();
    _orbitCtrl.dispose();
    _entranceCtrl.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // ── Aurora background
          Positioned.fill(
            child: AnimatedBuilder(
              animation: Listenable.merge([_bgCtrl, _particleCtrl]),
              builder: (_, __) => CustomPaint(
                painter: _AuroraBgPainter(_bgCtrl.value, _particleCtrl.value),
              ),
            ),
          ),

          // ── Content
          SafeArea(
            child: FadeTransition(
              opacity: _entranceFade,
              child: SlideTransition(
                position: _entranceSlide,
                child: _buildContent(),
              ),
            ),
          ),

          // ── Fingerprint gate overlay
          if (_showFingerprintGate && !_fingerprintVerified)
            _buildFingerprintOverlay(),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // FINGERPRINT OVERLAY — modal style
  // ═══════════════════════════════════════════════════════════════
  Widget _buildFingerprintOverlay() {
    return Positioned.fill(
      child: Container(
        color: _C.bg.withOpacity(0.85),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: FingerprintVerifyPage(
            title: 'SECURE ACCESS',
            subtitle: 'Verifikasi identitas Anda',
            onVerified: () {
              if (mounted) {
                setState(() {
                  _fingerprintVerified = true;
                  _showFingerprintGate = false;
                });
              }
            },
            onCancel: () {
              // Tetap blokir sampai verify
            },
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // CONTENT
  // ═══════════════════════════════════════════════════════════════
  Widget _buildContent() {
    return Column(
      children: [
        // Sticky mini header
        _buildStickyHeader(),

        // Scroll content
        Expanded(
          child: SingleChildScrollView(
            controller: _scrollCtrl,
            physics: const BouncingScrollPhysics(),
            child: Column(
              children: [
                const SizedBox(height: 12),
                _buildHeroCard(),
                const SizedBox(height: 20),
                _buildMarquee(),
                const SizedBox(height: 20),
                _buildBentoStats(),
                const SizedBox(height: 24),
                _buildSectionTitle('FEATURES', 'Powered by Mortix Engine'),
                const SizedBox(height: 14),
                _buildFeatureGrid(),
                const SizedBox(height: 28),
                _buildSectionTitle('REVIEWS', 'Real feedback dari user'),
                const SizedBox(height: 14),
                _buildReviewsGrid(),
                const SizedBox(height: 28),
                _buildSectionTitle('CHANGELOG', 'Latest v17.0'),
                const SizedBox(height: 14),
                _buildChangelogCard(),
                const SizedBox(height: 28),
                _buildCTASection(),
                const SizedBox(height: 28),
                _buildContactSection(),
                const SizedBox(height: 24),
                _buildFooter(),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // STICKY HEADER
  // ═══════════════════════════════════════════════════════════════
  Widget _buildStickyHeader() {
    final scrolled = _scrollOffset > 40;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color: scrolled ? _C.bg.withOpacity(0.85) : Colors.transparent,
        border: Border(
          bottom: BorderSide(
            color: scrolled ? _C.borderLit.withOpacity(0.3) : Colors.transparent,
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          // Brand
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              gradient: _C.primaryGrad,
              boxShadow: _C.glow(_C.neon, blur: 12, spread: 0),
            ),
            child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 16),
          ),
          const SizedBox(width: 10),
          ShaderMask(
            shaderCallback: (b) => _C.primaryGrad.createShader(b),
            child: const Text(
              'Mortix',
              style: TextStyle(
                color: Colors.white, fontSize: 15,
                fontWeight: FontWeight.w900, letterSpacing: 3,
                fontFamily: 'Qaxer',
              ),
            ),
          ),
          const Spacer(),
          // Status pill
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: _C.card.withOpacity(0.85),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _C.mint.withOpacity(0.5), width: 1),
                boxShadow: _C.glow(_C.mint, blur: 10, spread: 0),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 6, height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _C.mint,
                      boxShadow: [
                        BoxShadow(
                          color: _C.mint.withOpacity(0.8),
                          blurRadius: 8, spreadRadius: 1),
                      ],
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Text('ONLINE',
                    style: TextStyle(
                      color: _C.mint, fontSize: 9,
                      fontWeight: FontWeight.w900, letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // HERO CARD
  // ═══════════════════════════════════════════════════════════════
  Widget _buildHeroCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: AnimatedBuilder(
        animation: Listenable.merge([_heroCtrl, _orbitCtrl]),
        builder: (_, __) {
          return Container(
            height: 420,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(32),
              gradient: const LinearGradient(
                colors: [Color(0xFF0D1226), Color(0xFF121932)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              border: Border.all(color: _C.neon.withOpacity(0.3), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: _C.neon.withOpacity(0.25),
                  blurRadius: 50, spreadRadius: -8, offset: const Offset(0, 12),
                ),
                BoxShadow(
                  color: _C.violet.withOpacity(0.15),
                  blurRadius: 80, spreadRadius: -12,
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(32),
              child: Stack(
                children: [
                  // ── Background image with parallax
                  Positioned.fill(
                    child: Transform.translate(
                      offset: Offset(0, _scrollOffset * 0.15),
                      child: Image.asset(
                        'assets/images/landing.jpg',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          decoration: const BoxDecoration(gradient: _C.auroraGrad),
                        ),
                      ),
                    ),
                  ),

                  // ── Tint overlay
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            _C.bg.withOpacity(0.3),
                            _C.bg.withOpacity(0.7),
                            _C.bg.withOpacity(0.95),
                          ],
                          stops: const [0.0, 0.5, 1.0],
                        ),
                      ),
                    ),
                  ),

                  // ── Grid overlay
                  Positioned.fill(
                    child: CustomPaint(painter: _GridPainter()),
                  ),

                  // ── Top badge
                  Positioned(
                    top: 16, left: 16,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        gradient: _C.primaryGrad,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: _C.glow(_C.neon, blur: 14, spread: 0),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.bolt_rounded, color: Colors.white, size: 12),
                          SizedBox(width: 4),
                          Text('v17.0',
                            style: TextStyle(
                              color: Colors.white, fontSize: 11,
                              fontWeight: FontWeight.w900, letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // ── Live badge
                  Positioned(
                    top: 16, right: 16,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: _C.bg.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _C.pink.withOpacity(0.6), width: 1),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 6, height: 6,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _C.pink,
                              boxShadow: [
                                BoxShadow(
                                  color: _C.pink.withOpacity(0.8),
                                  blurRadius: 8, spreadRadius: 1),
                              ],
                            ),
                          ),
                          const SizedBox(width: 5),
                          const Text('LIVE',
                            style: TextStyle(
                              color: Colors.white, fontSize: 9,
                              fontWeight: FontWeight.w900, letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // ── Center logo ring
                  Center(
                    child: Transform.translate(
                      offset: const Offset(0, -30),
                      child: _buildCenterLogoRing(),
                    ),
                  ),

                  // ── Bottom content
                  Positioned(
                    bottom: 0, left: 0, right: 0,
                    child: Padding(
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ShaderMask(
                            shaderCallback: (b) => _C.auroraGrad.createShader(b),
                            child: const Text(
                              'Mortix',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 36,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 4,
                                height: 1,
                                fontFamily: 'Qaxer',
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Container(
                                width: 4, height: 4,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle, color: _C.neon),
                              ),
                              const SizedBox(width: 8),
                              const Text(
                                'Powered by @vinzzsukakmu',
                                style: TextStyle(
                                  color: _C.textSub,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              _buildHeroChip(Icons.people_rounded, '2.8K ONLINE'),
                              const SizedBox(width: 8),
                              _buildHeroChip(Icons.star_rounded, '4.9 RATING'),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildCenterLogoRing() {
    return SizedBox(
      width: 150, height: 150,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Outer breathing glow
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Container(
              width: 150, height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    _C.neon.withOpacity(0.15 + _pulseCtrl.value * 0.1),
                    Colors.transparent,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: _C.neon.withOpacity(0.3 + _pulseCtrl.value * 0.2),
                    blurRadius: 40, spreadRadius: 6,
                  ),
                ],
              ),
            ),
          ),
          // Orbit dot
          Transform.rotate(
            angle: _orbitCtrl.value * 2 * math.pi,
            child: SizedBox(
              width: 140, height: 140,
              child: Align(
                alignment: Alignment.topCenter,
                child: Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _C.neon,
                    boxShadow: [
                      BoxShadow(color: _C.neon, blurRadius: 12, spreadRadius: 2),
                    ],
                  ),
                ),
              ),
            ),
          ),
          // Ring 1
          Container(
            width: 130, height: 130,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: _C.neon.withOpacity(0.35), width: 1.5),
            ),
          ),
          // Ring 2
          Container(
            width: 110, height: 110,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: _C.violet.withOpacity(0.3), width: 1),
            ),
          ),
          // Logo core
          Container(
            width: 84, height: 84,
            padding: const EdgeInsets.all(2),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: _C.auroraGrad,
              boxShadow: _C.glow(_C.neon, blur: 24, spread: 2),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(22),
              child: Container(
                color: _C.card,
                child: Image.asset(
                  'assets/images/reze.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(
                    Icons.auto_awesome_rounded,
                    color: Colors.white, size: 36,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroChip(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: _C.bg.withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.neon.withOpacity(0.4), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: _C.neon, size: 10),
          const SizedBox(width: 5),
          Text(text,
            style: const TextStyle(
              color: _C.text, fontSize: 9.5,
              fontWeight: FontWeight.w900, letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // MARQUEE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildMarquee() {
    return AnimatedBuilder(
      animation: _marqueeCtrl,
      builder: (_, __) {
        final offset = _marqueeCtrl.value * 900;
        return Container(
          height: 36,
          decoration: BoxDecoration(
            color: _C.surface.withOpacity(0.6),
            border: Border.symmetric(
              horizontal: BorderSide(
                color: _C.neon.withOpacity(0.2), width: 1),
            ),
          ),
          child: ClipRect(
            child: Stack(
              children: [
                Positioned(
                  left: -offset,
                  top: 0, bottom: 0,
                  child: Row(
                    children: List.generate(3, (i) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 22),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.bolt_rounded, color: _C.neon, size: 13),
                          const SizedBox(width: 6),
                          ShaderMask(
                            shaderCallback: (b) => _C.primaryGrad.createShader(b),
                            child: const Text('Mortix v17',
                              style: TextStyle(
                                color: Colors.white, fontSize: 11,
                                fontWeight: FontWeight.w900, letterSpacing: 3,
                              ),
                            ),
                          ),
                          const SizedBox(width: 22),
                          const Icon(Icons.star_rounded, color: _C.gold, size: 13),
                          const SizedBox(width: 6),
                          const Text('LIMITED SLOTS',
                            style: TextStyle(
                              color: _C.textSub, fontSize: 11,
                              fontWeight: FontWeight.w900, letterSpacing: 3,
                            ),
                          ),
                          const SizedBox(width: 22),
                          const Icon(Icons.verified_rounded, color: _C.mint, size: 13),
                          const SizedBox(width: 6),
                          const Text('JOIN NOW',
                            style: TextStyle(
                              color: _C.textSub, fontSize: 11,
                              fontWeight: FontWeight.w900, letterSpacing: 3,
                            ),
                          ),
                          const SizedBox(width: 22),
                        ],
                      ),
                    )),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // BENTO STATS
  // ═══════════════════════════════════════════════════════════════
  Widget _buildBentoStats() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(flex: 2, child: _BentoStat(
                icon: Icons.people_rounded,
                value: '2,847',
                label: 'ACTIVE USERS',
                trend: '+12%',
                color: _C.mint,
                big: true,
              )),
              const SizedBox(width: 10),
              Expanded(child: _BentoStat(
                icon: Icons.bolt_rounded,
                value: '99.9%',
                label: 'UPTIME',
                trend: 'stable',
                color: _C.neon,
              )),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _BentoStat(
                icon: Icons.star_rounded,
                value: '4.9',
                label: 'RATING',
                trend: '+0.2',
                color: _C.gold,
              )),
              const SizedBox(width: 10),
              Expanded(child: _BentoStat(
                icon: Icons.security_rounded,
                value: 'AES',
                label: 'ENCRYPT',
                trend: '256-bit',
                color: _C.violet,
              )),
              const SizedBox(width: 10),
              Expanded(child: _BentoStat(
                icon: Icons.update_rounded,
                value: 'v17',
                label: 'VERSION',
                trend: 'fresh',
                color: _C.pink,
              )),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // SECTION TITLE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildSectionTitle(String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (b) => _C.primaryGrad.createShader(b),
                  child: Text(title,
                    style: const TextStyle(
                      color: Colors.white, fontSize: 18,
                      fontWeight: FontWeight.w900, letterSpacing: 2,
                    ),
                  ),
                ),
                const SizedBox(height: 3),
                Text(subtitle,
                  style: const TextStyle(
                    color: _C.textDim, fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 30, height: 2,
            decoration: BoxDecoration(
              gradient: _C.primaryGrad,
              borderRadius: BorderRadius.circular(2),
              boxShadow: _C.glow(_C.neon, blur: 10, spread: 0),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // FEATURE GRID (2x2)
  // ═══════════════════════════════════════════════════════════════
  Widget _buildFeatureGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: LayoutBuilder(builder: (context, c) {
        final w = (c.maxWidth - 12) / 2;
        return Wrap(
          spacing: 12,
          runSpacing: 12,
          children: _features.map((f) => SizedBox(
            width: w,
            child: _FeatureCard(
              icon: f['icon'] as IconData,
              title: f['title'] as String,
              metric: f['metric'] as String,
              desc: f['desc'] as String,
              color: f['color'] as Color,
            ),
          )).toList(),
        );
      }),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // REVIEWS GRID (2 col staggered)
  // ═══════════════════════════════════════════════════════════════
  Widget _buildReviewsGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: LayoutBuilder(builder: (context, c) {
        final w = (c.maxWidth - 12) / 2;
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: w,
              child: Column(
                children: [
                  _ReviewCard(r: _reviews[0], offset: false),
                  const SizedBox(height: 12),
                  _ReviewCard(r: _reviews[2], offset: true),
                ],
              ),
            ),
            const SizedBox(width: 12),
            SizedBox(
              width: w,
              child: Column(
                children: [
                  _ReviewCard(r: _reviews[1], offset: true),
                  const SizedBox(height: 12),
                  _ReviewCard(r: _reviews[3], offset: false),
                ],
              ),
            ),
          ],
        );
      }),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // CHANGELOG
  // ═══════════════════════════════════════════════════════════════
  Widget _buildChangelogCard() {
    final updates = [
      ('New RAT module v3', _C.neon),
      ('Performance +40%', _C.violet),
      ('Enhanced encryption', _C.pink),
      ('Fresh UI v17', _C.gold),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.gold.withOpacity(0.08), _C.card],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _C.gold.withOpacity(0.35), width: 1.2),
          boxShadow: _C.glow(_C.gold, blur: 20, spread: 0),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    gradient: _C.hotGrad,
                    borderRadius: BorderRadius.circular(9),
                    boxShadow: _C.glow(_C.pink, blur: 12, spread: 0),
                  ),
                  child: const Icon(Icons.new_releases_rounded,
                    color: Colors.white, size: 14),
                ),
                const SizedBox(width: 10),
                const Text("WHAT'S NEW",
                  style: TextStyle(
                    color: _C.text, fontSize: 13,
                    fontWeight: FontWeight.w900, letterSpacing: 1.8,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _C.gold.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _C.gold.withOpacity(0.5), width: 1),
                  ),
                  child: const Text('v17.0',
                    style: TextStyle(
                      color: _C.gold, fontSize: 9.5,
                      fontWeight: FontWeight.w900, letterSpacing: 0.8,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            ...updates.map((u) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  Container(
                    width: 6, height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: u.$2,
                      boxShadow: [
                        BoxShadow(color: u.$2.withOpacity(0.6), blurRadius: 6),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Text(u.$1,
                    style: const TextStyle(
                      color: _C.textSub, fontSize: 12,
                      fontWeight: FontWeight.w600, height: 1.4,
                    ),
                  )),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // CTA SECTION
  // ═══════════════════════════════════════════════════════════════
  Widget _buildCTASection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          _PrimaryCTA(onTap: () => Navigator.pushNamed(context, '/login')),
          const SizedBox(height: 12),
          _SecondaryCTA(onTap: () => _openUrl('https://t.me/vinzzsukakmu')),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // CONTACT
  // ═══════════════════════════════════════════════════════════════
  Widget _buildContactSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: _ContactPill(
                icon: FontAwesomeIcons.telegram,
                label: 'Telegram',
                color: _C.neon,
                onTap: () => _openUrl('https://t.me/vinzzsukakmu'),
              )),
              const SizedBox(width: 12),
              Expanded(child: _ContactPill(
                icon: FontAwesomeIcons.whatsapp,
                label: 'WhatsApp',
                color: _C.mint,
                onTap: () => _openUrl('https://wa.me/'),
              )),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // FOOTER
  // ═══════════════════════════════════════════════════════════════
  Widget _buildFooter() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(width: 40, height: 1.5,
              decoration: BoxDecoration(
                gradient: _C.primaryGrad,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: _C.card,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _C.borderLit.withOpacity(0.4), width: 1),
              ),
              child: const Text(
                '© 2026 Mortix',
                style: TextStyle(
                  color: _C.textDim, fontSize: 10.5,
                  fontWeight: FontWeight.w800, letterSpacing: 1.2,
                ),
              ),
            ),
            const SizedBox(width: 14),
            Container(width: 40, height: 1.5,
              decoration: BoxDecoration(
                gradient: _C.primaryGrad,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET: BENTO STAT
// ═══════════════════════════════════════════════════════════════════
class _BentoStat extends StatelessWidget {
  final IconData icon;
  final String value, label, trend;
  final Color color;
  final bool big;

  const _BentoStat({
    required this.icon, required this.value, required this.label,
    required this.trend, required this.color, this.big = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(big ? 16 : 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.12), _C.card],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.35), width: 1.2),
        boxShadow: _C.glow(color, blur: 16, spread: 0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: color, size: big ? 16 : 13),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(5),
                  border: Border.all(color: color.withOpacity(0.4), width: 0.8),
                ),
                child: Text(trend,
                  style: TextStyle(
                    color: color, fontSize: 8,
                    fontWeight: FontWeight.w900, letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ShaderMask(
            shaderCallback: (b) => LinearGradient(
              colors: [color, Colors.white],
            ).createShader(b),
            child: Text(value,
              style: TextStyle(
                color: Colors.white,
                fontSize: big ? 26 : 20,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.5,
                height: 1,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(label,
            style: const TextStyle(
              color: _C.textDim, fontSize: 9,
              fontWeight: FontWeight.w900, letterSpacing: 1.2,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET: FEATURE CARD
// ═══════════════════════════════════════════════════════════════════
class _FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title, metric, desc;
  final Color color;

  const _FeatureCard({
    required this.icon, required this.title,
    required this.metric, required this.desc, required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.12), _C.card],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.35), width: 1.2),
        boxShadow: _C.glow(color, blur: 18, spread: 0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 46, height: 46,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [color, color.withOpacity(0.5)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: _C.glow(color, blur: 14, spread: 0),
            ),
            child: Icon(icon, color: Colors.white, size: 24),
          ),
          const SizedBox(height: 12),
          Text(title,
            style: const TextStyle(
              color: _C.text, fontSize: 13,
              fontWeight: FontWeight.w900, letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 4),
          ShaderMask(
            shaderCallback: (b) => LinearGradient(
              colors: [color, Colors.white],
            ).createShader(b),
            child: Text(metric,
              style: const TextStyle(
                color: Colors.white, fontSize: 18,
                fontWeight: FontWeight.w900, height: 1,
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(desc,
            maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: _C.textSub, fontSize: 10.5,
              height: 1.35, fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET: REVIEW CARD
// ═══════════════════════════════════════════════════════════════════
class _ReviewCard extends StatelessWidget {
  final Map<String, dynamic> r;
  final bool offset;
  const _ReviewCard({required this.r, required this.offset});

  @override
  Widget build(BuildContext context) {
    final color = r['color'] as Color;
    final name = r['name'] as String;
    final role = r['role'] as String;
    final text = r['text'] as String;
    final rating = r['rating'] as int;

    return Transform.translate(
      offset: Offset(0, offset ? 16 : 0),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color.withOpacity(0.1), _C.card],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: color.withOpacity(0.3), width: 1.1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: List.generate(5, (j) => Icon(
                j < rating ? Icons.star_rounded : Icons.star_border_rounded,
                color: _C.gold, size: 13,
              )),
            ),
            const SizedBox(height: 10),
            Text('"$text"',
              maxLines: 3, overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: _C.text, fontSize: 11.5,
                fontStyle: FontStyle.italic, height: 1.4,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Container(
                  width: 22, height: 22,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [color, color.withOpacity(0.5)],
                    ),
                  ),
                  child: const Icon(Icons.person_rounded,
                    color: Colors.white, size: 12),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: Text(name,
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _C.text, fontSize: 10.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: color.withOpacity(0.5), width: 0.8),
                  ),
                  child: Text(role,
                    style: TextStyle(
                      color: color, fontSize: 7.5,
                      fontWeight: FontWeight.w900, letterSpacing: 0.5,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET: PRIMARY CTA
// ═══════════════════════════════════════════════════════════════════
class _PrimaryCTA extends StatefulWidget {
  final VoidCallback onTap;
  const _PrimaryCTA({required this.onTap});

  @override
  State<_PrimaryCTA> createState() => _PrimaryCTAState();
}

class _PrimaryCTAState extends State<_PrimaryCTA>
    with SingleTickerProviderStateMixin {
  late AnimationController _shine;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _shine = AnimationController(
      vsync: this, duration: const Duration(seconds: 3))..repeat();
  }

  @override
  void dispose() { _shine.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 62,
          decoration: BoxDecoration(
            gradient: _C.auroraGrad,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(color: _C.neon.withOpacity(0.5),
                blurRadius: 24, spreadRadius: 2),
              BoxShadow(color: _C.violet.withOpacity(0.3),
                blurRadius: 40, spreadRadius: -4),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Stack(
              children: [
                // Shine
                AnimatedBuilder(
                  animation: _shine,
                  builder: (_, __) => Positioned.fill(
                    child: Transform.translate(
                      offset: Offset(-200 + _shine.value * 600, 0),
                      child: Container(
                        width: 80,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [
                            Colors.transparent,
                            Colors.white.withOpacity(0.35),
                            Colors.transparent,
                          ]),
                        ),
                      ),
                    ),
                  ),
                ),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(0.25),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.6), width: 1.5),
                        ),
                        child: const Icon(Icons.login_rounded,
                          color: Colors.white, size: 17),
                      ),
                      const SizedBox(width: 12),
                      const Text('ENTER LOGIN',
                        style: TextStyle(
                          color: Colors.white, fontSize: 16,
                          fontWeight: FontWeight.w900, letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Icon(Icons.arrow_forward_rounded,
                        color: Colors.white, size: 18),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET: SECONDARY CTA
// ═══════════════════════════════════════════════════════════════════
class _SecondaryCTA extends StatefulWidget {
  final VoidCallback onTap;
  const _SecondaryCTA({required this.onTap});

  @override
  State<_SecondaryCTA> createState() => _SecondaryCTAState();
}

class _SecondaryCTAState extends State<_SecondaryCTA> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 58,
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.gold.withOpacity(0.5), width: 1.5),
            boxShadow: _C.glow(_C.gold, blur: 16, spread: 0),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.shopping_bag_outlined, color: _C.gold, size: 18),
              const SizedBox(width: 10),
              const Text('BUY ACCESS',
                style: TextStyle(
                  color: _C.text, fontSize: 14,
                  fontWeight: FontWeight.w900, letterSpacing: 1.8,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(
                  color: _C.gold.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: _C.gold.withOpacity(0.5), width: 1),
                ),
                child: const Text('VIA TG',
                  style: TextStyle(
                    color: _C.gold, fontSize: 9,
                    fontWeight: FontWeight.w900, letterSpacing: 0.8,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET: CONTACT PILL
// ═══════════════════════════════════════════════════════════════════
class _ContactPill extends StatefulWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ContactPill({
    required this.icon, required this.label,
    required this.color, required this.onTap,
  });

  @override
  State<_ContactPill> createState() => _ContactPillState();
}

class _ContactPillState extends State<_ContactPill> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 56,
          decoration: BoxDecoration(
            color: _pressed ? widget.color.withOpacity(0.15) : _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: widget.color.withOpacity(0.5), width: 1.2),
            boxShadow: _pressed ? _C.glow(widget.color, blur: 20, spread: 0) : [],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 30, height: 30,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.color.withOpacity(0.15),
                  border: Border.all(
                    color: widget.color.withOpacity(0.6), width: 1.2),
                ),
                child: Center(
                  child: FaIcon(widget.icon, color: widget.color, size: 13),
                ),
              ),
              const SizedBox(width: 10),
              Text(widget.label,
                style: const TextStyle(
                  color: _C.text, fontSize: 13,
                  fontWeight: FontWeight.w800, letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// PAINTERS
// ═══════════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _C.neon.withOpacity(0.05)
      ..strokeWidth = 0.5;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }
  @override
  bool shouldRepaint(CustomPainter old) => false;
}

class _AuroraBgPainter extends CustomPainter {
  final double t, p;
  _AuroraBgPainter(this.t, this.p);

  @override
  void paint(Canvas canvas, Size size) {
    // Base gradient
    final bg = Paint()
      ..shader = _C.bgGrad.createShader(
        Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bg);

    // Orb 1
    final o1x = size.width * 0.2 + math.cos(t * 2 * math.pi) * 80;
    final o1y = size.height * 0.15 + math.sin(t * 2 * math.pi) * 60;
    final o1 = Paint()
      ..shader = RadialGradient(colors: [
        _C.neon.withOpacity(0.15),
        Colors.transparent,
      ]).createShader(Rect.fromCircle(center: Offset(o1x, o1y), radius: 320));
    canvas.drawCircle(Offset(o1x, o1y), 320, o1);

    // Orb 2
    final o2x = size.width * 0.85 + math.cos(t * 2 * math.pi + 1.5) * 70;
    final o2y = size.height * 0.5 + math.sin(t * 2 * math.pi + 1.5) * 60;
    final o2 = Paint()
      ..shader = RadialGradient(colors: [
        _C.violet.withOpacity(0.12),
        Colors.transparent,
      ]).createShader(Rect.fromCircle(center: Offset(o2x, o2y), radius: 280));
    canvas.drawCircle(Offset(o2x, o2y), 280, o2);

    // Orb 3
    final o3x = size.width * 0.5 + math.cos(t * 2 * math.pi + 3) * 90;
    final o3y = size.height * 0.85 + math.sin(t * 2 * math.pi + 3) * 50;
    final o3 = Paint()
      ..shader = RadialGradient(colors: [
        _C.pink.withOpacity(0.1),
        Colors.transparent,
      ]).createShader(Rect.fromCircle(center: Offset(o3x, o3y), radius: 260));
    canvas.drawCircle(Offset(o3x, o3y), 260, o3);

    // Grid overlay
    final grid = Paint()
      ..color = _C.neon.withOpacity(0.03)
      ..strokeWidth = 0.5;
    const step = 50.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }

  @override
  bool shouldRepaint(_AuroraBgPainter old) => old.t != t || old.p != p;
}
