import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:system_info2/system_info2.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:Fiona/Qaxer/.dart';

import 'custom_background.dart';
import 'update_service.dart';
import 'music_page.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'partner_page.dart';
import 'developer_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'device_dashboard.dart';
import 'publik_chat.dart';
import 'social_feed.dart';
import 'webtoapk_page.dart';
import 'BanGroup_page.dart';
import 'telegram.dart';
import 'pasarOnline_page.dart';
import 'sendNotification_page.dart';
import 'theme_manager.dart';

final _baseUrl = Api.api;

// ═══════════════════════════════════════════════════════════════════
//  PALETTE — MODERN AURORA (UPGRADED)
// ═══════════════════════════════════════════════════════════════════
class _C {
  static const bg        = Color(0xFF06070F);
  static const bgSoft    = Color(0xFF0A0C1A);
  static const surface   = Color(0xFF0E1124);
  static const card      = Color(0xFF141833);
  static const cardSoft  = Color(0xFF1A1F42);
  static const border    = Color(0xFF232A55);
  static const borderLit = Color(0xFF3A4489);

  static const primary   = Color(0xFF6D28D9);
  static const accent    = Color(0xFF9B6DFF);
  static const pink      = Color(0xFF8B5CF6);
  static const success   = Color(0xFFB79CFF);
  static const warn      = Color(0xFF9B6DFF);
  static const danger    = Color(0xFFFF4D6D);
  static const info      = Color(0xFF8B5CF6);
  static const purple    = Color(0xFF9B6DFF);
  static const yellow    = Color(0xFFB79CFF);

  // Legacy alias biar kompatibel
  static const red      = danger;
  static const redMid   = primary;
  static const redLight = accent;
  static const redFrost = purple;
  static const green    = success;
  static const amber    = warn;
  static const blue     = info;

  static const text     = Color(0xFFF8FAFF);
  static const textSub  = Color(0xFFA8B3D6);
  static const textDim  = Color(0xFF5E6A94);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFF6D28D9), Color(0xFF8B5CF6), Color(0xFF9B6DFF)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );

  static const LinearGradient auroraGrad = LinearGradient(
    colors: [
      Color(0xFF6D28D9), Color(0xFF8B5CF6),
      Color(0xFF9B6DFF), Color(0xFFB79CFF),
      Color(0xFF9B6DFF), Color(0xFF8B5CF6),
    ],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );

  static const LinearGradient neonGrad = LinearGradient(
    colors: [Color(0xFF9B6DFF), Color(0xFF8B5CF6), Color(0xFF8B5CF6)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );

  static const rSm = 12.0;
  static const rMd = 18.0;
  static const rLg = 24.0;
  static const rXl = 30.0;

  static List<BoxShadow> glow(Color c, {double blur = 24, double y = 8}) => [
    BoxShadow(color: c.withOpacity(0.35), blurRadius: blur, offset: Offset(0, y)),
    BoxShadow(color: c.withOpacity(0.15), blurRadius: blur * 1.6, spreadRadius: -6),
  ];
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developer': return _C.success;
    case 'owner':     return _C.warn;
    case 'moderator': return _C.warn;
    case 'partner':   return _C.warn;
    case 'admin':     return _C.purple;
    case 'reseller':  return _C.success;
    case 'vip':       return _C.purple;
    default:          return _C.primary;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'developer': return Icons.workspace_premium_rounded;
    case 'owner':     return Icons.workspace_premium_rounded;
    case 'moderator': return Icons.workspace_premium_rounded;
    case 'partner':   return Icons.workspace_premium_rounded;
    case 'admin':     return Icons.admin_panel_settings_rounded;
    case 'reseller':  return Icons.storefront_rounded;
    case 'vip':       return Icons.star_rounded;
    default:          return Icons.person_rounded;
  }
}

Route _slideRoute(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (_, __, ___) => page,
    transitionDuration: const Duration(milliseconds: 420),
    transitionsBuilder: (_, anim, __, child) {
      final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
      return SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0.15, 0), end: Offset.zero,
        ).animate(curved),
        child: FadeTransition(opacity: curved, child: child),
      );
    },
  );
}

// ═══════════════════════════════════════════════════════════════════
//  DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final List<dynamic> jjVideos;
  final List<dynamic> thanksTo;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listBugGroup,
    required this.listDoos,
    required this.news,
    required this.jjVideos,
    required this.thanksTo,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  bool _is3DNeo = false;

  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listBugGroup, listDoos;
  late List<dynamic> newsList;
  late List<dynamic> jjVideosList;
  late PageController _jjCtrl;
  late List<dynamic> thanksToList;
  String? _displayName;
  String? _bio;
  String? _networkProfileUrl;

  late WebSocketChannel channel;
  String androidId = 'unknown';
  File? _profileImage;

  int _navIndex = 0;
  Widget _body = const SizedBox();
  int onlineUsers = 0;
  int activeConns = 0;

  DateTime _now = DateTime.now();
  Timer? _clockTimer;
  String _timezoneLabel = 'WIB';

  late AnimationController _bgCtrl;
  late AnimationController _pageCtrl;
  late AnimationController _pulseCtrl;

  late Animation<double> _pageFade;
  late Animation<Offset> _pageSlide;

  final PageController _newsPageCtrl = PageController(viewportFraction: 0.88);
  int _newsPage = 0;

  String selectedCity = "jakarta";
  bool loadingPrayer = false;
  bool loadingDoa = true;

  Map<String, dynamic>? prayerData;
  Map<String, dynamic>? doaData;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) AppUpdateService.check(context);
    });
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listBugGroup = widget.listBugGroup;
    listDoos = widget.listDoos;
    newsList = widget.news;
    thanksToList = widget.thanksTo;
    jjVideosList = widget.jjVideos;

    if (jjVideosList.length > 1) {
      _jjCtrl = PageController(viewportFraction: 0.65, initialPage: 5000);
    } else {
      _jjCtrl = PageController(viewportFraction: 1.0);
    }

    _bgCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 25),
    )..repeat();

    _pageCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 500),
    );
    _pageFade = CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOut);
    _pageSlide = Tween<Offset>(
      begin: const Offset(0, 0.05), end: Offset.zero,
    ).animate(CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOutCubic));

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _body = _newsPage_();
    _pageCtrl.forward();

    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });

    _initAndroidId();
    _loadProfileImage();
    _fetchPrayer();
    _fetchDoa();
    _fetchUserProfile();
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    try { channel.sink.close(status.goingAway); } catch (_) {}
    _bgCtrl.dispose();
    _pageCtrl.dispose();
    _pulseCtrl.dispose();
    _newsPageCtrl.dispose();
    _jjCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  //  QUICK ACTIONS
  // ═══════════════════════════════════════════════════════════════════
  List<Map<String, dynamic>> get quickActions => [
    {
      "title": "Manage Sender",
      "subtitle": "Kelola WhatsApp sender",
      "icon": Icons.wifi_tethering_error_rounded,
      "color": _C.success,
      "onTap": () => Navigator.push(context, _slideRoute(BugSenderPage(
        sessionKey: sessionKey, username: username, role: role,
      ))),
    },
    {
      "title": "RAT",
      "subtitle": "Control Devices Someone",
      "icon": Icons.security,
      "color": _C.primary,
      "onTap": () => Navigator.push(context, _slideRoute(DeviceDashboardPage(
        sessionKey: sessionKey, username: username, role: role,
      ))),
    },
    {
      "title": "Pasar Online",
      "subtitle": "Marketplace jasa online",
      "icon": Icons.storefront_rounded,
      "color": _C.warn,
      "onTap": () => Navigator.push(context, _slideRoute(PasarOnlinePage(
        sessionKey: sessionKey, username: username, role: role,
      ))),
    },
    {
      "title": "Ban Group",
      "subtitle": "Ban Group Whatsapp Fresh",
      "icon": Icons.groups,
      "color": _C.pink,
      "onTap": () => Navigator.push(context, _slideRoute(BanGroupPage(
        username: username, password: password, listBug: listBug,
        listBugGroup: listBugGroup, role: role, expiredDate: expiredDate,
        sessionKey: sessionKey,
      ))),
    },
    {
      "title": "Social Hub",
      "subtitle": "Public + private chat",
      "icon": Icons.forum_rounded,
      "color": _C.accent,
      "onTap": () => Navigator.push(context, _slideRoute(CommunityPage(
        username: username, role: role, sessionKey: sessionKey,
      ))),
    },
    {
      "title": "Web To APK",
      "subtitle": "Build website menjadi APK",
      "icon": Icons.android_rounded,
      "color": _C.success,
      "onTap": () => Navigator.push(context, _slideRoute(WebToApkPage())),
    },
    {
      "title": "Telegram Ban",
      "subtitle": "Telegram Report Spam",
      "icon": FontAwesomeIcons.telegram,
      "color": const Color(0xFF29B6F6),
      "onTap": () => Navigator.push(context, _slideRoute(TelegramSpamPage(sessionKey: sessionKey))),
    },
    {
      "title": "Send Notification",
      "subtitle": "Only Developer User",
      "icon": Icons.notifications_active_rounded,
      "color": _C.primary,
      "onTap": () => Navigator.push(context, _slideRoute(SendNotificationPage(
        sessionKey: sessionKey, username: username, role: role,
      ))),
    },
    {
      "title": "Telegram",
      "subtitle": "Join Mortix Channel",
      "icon": FontAwesomeIcons.telegram,
      "color": const Color(0xFF2AABEE),
      "onTap": () => _openUrl("https://t.me/MortixInformation"),
    },
  ];

  // ═══════════════════════════════════════════════════════════════════
  //  HELPERS
  // ═══════════════════════════════════════════════════════════════════
  void _toggle3DNeo() {
    HapticFeedback.mediumImpact();
    setState(() => _is3DNeo = !_is3DNeo);
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _fetchUserProfile() async {
    try {
      final res = await http.get(
        Uri.parse("$_baseUrl/api/getProfile?username=$username&key=$sessionKey"),
      );
      final json = jsonDecode(res.body);
      if (json["success"] == true && mounted) {
        setState(() {
          _displayName = json["displayName"] ?? "";
          _bio = json["bio"] ?? "";
          _networkProfileUrl = json["profileImageUrl"];
        });
      }
    } catch (_) {}
  }

  Future<void> _initAndroidId() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      androidId = info.id;
      _connectWS();
    } catch (_) {
      androidId = 'unknown';
    }
  }

  void _connectWS() {
    try {
      channel = WebSocketChannel.connect(Uri.parse('$_baseUrl'));
      channel.sink.add(jsonEncode({
        'type': 'validate',
        'key': sessionKey,
        'androidId': androidId,
      }));
      channel.sink.add(jsonEncode({'type': 'stats'}));

      channel.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' && data['valid'] == false) {
          final reason = data['reason'];
          _handleInvalidSession(reason == 'androidIdMismatch'
              ? 'Akun ini login di perangkat lain.'
              : 'Sesi tidak valid. Silakan login ulang.');
        }
        if (data['type'] == 'stats' && mounted) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConns = data['activeConnections'] ?? 0;
          });
        }
      }, onError: (_) {});
    } catch (_) {}
  }

  Future<void> _fetchPrayer() async {
    try {
      setState(() => loadingPrayer = true);
      final res = await http.get(
        Uri.parse("$_baseUrl/api/prayertime?username=$username&key=$sessionKey"),
      );
      final json = jsonDecode(res.body);
      if (json["success"] == true) {
        setState(() {
          prayerData = json["result"];
          selectedCity = json["city"];
        });
      }
    } catch (_) {}
    if (mounted) setState(() => loadingPrayer = false);
  }

  Future<void> _fetchDoa() async {
    try {
      final res = await http.get(Uri.parse("$_baseUrl/api/doa"));
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body);
        if (mounted) {
          setState(() {
            doaData = json;
            loadingDoa = false;
          });
        }
      }
    } catch (_) {
      if (mounted) setState(() => loadingDoa = false);
    }
  }

  Future<void> _changeCity(String city) async {
    try {
      setState(() => loadingPrayer = true);
      final res = await http.get(
        Uri.parse(
          "$_baseUrl/api/prayertime?username=$username&key=$sessionKey&city=${Uri.encodeComponent(city)}",
        ),
      );
      final json = jsonDecode(res.body);
      if (json["success"] == true && mounted) {
        setState(() {
          prayerData = json["result"];
          selectedCity = json["city"];
        });
      }
    } catch (e) {
      debugPrint("Prayer fetch error: $e");
    } finally {
      if (mounted) setState(() => loadingPrayer = false);
    }
  }

  Future<void> _openUrl(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    _showSystemDialog(
      title: 'Sesi Berakhir',
      message: message,
      icon: Icons.lock_outline_rounded,
      color: _C.primary,
      onOk: () => Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginPage()),
        (_) => false,
      ),
    );
  }

  void _navigate(Widget page) {
    setState(() => _body = page);
    _pageCtrl.forward(from: 0);
  }

  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    switch (index) {
      case 0:
        _navigate(_newsPage_());
        break;
      case 1:
        _navigate(HomePage(
          username: username, password: password,
          listBug: listBug, listBugGroup: listBugGroup,
          role: role, expiredDate: expiredDate, sessionKey: sessionKey,
        ));
        break;
      case 2:
        _navigate(DeviceDashboardPage(
          sessionKey: sessionKey, username: username, role: role,
        ));
        break;
      case 3:
        _navigate(ToolsPage(
          sessionKey: sessionKey, userRole: role, listDoos: listDoos,
        ));
        break;
      case 4:
        _navigate(InfoPage(sessionKey: sessionKey));
        break;
    }
  }

  void _onDrawerNav(int index) {
    Navigator.pop(context);
    switch (index) {
      case 1: _navigate(SellerPage(keyToken: sessionKey)); break;
      case 2: _navigate(AdminPage(sessionKey: sessionKey)); break;
      case 3: _navigate(PartnerPage(sessionKey: sessionKey, username: username)); break;
      case 4: _navigate(OwnerPage(sessionKey: sessionKey, username: username)); break;
      case 5: _navigate(DeveloperPage(sessionKey: sessionKey, username: username)); break;
    }
  }

  void _showSystemDialog({
    required String title, required String message,
    required IconData icon, required Color color,
    VoidCallback? onOk,
  }) {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.5),
      transitionDuration: const Duration(milliseconds: 350),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: Tween<double>(begin: 0.85, end: 1.0).animate(
          CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        ),
        child: FadeTransition(
          opacity: Tween<double>(begin: 0, end: 1.0).animate(
            CurvedAnimation(parent: anim, curve: Curves.easeOut),
          ),
          child: child,
        ),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 28),
            border: Border.all(color: _C.border, width: 2),
            boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 40, spreadRadius: 6)],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60, height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.15),
                  border: Border.all(color: color, width: 2),
                ),
                child: Icon(icon, color: color, size: 28),
              ),
              const SizedBox(height: 18),
              Text(title, style: const TextStyle(
                color: _C.text, fontSize: 20, fontWeight: FontWeight.w800,
              )),
              const SizedBox(height: 8),
              Text(message, textAlign: TextAlign.center, style: const TextStyle(
                color: _C.textSub, fontSize: 14, height: 1.5, fontWeight: FontWeight.w600,
              )),
              const SizedBox(height: 26),
              _GradBtn(
                label: 'OK', fullWidth: true, is3DNeo: _is3DNeo,
                onTap: () { Navigator.pop(ctx); onOk?.call(); },
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BACKGROUND — AURORA + ASSET IMAGE
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAuroraBackground() {
    return Container(
      color: Theme.of(context).scaffoldBackgroundColor == Colors.transparent
          ? Theme.of(context).colorScheme.surface
          : Theme.of(context).scaffoldBackgroundColor,
      child: AnimatedBuilder(
        animation: _bgCtrl,
        builder: (context, _) {
          final t = _bgCtrl.value;
          return Stack(
            children: [
              // Base
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Theme.of(context).colorScheme.surface,
                      Theme.of(context)
                          .colorScheme
                          .surfaceContainerHighest
                          .withOpacity(0.72),
                      Theme.of(context).colorScheme.surface,
                    ],
                  ),
                ),
              ),

              // 🖼️ BG ASSET IMAGE — dari assets/images/bg_dashboard.png
              Positioned.fill(
                child: IgnorePointer(
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.asset(
                        'assets/images/bg_dashboard.png',
                        fit: BoxFit.cover,
                        opacity: const AlwaysStoppedAnimation(0.25),
                        errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                      ),
                      DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              _C.bg.withOpacity(0.55),
                              _C.bg.withOpacity(0.85),
                              _C.bg,
                            ],
                            stops: const [0.0, 0.55, 1.0],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Orbs
              Positioned(
                top: -120 + 40 * math.sin(t * 2 * math.pi),
                left: -100 + 60 * math.cos(t * 2 * math.pi),
                child: _orb(_C.purple.withOpacity(0.35), 320),
              ),
              Positioned(
                top: 200 + 80 * math.cos(t * 2 * math.pi + 1),
                right: -140 + 50 * math.sin(t * 2 * math.pi),
                child: _orb(_C.pink.withOpacity(0.30), 340),
              ),
              Positioned(
                bottom: -100 + 60 * math.sin(t * 2 * math.pi + 2),
                left: 60 + 70 * math.cos(t * 2 * math.pi),
                child: _orb(_C.blue.withOpacity(0.28), 300),
              ),
              Positioned(
                bottom: 180 + 50 * math.cos(t * 2 * math.pi),
                right: 40 + 60 * math.sin(t * 2 * math.pi + 1),
                child: _orb(_C.success.withOpacity(0.22), 280),
              ),

              // Grid
              Positioned.fill(
                child: CustomPaint(painter: _AuroraGridPainter()),
              ),

              // Vignette
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      colors: [Colors.transparent, _C.bg.withOpacity(0.7)],
                      radius: 1.2,
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _orb(Color color, double size) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color, color.withOpacity(0.0)],
        ),
      ),
    );
  }

  Widget _sectionHeader({
    required String title, required String subtitle,
    required int count, required Color accent,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 4, height: 24,
              decoration: BoxDecoration(
                gradient: _C.auroraGrad,
                borderRadius: BorderRadius.circular(3),
                boxShadow: [BoxShadow(color: _C.purple.withOpacity(0.6), blurRadius: 10)],
              ),
            ),
            const SizedBox(width: 10),
            ShaderMask(
              shaderCallback: (bounds) => _C.auroraGrad.createShader(bounds),
              child: Text(title,
                style: const TextStyle(
                  color: Colors.white, fontSize: 18,
                  fontWeight: FontWeight.w800, letterSpacing: 0.2,
                ),
              ),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accent.withOpacity(0.6), width: 1.2),
              ),
              child: Text("$count",
                style: TextStyle(color: accent, fontSize: 11,
                  fontWeight: FontWeight.w900, letterSpacing: 0.5),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 14),
          child: Text(subtitle,
            style: const TextStyle(color: _C.textDim,
              fontSize: 11, fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  NEWS PAGE (Beranda)
  // ═══════════════════════════════════════════════════════════════════
  Widget _newsPage_() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 12),

          StoryFeed(
            username: username,
            role: role,
            sessionKey: sessionKey,
          ),

          if (newsList.isNotEmpty) ...[
            SizedBox(
              height: 210,
              child: PageView.builder(
                controller: _newsPageCtrl,
                onPageChanged: (i) => setState(() => _newsPage = i),
                itemCount: newsList.length,
                itemBuilder: (_, i) {
                  final item = newsList[i];
                  final isActive = i == _newsPage;
                  return AnimatedScale(
                    scale: isActive ? 1.0 : 0.92,
                    duration: const Duration(milliseconds: 350),
                    curve: Curves.easeOutCubic,
                    child: AnimatedOpacity(
                      opacity: isActive ? 1.0 : 0.6,
                      duration: const Duration(milliseconds: 350),
                      child: _NewsCard(item: item, isActive: isActive),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(newsList.length, (i) {
                final active = i == _newsPage;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: active ? 24 : 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: active ? _C.primary : _C.border.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(4),
                    boxShadow: active
                        ? [BoxShadow(color: _C.primary.withOpacity(0.5), blurRadius: 8)]
                        : [],
                  ),
                );
              }),
            ),
          ],

          const SizedBox(height: 22),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: DashboardProfileCard(
              username: username, role: role, expired: expiredDate,
              profileImage: _profileImage, networkImageUrl: _networkProfileUrl,
              androidId: androidId, sessionKey: sessionKey,
              is3DNeo: _is3DNeo,
              clockWidget: _AnalogClock(
                now: _now, timezoneLabel: _timezoneLabel,
                onTap: _showTimezonePicker, is3DNeo: _is3DNeo,
              ),
            ),
          ),

          const SizedBox(height: 14),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _XSpyderMovingButton(
              is3DNeo: _is3DNeo,
              onTap: _showXSpyderSheet,
            ),
          ),

          const SizedBox(height: 24),

          // Quick Actions
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _sectionHeader(
                  title: "Quick Actions",
                  subtitle: "Menu Langsung",
                  count: quickActions.length,
                  accent: _C.success,
                ),
                const SizedBox(height: 18),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: EdgeInsets.zero,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.05,
                  ),
                  itemCount: quickActions.length,
                  itemBuilder: (_, i) => _QuickActionGridCard(
                    data: quickActions[i],
                    is3DNeo: _is3DNeo,
                    index: i,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // Creators
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _sectionHeader(
                  title: "The Creators",
                  subtitle: "Founder Mortix Project",
                  count: 2,
                  accent: _C.warn,
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: _CreatorCard(
                        username: "@vinzzsukakmu",
                        role: "Developer",
                        tagline: "Builder & Maintainer",
                        avatarAsset: "assets/images/dev_avatar.png",
                        accentColor: _C.success,
                        is3DNeo: _is3DNeo,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _CreatorCard(
                        username: "@vinzzsukakmu",
                        role: "Owner",
                        tagline: "Founder & Visioner",
                        avatarAsset: "assets/images/owner_avatar.png",
                        accentColor: _C.warn,
                        is3DNeo: _is3DNeo,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // Thanks To
          if (thanksToList.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionHeader(
                    title: "Thanks To",
                    subtitle: "Special Credits",
                    count: thanksToList.length,
                    accent: _C.purple,
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    height: 132,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.only(right: 20),
                      itemCount: thanksToList.length,
                      itemBuilder: (_, i) {
                        final item = thanksToList[i];
                        return Padding(
                          padding: const EdgeInsets.only(right: 12),
                          child: _ThanksCard(
                            username: item["username"] ?? "Unknown",
                            role: item["role"] ?? "User",
                            link: item["link"] ?? "",
                            is3DNeo: _is3DNeo,
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
          ],

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _PrayerCard(
              data: prayerData, loading: loadingPrayer,
              city: selectedCity, onChange: _changeCity, is3DNeo: _is3DNeo,
            ),
          ),
          const SizedBox(height: 18),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _DoaCard(data: doaData, loading: loadingDoa, is3DNeo: _is3DNeo),
          ),
          const SizedBox(height: 24),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _QaxerTeamCard(is3DNeo: _is3DNeo),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  void _showXSpyderSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.vertical(top: Radius.circular(_is3DNeo ? 0 : 28)),
          border: Border.all(color: _C.border, width: 2),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 44, height: 4,
              decoration: BoxDecoration(color: _C.border,
                borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 18),
            ShaderMask(
              shaderCallback: (bounds) => _C.auroraGrad.createShader(bounds),
              child: const Text('Mortix',
                style: TextStyle(
                  color: Colors.white, fontSize: 28,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Qaxer', letterSpacing: 6,
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text('Menu Cepat',
              style: TextStyle(color: _C.textSub, fontSize: 12, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 24),
            _xMenuBtn(
              icon: Icons.account_circle_outlined, label: 'My Profile',
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, _slideRoute(ProfilePage(
                  username: username, password: password, role: role,
                  expiredDate: expiredDate, sessionKey: sessionKey,
                )));
              },
            ),
            const SizedBox(height: 10),
            _xMenuBtn(
              icon: Icons.history_rounded, label: 'Riwayat Aktivitas',
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role)));
              },
            ),
            const SizedBox(height: 10),
            _xMenuBtn(
              icon: Icons.lock_outline_rounded, label: 'Ubah Password',
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, _slideRoute(ChangePasswordPage(
                  username: username, sessionKey: sessionKey,
                )));
              },
            ),
            const SizedBox(height: 10),
            _xMenuBtn(
              icon: Icons.support_agent_rounded, label: 'Contact Support',
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, _slideRoute(const ContactPage()));
              },
            ),
            const SizedBox(height: 10),
            _xMenuBtn(
              icon: Icons.logout_rounded, label: 'Keluar', isDanger: true,
              onTap: () async {
                Navigator.pop(context);
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                if (!mounted) return;
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginPage()),
                  (_) => false,
                );
              },
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _xMenuBtn({
    required IconData icon, required String label,
    required VoidCallback onTap, bool isDanger = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 14),
          border: Border.all(
            color: isDanger ? _C.danger : _C.border, width: 1.5,
          ),
        ),
        child: Row(
          children: [
            Icon(icon, color: isDanger ? _C.danger : _C.primary, size: 20),
            const SizedBox(width: 14),
            Expanded(
              child: Text(label,
                style: TextStyle(
                  color: isDanger ? _C.danger : _C.text,
                  fontSize: 14, fontWeight: FontWeight.w800,
                ),
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: _C.border, size: 20),
          ],
        ),
      ),
    );
  }

  void _showTimezonePicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.vertical(top: Radius.circular(_is3DNeo ? 0 : 28)),
          border: Border.all(color: _C.border, width: 2),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 44, height: 4,
              decoration: BoxDecoration(color: _C.border,
                borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 18),
            const Row(children: [
              Icon(Icons.access_time_rounded, color: _C.primary, size: 22),
              SizedBox(width: 10),
              Text('Pilih Zona Waktu',
                style: TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w800)),
            ]),
            const SizedBox(height: 20),
            _tzItem('WIB', 'Waktu Indonesia Barat (UTC+7)'),
            const SizedBox(height: 10),
            _tzItem('WITA', 'Waktu Indonesia Tengah (UTC+8)'),
            const SizedBox(height: 10),
            _tzItem('WIT', 'Waktu Indonesia Timur (UTC+9)'),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _tzItem(String code, String label) {
    final active = _timezoneLabel == code;
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        setState(() => _timezoneLabel = code);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: active ? _C.primary.withOpacity(0.15) : _C.cardSoft,
          borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 14),
          border: Border.all(
            color: active ? _C.primary : _C.border, width: 1.5,
          ),
        ),
        child: Row(
          children: [
            Icon(active ? Icons.radio_button_checked : Icons.radio_button_off,
              color: _C.primary, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(code, style: const TextStyle(
                    color: _C.text, fontSize: 15,
                    fontWeight: FontWeight.w900, letterSpacing: 1.5,
                  )),
                  Text(label, style: const TextStyle(color: _C.textSub, fontSize: 11)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBody: true,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Positioned.fill(
            child: ValueListenableBuilder<CustomBackgroundConfig>(
              valueListenable: CustomBackgroundManager.current,
              builder: (context, config, _) => config.path != null
                  ? const SizedBox.expand()
                  : _buildAuroraBackground(),
            ),
          ),

          SafeArea(
            bottom: false,
            child: FadeTransition(
              opacity: _pageFade,
              child: SlideTransition(
                position: _pageSlide,
                child: _body,
              ),
            ),
          ),

          Positioned(
            top: MediaQuery.of(context).padding.top + kToolbarHeight - 8,
            right: 4, width: 120, height: 160,
            child: const IgnorePointer(
              ignoring: true,
              child: SpongebobSticker(),
            ),
          ),

          // Persistent background-music toggle while the dashboard is open.
          const DashboardMusicControl(),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    final hh = _now.hour.toString().padLeft(2, '0');
    final mm = _now.minute.toString().padLeft(2, '0');

    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      toolbarHeight: 76,
      titleSpacing: 0,
      leadingWidth: 58,
      leading: Builder(
        builder: (ctx) => Padding(
          padding: const EdgeInsets.only(left: 14),
          child: _MenuBtn(onTap: () => Scaffold.of(ctx).openDrawer()),
        ),
      ),
      title: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: _C.card.withOpacity(0.72),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: _C.borderLit.withOpacity(0.45)),
          boxShadow: [
            BoxShadow(color: _C.purple.withOpacity(0.15),
              blurRadius: 24, spreadRadius: -4),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 34, height: 34,
              padding: const EdgeInsets.all(1.8),
              decoration: const BoxDecoration(
                shape: BoxShape.circle, gradient: _C.auroraGrad,
              ),
              child: ClipOval(
                child: _profileImage != null
                    ? Image.file(_profileImage!, fit: BoxFit.cover)
                    : _networkProfileUrl != null && _networkProfileUrl!.isNotEmpty
                        ? Image.network(_networkProfileUrl!, fit: BoxFit.cover)
                        : Container(
                            color: _C.surface,
                            child: Icon(_roleIcon(role), color: _roleColor(role), size: 16),
                          ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Halo $username 👋',
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white, fontSize: 13,
                      fontWeight: FontWeight.w800, letterSpacing: -0.2,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Container(
                        width: 6, height: 6,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle, color: _C.success,
                          boxShadow: [BoxShadow(color: _C.success.withOpacity(0.7), blurRadius: 6)],
                        ),
                      ),
                      const SizedBox(width: 5),
                      Text(role.toUpperCase(),
                        style: TextStyle(color: _roleColor(role), fontSize: 8.5,
                          fontWeight: FontWeight.w900, letterSpacing: 1),
                      ),
                      const SizedBox(width: 6),
                      Container(width: 1, height: 9, color: _C.borderLit.withOpacity(0.5)),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text('EXP $expiredDate',
                          maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: _C.textSub,
                            fontSize: 8.5, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: _showTimezonePicker,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  gradient: _C.neonGrad,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [BoxShadow(color: _C.purple.withOpacity(0.4), blurRadius: 10)],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.access_time_rounded, color: Colors.white, size: 11),
                    const SizedBox(width: 4),
                    Text('$hh:$mm',
                      style: const TextStyle(color: Colors.white, fontSize: 11,
                        fontWeight: FontWeight.w900, letterSpacing: 0.5),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      actions: [
        GestureDetector(
          onTap: _toggle3DNeo,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
            decoration: BoxDecoration(
              gradient: _is3DNeo ? _C.neonGrad : null,
              color: _is3DNeo ? null : _C.card.withOpacity(0.72),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(
                color: _is3DNeo ? _C.pink : _C.borderLit.withOpacity(0.45),
              ),
            ),
            child: Icon(Icons.view_in_ar_rounded,
              color: _is3DNeo ? Colors.white : _C.primary, size: 17),
          ),
        ),
        const SizedBox(width: 6),
        _AppBarIconBtn(
          icon: Icons.headset_mic_outlined,
          onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
          is3DNeo: _is3DNeo,
        ),
        _AppBarIconBtn(
          icon: Icons.account_circle_outlined,
          onTap: () async {
            await Navigator.push(context, _slideRoute(ProfilePage(
              username: username, password: password, role: role,
              expiredDate: expiredDate, sessionKey: sessionKey,
            )));
            _loadProfileImage();
            _fetchUserProfile();
          },
          is3DNeo: _is3DNeo,
        ),
        const SizedBox(width: 10),
      ],
    );
  }

  Widget _buildBottomNav() {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
        child: Container(
          height: 68,
          decoration: BoxDecoration(
            color: _C.card.withOpacity(0.94),
            borderRadius: BorderRadius.circular(26),
            border: Border.all(
              color: (_is3DNeo ? _C.pink : _C.borderLit).withOpacity(0.55),
              width: 1.3,
            ),
            boxShadow: [
              BoxShadow(color: _C.purple.withOpacity(0.28), blurRadius: 30,
                spreadRadius: -5, offset: const Offset(0, 10)),
              BoxShadow(color: _C.pink.withOpacity(0.10), blurRadius: 22, spreadRadius: -5),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(26),
            child: Stack(
              children: [
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 320),
                  curve: Curves.easeOutCubic,
                  left: (MediaQuery.of(context).size.width - 28) / 5 * _navIndex,
                  top: 8,
                  child: Container(
                    width: (MediaQuery.of(context).size.width - 28) / 5,
                    height: 52,
                    alignment: Alignment.center,
                    child: Container(
                      width: 52,
                      decoration: BoxDecoration(
                        gradient: _C.neonGrad,
                        borderRadius: BorderRadius.circular(18),
                        boxShadow: [
                          BoxShadow(color: _C.purple.withOpacity(0.55),
                            blurRadius: 18, spreadRadius: 1),
                          BoxShadow(color: _C.pink.withOpacity(0.3),
                            blurRadius: 24, spreadRadius: -2),
                        ],
                      ),
                    ),
                  ),
                ),
                Row(
                  children: [
                    _NavPillItem(icon: Icons.home_rounded, label: 'Beranda',
                      active: _navIndex == 0, onTap: () => _onNavTap(0)),
                    _NavPillItem(icon: Icons.grid_view_rounded, label: 'Menu',
                      active: _navIndex == 1, onTap: () => _onNavTap(1)),
                    _NavPillItem(icon: Icons.settings_remote_rounded, label: 'RAT',
                      active: _navIndex == 2, onTap: () => _onNavTap(2)),
                    _NavPillItem(icon: Icons.build_rounded, label: 'Tools',
                      active: _navIndex == 3, onTap: () => _onNavTap(3)),
                    _NavPillItem(icon: Icons.info_outline_rounded, label: 'Info',
                      active: _navIndex == 4, onTap: () => _onNavTap(4)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _showGlobalThemePicker() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (sheetContext) {
        final active = QaxerThemeManager.current.value;
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 42, height: 4,
                    decoration: BoxDecoration(
                      color: Theme.of(sheetContext).colorScheme.outline,
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Text('GLOBAL COLOR THEME', style: Theme.of(sheetContext).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800, letterSpacing: 0.5)),
                const SizedBox(height: 6),
                Text('Pilih palet warna untuk komponen aplikasi di semua halaman.', style: Theme.of(sheetContext).textTheme.bodyMedium),
                const SizedBox(height: 16),
                ...QaxerThemeManager.palettes.map((palette) {
                  final selected = active.id == palette.id;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 9),
                    child: Material(
                      color: selected ? palette.primary.withOpacity(0.13) : Theme.of(sheetContext).colorScheme.surfaceContainerHighest.withOpacity(0.45),
                      borderRadius: BorderRadius.circular(16),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () async {
                          await QaxerThemeManager.select(
                            palette,
                            sessionKey: sessionKey,
                            syncToServer: role.toLowerCase() == 'developer',
                          );
                          if (sheetContext.mounted) Navigator.pop(sheetContext);
                          if (mounted) {
                            final message = role.toLowerCase() == 'developer'
                                ? 'Tema ${palette.name} dipilih. Tampilan Material diperbarui; elemen custom mengikuti tema jika memakai warna tema.'
                                : 'Tema ${palette.name} diterapkan di perangkat ini';
                            ScaffoldMessenger.of(context)
                              ..hideCurrentSnackBar()
                              ..showSnackBar(SnackBar(content: Text(message)));
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                          child: Row(
                            children: [
                              Container(
                                width: 48, height: 38,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(colors: [palette.primary, palette.accent]),
                                  borderRadius: BorderRadius.circular(12),
                                  boxShadow: [BoxShadow(color: palette.primary.withOpacity(0.24), blurRadius: 12, offset: const Offset(0, 4))],
                                ),
                              ),
                              const SizedBox(width: 13),
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(palette.name, style: Theme.of(sheetContext).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
                                const SizedBox(height: 2),
                                Text(palette.description, style: Theme.of(sheetContext).textTheme.bodySmall),
                              ])),
                              if (selected) Icon(Icons.check_circle_rounded, color: palette.accent)
                              else Icon(Icons.radio_button_unchecked_rounded, color: Theme.of(sheetContext).colorScheme.outline),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.85,
      child: Container(
        decoration: BoxDecoration(
          color: _C.surface,
          border: Border(right: BorderSide(
            color: _C.borderLit.withOpacity(0.4), width: 1.5)),
          boxShadow: [
            BoxShadow(color: _C.purple.withOpacity(0.3),
              blurRadius: 40, offset: const Offset(4, 0)),
          ],
        ),
        child: Column(
          children: [
            _DrawerHeader(
              username: username, role: role, expiredDate: expiredDate,
              profileImage: _profileImage, is3DNeo: _is3DNeo,
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                children: [
                  _DrawerItem(
                    icon: Icons.account_circle_outlined,
                    label: 'My Profile', is3DNeo: _is3DNeo,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, _slideRoute(ProfilePage(
                        username: username, password: password, role: role,
                        expiredDate: expiredDate, sessionKey: sessionKey,
                      ))).then((_) {
                        _loadProfileImage();
                        _fetchUserProfile();
                      });
                    },
                  ),
                  const SizedBox(height: 8),
                  if (role == 'reseller')
                    _DrawerItem(icon: Icons.storefront_rounded, label: 'Seller Page',
                      is3DNeo: _is3DNeo, onTap: () => _onDrawerNav(1)),
                  if (role == 'admin')
                    _DrawerItem(icon: Icons.admin_panel_settings_rounded, label: 'Admin Page',
                      is3DNeo: _is3DNeo, onTap: () => _onDrawerNav(2)),
                  if (role == 'partner')
                    _DrawerItem(icon: Icons.workspace_premium_rounded, label: 'Partner Page',
                      is3DNeo: _is3DNeo, onTap: () => _onDrawerNav(3)),
                  if (role == 'owner')
                    _DrawerItem(icon: Icons.workspace_premium_rounded, label: 'Owner Page',
                      is3DNeo: _is3DNeo, onTap: () => _onDrawerNav(4)),
                  if (role == 'developer')
                    _DrawerItem(icon: Icons.workspace_premium_rounded, label: 'Developer Page',
                      is3DNeo: _is3DNeo, onTap: () => _onDrawerNav(5)),
                  const SizedBox(height: 8),
                  _DrawerItem(
                    icon: Icons.history_rounded, label: 'Riwayat Aktivitas', is3DNeo: _is3DNeo,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role)));
                    },
                  ),
                  const SizedBox(height: 8),
                  _DrawerItem(
                    icon: Icons.lock_outline_rounded, label: 'Ubah Password', is3DNeo: _is3DNeo,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, _slideRoute(ChangePasswordPage(
                        username: username, sessionKey: sessionKey,
                      )));
                    },
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: _DrawerItem(
                icon: Icons.palette_rounded,
                label: 'Tema & Warna Global',
                is3DNeo: _is3DNeo,
                onTap: () {
                  Navigator.pop(context);
                  Future<void>.delayed(const Duration(milliseconds: 120), _showGlobalThemePicker);
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: _DrawerItem(
                icon: Icons.wallpaper_rounded,
                label: 'Background Kustom',
                is3DNeo: _is3DNeo,
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/custom-background');
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              child: _DrawerItem(
                icon: Icons.logout_rounded, label: 'Keluar', isDestructive: true,
                is3DNeo: _is3DNeo,
                onTap: () async {
                  Navigator.pop(context);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  if (!mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (_) => false,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  PAINTERS
// ═══════════════════════════════════════════════════════════════════
class _AuroraGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _C.borderLit.withOpacity(0.08)
      ..strokeWidth = 0.6;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class HoneycombPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _C.borderLit.withOpacity(.06)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    const r = 24.0;
    final h = math.sqrt(3) * r;
    for (double y = 0; y < size.height + h; y += h) {
      for (double x = 0; x < size.width + r; x += r * 3) {
        final dx = ((y ~/ h).isEven) ? x : x + r * 1.5;
        final path = Path();
        for (int i = 0; i < 6; i++) {
          final angle = (60 * i - 30) * math.pi / 180;
          final px = dx + r * math.cos(angle);
          final py = y + r * math.sin(angle);
          if (i == 0) path.moveTo(px, py); else path.lineTo(px, py);
        }
        path.close();
        canvas.drawPath(path, paint);
      }
    }
  }
  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════════════
//  NAV PILL ITEM
// ═══════════════════════════════════════════════════════════════════
class _NavPillItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _NavPillItem({
    required this.icon, required this.label,
    required this.active, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedScale(
                scale: active ? 1.15 : 1.0,
                duration: const Duration(milliseconds: 260),
                curve: Curves.easeOutCubic,
                child: Icon(icon, size: 20,
                  color: active ? Colors.white : _C.textSub),
              ),
              const SizedBox(height: 3),
              AnimatedOpacity(
                duration: const Duration(milliseconds: 260),
                opacity: active ? 1 : 0.7,
                child: Text(label,
                  style: TextStyle(
                    color: active ? _C.text : _C.textDim,
                    fontSize: 9,
                    fontWeight: active ? FontWeight.w800 : FontWeight.w600,
                    letterSpacing: 0.2,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  Mortix MOVING BUTTON
// ═══════════════════════════════════════════════════════════════════
class _XSpyderMovingButton extends StatefulWidget {
  final bool is3DNeo;
  final VoidCallback onTap;

  const _XSpyderMovingButton({required this.is3DNeo, required this.onTap});

  @override
  State<_XSpyderMovingButton> createState() => _XSpyderMovingButtonState();
}

class _XSpyderMovingButtonState extends State<_XSpyderMovingButton>
    with TickerProviderStateMixin {
  late AnimationController _textCtrl, _borderCtrl, _glowCtrl;

  @override
  void initState() {
    super.initState();
    _textCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 3000))..repeat();
    _borderCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 4000))..repeat();
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _textCtrl.dispose();
    _borderCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: Listenable.merge([_textCtrl, _borderCtrl, _glowCtrl]),
        builder: (context, _) {
          final rotate = _borderCtrl.value;
          final glow = _glowCtrl.value;
          final textSweep = _textCtrl.value;

          return Container(
            height: 62,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 18),
              boxShadow: [
                BoxShadow(color: _C.purple.withOpacity(0.4 + glow * 0.3),
                  blurRadius: 20 + glow * 16, spreadRadius: 2, offset: const Offset(0, 6)),
                BoxShadow(color: _C.pink.withOpacity(0.2 + glow * 0.2),
                  blurRadius: 30, spreadRadius: -2),
              ],
            ),
            child: Stack(
              children: [
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 18),
                      gradient: SweepGradient(
                        transform: GradientRotation(rotate * 2 * math.pi),
                        colors: const [
                          Color(0xFF9B6DFF), Color(0xFF8B5CF6),
                          Color(0xFF8B5CF6), Color(0xFF9B6DFF),
                          Color(0xFFB79CFF), Color(0xFF9B6DFF),
                        ],
                      ),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: Container(
                    margin: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      color: _C.card,
                      borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 15),
                    ),
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.security_rounded, color: _C.accent, size: 22),
                          const SizedBox(width: 12),
                          ShaderMask(
                            shaderCallback: (bounds) => LinearGradient(
                              begin: Alignment(-1.0 + textSweep * 2, 0.0),
                              end: Alignment(1.0 + textSweep * 2, 0.0),
                              colors: const [
                                Color(0xFF8B5CF6), Color(0xFF9B6DFF),
                                Color(0xFFF8FAFF), Color(0xFF8B5CF6),
                                Color(0xFF8B5CF6),
                              ],
                              stops: const [0.0, 0.3, 0.5, 0.7, 1.0],
                            ).createShader(bounds),
                            child: const Text('Mortix',
                              style: TextStyle(
                                color: Colors.white, fontSize: 22,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Qaxer', letterSpacing: 6,
                                shadows: [Shadow(color: Color(0xFF8B5CF6), blurRadius: 10)],
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Icon(Icons.arrow_forward_ios_rounded, color: _C.accent, size: 14),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  ANALOG CLOCK
// ═══════════════════════════════════════════════════════════════════
class _AnalogClock extends StatelessWidget {
  final DateTime now;
  final String timezoneLabel;
  final VoidCallback onTap;
  final bool is3DNeo;

  const _AnalogClock({
    required this.now, required this.timezoneLabel,
    required this.onTap, required this.is3DNeo,
  });

  @override
  Widget build(BuildContext context) {
    const size = 78.0;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: is3DNeo ? BoxShape.rectangle : BoxShape.circle,
          borderRadius: is3DNeo ? BorderRadius.circular(6) : null,
          gradient: const LinearGradient(
            colors: [Color(0xFF1A1F42), Color(0xFF0E1124)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          border: Border.all(color: _C.borderLit, width: 2),
          boxShadow: [
            BoxShadow(color: _C.info.withOpacity(0.5), blurRadius: 18, spreadRadius: 1),
            BoxShadow(color: _C.purple.withOpacity(0.4), blurRadius: 24, spreadRadius: -2),
          ],
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            CustomPaint(size: const Size(size, size), painter: _ClockPainter(now)),
            Positioned(
              bottom: 4,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(
                  gradient: _C.neonGrad,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(timezoneLabel,
                  style: const TextStyle(color: Colors.white, fontSize: 7,
                    fontWeight: FontWeight.w900, letterSpacing: 0.8),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ClockPainter extends CustomPainter {
  final DateTime time;
  _ClockPainter(this.time);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 6;

    for (int i = 1; i <= 12; i++) {
      final angle = (i * 30 - 90) * math.pi / 180;
      final x = center.dx + (radius - 10) * math.cos(angle);
      final y = center.dy + (radius - 10) * math.sin(angle);
      if (i % 3 == 0) {
        final tp2 = TextPainter(
          text: TextSpan(text: '$i',
            style: const TextStyle(color: _C.text, fontSize: 8, fontWeight: FontWeight.w900),
          ),
          textDirection: TextDirection.ltr,
        )..layout();
        tp2.paint(canvas, Offset(x - tp2.width / 2, y - tp2.height / 2));
      }
    }

    canvas.drawCircle(center, 3.5, Paint()..color = _C.borderLit);

    final hourAngle = ((time.hour % 12) * 30 + time.minute * 0.5 - 90) * math.pi / 180;
    canvas.drawLine(center, Offset(
      center.dx + (radius * 0.5) * math.cos(hourAngle),
      center.dy + (radius * 0.5) * math.sin(hourAngle),
    ), Paint()..color = _C.primary..strokeWidth = 3.5..strokeCap = StrokeCap.round);

    final minAngle = (time.minute * 6 + time.second * 0.1 - 90) * math.pi / 180;
    canvas.drawLine(center, Offset(
      center.dx + (radius * 0.72) * math.cos(minAngle),
      center.dy + (radius * 0.72) * math.sin(minAngle),
    ), Paint()..color = _C.pink..strokeWidth = 2.2..strokeCap = StrokeCap.round);

    final secAngle = (time.second * 6 - 90) * math.pi / 180;
    canvas.drawLine(center, Offset(
      center.dx + (radius * 0.82) * math.cos(secAngle),
      center.dy + (radius * 0.82) * math.sin(secAngle),
    ), Paint()..color = _C.accent..strokeWidth = 1..strokeCap = StrokeCap.round);
  }

  @override
  bool shouldRepaint(_ClockPainter old) => old.time.second != time.second;
}

// ═══════════════════════════════════════════════════════════════════
//  NEWS CARD
// ═══════════════════════════════════════════════════════════════════
class _NewsCard extends StatelessWidget {
  final dynamic item;
  final bool isActive;
  const _NewsCard({required this.item, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(_C.rLg),
        border: Border.all(
          color: isActive ? _C.borderLit : _C.border.withOpacity(0.5),
          width: isActive ? 2 : 1,
        ),
        boxShadow: isActive
            ? [
                BoxShadow(color: _C.purple.withOpacity(0.45), blurRadius: 30,
                  spreadRadius: 2, offset: const Offset(0, 12)),
                BoxShadow(color: _C.info.withOpacity(0.25), blurRadius: 22, spreadRadius: -2),
              ]
            : [],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(_C.rLg),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (item['image'] != null && item['image'].toString().isNotEmpty)
              NewsMedia(url: item['image']),
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xF0080F2C), Color(0x00080F2C)],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  stops: [0.0, 0.85],
                ),
              ),
            ),
            Positioned(
              top: 14, left: 14,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  gradient: _C.auroraGrad,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [BoxShadow(color: _C.purple.withOpacity(0.5), blurRadius: 12)],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.bolt_rounded, color: Colors.white, size: 11),
                    SizedBox(width: 3),
                    Text("NEWS",
                      style: TextStyle(color: Colors.white, fontSize: 9,
                        fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                  ],
                ),
              ),
            ),
            Positioned(
              top: 16, right: 14,
              child: Container(
                width: 8, height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle, color: _C.success,
                  boxShadow: [BoxShadow(color: _C.success.withOpacity(0.7),
                    blurRadius: 8, spreadRadius: 1)],
                ),
              ),
            ),
            Positioned(
              bottom: 18, left: 18, right: 18,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item['title'] ?? 'No Title',
                    style: const TextStyle(
                      color: Colors.white, fontSize: 16,
                      fontWeight: FontWeight.w700, height: 1.3, letterSpacing: 0.3,
                    ),
                    maxLines: 2, overflow: TextOverflow.ellipsis,
                  ),
                  if (item['desc'] != null && item['desc'].toString().isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(item['desc'],
                      style: const TextStyle(
                        color: Colors.white70, fontSize: 11, height: 1.4,
                      ),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  QUICK ACTION GRID CARD
// ═══════════════════════════════════════════════════════════════════
class _QuickActionGridCard extends StatefulWidget {
  final Map<String, dynamic> data;
  final bool is3DNeo;
  final int index;
  const _QuickActionGridCard({
    required this.data, this.is3DNeo = false, this.index = 0,
  });

  @override
  State<_QuickActionGridCard> createState() => _QuickActionGridCardState();
}

class _QuickActionGridCardState extends State<_QuickActionGridCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _shimmerCtrl;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 2200 + (widget.index * 180) % 1400),
    )..repeat();
  }

  @override
  void dispose() { _shimmerCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final color = widget.data["color"] as Color;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        HapticFeedback.lightImpact();
        (widget.data["onTap"] as VoidCallback)();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 140),
        curve: Curves.easeOut,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : _C.rMd),
            gradient: LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [_C.card, Color.lerp(_C.card, color, 0.18)!],
            ),
            border: Border.all(color: color.withOpacity(0.45), width: 1.6),
            boxShadow: widget.is3DNeo
                ? [BoxShadow(color: color.withOpacity(0.6),
                    offset: const Offset(5, 5), blurRadius: 0)]
                : [BoxShadow(color: color.withOpacity(0.22),
                    blurRadius: 18, spreadRadius: -4, offset: const Offset(0, 8))],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : _C.rMd),
            child: Stack(
              children: [
                Positioned(
                  top: -34, right: -34,
                  child: Container(
                    width: 120, height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(colors: [
                        color.withOpacity(0.35), color.withOpacity(0.0),
                      ]),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: CustomPaint(painter: _CardGridPainter(color: color)),
                ),
                Positioned(
                  top: 0, left: 0, right: 0,
                  child: AnimatedBuilder(
                    animation: _shimmerCtrl,
                    builder: (context, _) => Align(
                      alignment: Alignment(-1.2 + _shimmerCtrl.value * 2.4, 0),
                      child: Container(
                        height: 2, width: 60,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [
                            Colors.transparent, color, Colors.transparent,
                          ]),
                          boxShadow: [BoxShadow(color: color.withOpacity(0.85), blurRadius: 10)],
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 44, height: 44,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [color, Color.lerp(color, _C.purple, 0.55)!],
                                begin: Alignment.topLeft, end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 14),
                              boxShadow: [
                                BoxShadow(color: color.withOpacity(0.55),
                                  blurRadius: 12, spreadRadius: 0.5),
                              ],
                            ),
                            child: Icon(widget.data["icon"], color: Colors.white, size: 22),
                          ),
                          const Spacer(),
                          Container(
                            width: 28, height: 28,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: color.withOpacity(0.15),
                              border: Border.all(color: color.withOpacity(0.55), width: 1.2),
                            ),
                            child: Icon(Icons.arrow_outward_rounded, color: color, size: 14),
                          ),
                        ],
                      ),
                      const Spacer(),
                      Text(widget.data["title"],
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: _C.text, fontSize: 15,
                          fontWeight: FontWeight.w800, letterSpacing: 0.2),
                      ),
                      const SizedBox(height: 4),
                      Text(widget.data["subtitle"],
                        maxLines: 2, overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: _C.textSub.withOpacity(0.85),
                          fontSize: 10.5, height: 1.35, fontWeight: FontWeight.w500),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CardGridPainter extends CustomPainter {
  final Color color;
  _CardGridPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.08)
      ..strokeWidth = 0.6;
    const step = 18.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }
  @override
  bool shouldRepaint(_CardGridPainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════════════
//  CREATOR CARD
// ═══════════════════════════════════════════════════════════════════
class _CreatorCard extends StatefulWidget {
  final String username, role, tagline, avatarAsset;
  final Color accentColor;
  final bool is3DNeo;

  const _CreatorCard({
    required this.username, required this.role, required this.tagline,
    required this.avatarAsset, required this.accentColor,
    this.is3DNeo = false,
  });

  @override
  State<_CreatorCard> createState() => _CreatorCardState();
}

class _CreatorCardState extends State<_CreatorCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseCtrl;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
  }

  @override
  void dispose() { _pulseCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final color = widget.accentColor;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 140),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : _C.rMd),
            gradient: LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [_C.card, Color.lerp(_C.card, color, 0.15)!],
            ),
            border: Border.all(color: color.withOpacity(0.5), width: 1.6),
            boxShadow: widget.is3DNeo
                ? [BoxShadow(color: color.withOpacity(0.6),
                    offset: const Offset(5, 5), blurRadius: 0)]
                : [BoxShadow(color: color.withOpacity(0.25),
                    blurRadius: 20, spreadRadius: -4, offset: const Offset(0, 10))],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : _C.rMd),
            child: Stack(
              children: [
                Positioned(
                  top: -20, right: -20,
                  child: AnimatedBuilder(
                    animation: _pulseCtrl,
                    builder: (context, _) {
                      return Container(
                        width: 100 + _pulseCtrl.value * 20,
                        height: 100 + _pulseCtrl.value * 20,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(colors: [
                            color.withOpacity(0.30), color.withOpacity(0.0),
                          ]),
                        ),
                      );
                    },
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          width: 74, height: 74,
                          padding: const EdgeInsets.all(2.5),
                          decoration: BoxDecoration(
                            shape: widget.is3DNeo ? BoxShape.rectangle : BoxShape.circle,
                            borderRadius: widget.is3DNeo ? BorderRadius.circular(8) : null,
                            gradient: LinearGradient(
                              colors: [color, Color.lerp(color, _C.purple, 0.5)!],
                              begin: Alignment.topLeft, end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(color: color.withOpacity(0.55),
                                blurRadius: widget.is3DNeo ? 0 : 16, spreadRadius: 1,
                                offset: widget.is3DNeo ? const Offset(3, 3) : Offset.zero),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(widget.is3DNeo ? 6 : 100),
                            child: Container(
                              color: _C.surface,
                              child: Image.asset(
                                widget.avatarAsset,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Center(
                                  child: Icon(_roleIcon(widget.role), color: color, size: 34),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          right: -2, bottom: -2,
                          child: Container(
                            width: 22, height: 22,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: _C.neonGrad,
                              border: Border.all(color: _C.card, width: 2),
                              boxShadow: [BoxShadow(color: color.withOpacity(0.6), blurRadius: 8)],
                            ),
                            child: const Icon(Icons.verified_rounded,
                              color: Colors.white, size: 11),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(widget.username,
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: _C.text, fontSize: 14,
                        fontWeight: FontWeight.w800, letterSpacing: 0.3),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.18),
                        borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 20),
                        border: Border.all(color: color.withOpacity(0.7), width: 1.3),
                      ),
                      child: Text(widget.role.toUpperCase(),
                        style: TextStyle(color: color, fontSize: 9.5,
                          fontWeight: FontWeight.w900, letterSpacing: 1.2),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(widget.tagline,
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: _C.textSub.withOpacity(0.85),
                        fontSize: 10, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  THANKS CARD
// ═══════════════════════════════════════════════════════════════════
class _ThanksCard extends StatelessWidget {
  final String username, role, link;
  final bool is3DNeo;

  const _ThanksCard({
    required this.username, required this.role,
    required this.link, this.is3DNeo = false,
  });

  Future<void> _openUrl() async {
    if (link.isEmpty) return;
    try {
      await launchUrl(Uri.parse(link), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _openUrl,
      child: Container(
        width: 122, height: 132,
        padding: const EdgeInsets.all(1.6),
        decoration: BoxDecoration(
          gradient: _C.auroraGrad,
          borderRadius: BorderRadius.circular(is3DNeo ? 0 : 22),
          boxShadow: [
            BoxShadow(color: _C.purple.withOpacity(0.4), blurRadius: 20,
              offset: const Offset(0, 8), spreadRadius: -2),
          ],
        ),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(is3DNeo ? 0 : 20),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 46, height: 46,
                    padding: const EdgeInsets.all(2),
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle, gradient: _C.auroraGrad,
                    ),
                    child: Container(
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle, color: _C.surface,
                      ),
                      child: const Icon(Icons.person_rounded, color: _C.text, size: 22),
                    ),
                  ),
                  Positioned(
                    right: -2, bottom: -2,
                    child: Container(
                      width: 14, height: 14,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle, color: _C.success,
                        border: Border.all(color: _C.card, width: 2),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(username,
                maxLines: 1, overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(color: _C.text, fontSize: 12.5,
                  fontWeight: FontWeight.w900, letterSpacing: -0.2),
              ),
              const SizedBox(height: 3),
              Text(role.toUpperCase(),
                maxLines: 1, overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(color: _C.textSub, fontSize: 8.5,
                  fontWeight: FontWeight.w700, letterSpacing: 0.8),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                decoration: BoxDecoration(
                  gradient: _C.neonGrad,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.open_in_new_rounded, color: Colors.white, size: 9),
                    SizedBox(width: 3),
                    Text("Visit",
                      style: TextStyle(color: Colors.white, fontSize: 9,
                        fontWeight: FontWeight.w800, letterSpacing: 0.3),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  QAXER TEAM CARD
// ═══════════════════════════════════════════════════════════════════
class _QaxerTeamCard extends StatelessWidget {
  final bool is3DNeo;
  const _QaxerTeamCard({this.is3DNeo = false});

  Future<void> _openUrl(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A1F42), Color(0xFF141833)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(is3DNeo ? 0 : _C.rLg),
        border: Border.all(color: _C.borderLit.withOpacity(0.5), width: 1.5),
        boxShadow: [
          BoxShadow(color: _C.purple.withOpacity(0.32),
            blurRadius: 26, offset: const Offset(0, 12), spreadRadius: -2),
          BoxShadow(color: _C.pink.withOpacity(0.15),
            blurRadius: 32, spreadRadius: -4),
        ],
      ),
      child: Column(
        children: [
          ShaderMask(
            shaderCallback: (bounds) => _C.auroraGrad.createShader(bounds),
            child: const Text("Mortix",
              style: TextStyle(
                color: Colors.white, fontSize: 26,
                fontWeight: FontWeight.w900, letterSpacing: 6,
              ),
            ),
          ),
          const SizedBox(height: 4),
          const Text("CONNECT WITH US",
            style: TextStyle(color: _C.textSub, fontSize: 10,
              fontWeight: FontWeight.w700, letterSpacing: 2.5),
          ),
          const SizedBox(height: 22),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _SocialItem(
                icon: FontAwesomeIcons.telegram, color: const Color(0xFF29B6F6),
                title: "Telegram", is3DNeo: is3DNeo,
                onTap: () => _openUrl("https://t.me/vinzzsukakmu"),
              ),
              _SocialItem(
                icon: FontAwesomeIcons.whatsapp, color: const Color(0xFF25D366),
                title: "WhatsApp", is3DNeo: is3DNeo,
                onTap: () => _openUrl("https://wa.me/"),
              ),
              _SocialItem(
                icon: FontAwesomeIcons.tiktok, color: _C.text,
                title: "TikTok", is3DNeo: is3DNeo,
                onTap: () => _openUrl("https://tiktok.com/@kyybutnow"),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: _C.surface.withOpacity(0.6),
              borderRadius: BorderRadius.circular(is3DNeo ? 0 : 30),
              border: Border.all(color: _C.borderLit.withOpacity(0.3)),
            ),
            child: const Text("Always stay tuned for the latest projects ✨",
              style: TextStyle(color: _C.textSub, fontSize: 11,
                fontWeight: FontWeight.w600, letterSpacing: 0.3),
            ),
          ),
        ],
      ),
    );
  }
}

class _SocialItem extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final VoidCallback onTap;
  final bool is3DNeo;

  const _SocialItem({
    required this.icon, required this.color,
    required this.title, required this.onTap,
    this.is3DNeo = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(is3DNeo ? 0 : 18),
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              shape: is3DNeo ? BoxShape.rectangle : BoxShape.circle,
              borderRadius: is3DNeo ? BorderRadius.circular(8) : null,
              gradient: RadialGradient(
                colors: [color.withOpacity(.25), color.withOpacity(.08)],
              ),
              border: Border.all(color: color.withOpacity(0.5), width: 1.5),
              boxShadow: [
                BoxShadow(color: color.withOpacity(.5),
                  blurRadius: 20, spreadRadius: 1),
              ],
            ),
            child: Center(child: FaIcon(icon, color: color, size: 30)),
          ),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  PRAYER CARD
// ═══════════════════════════════════════════════════════════════════
class _PrayerCard extends StatelessWidget {
  final Map<String, dynamic>? data;
  final bool loading;
  final String city;
  final Future<void> Function(String) onChange;
  final bool is3DNeo;

  const _PrayerCard({
    super.key, required this.data, required this.loading,
    required this.city, required this.onChange, this.is3DNeo = false,
  });

  @override
  Widget build(BuildContext context) {
    if (loading || data == null) {
      return Container(
        height: 320,
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(is3DNeo ? 0 : _C.rLg),
          border: Border.all(color: _C.border, width: 1.5),
        ),
        child: const Center(child: CircularProgressIndicator(color: _C.primary, strokeWidth: 3)),
      );
    }

    final jadwal = data!["waktu"];
    final now = TimeOfDay.now();

    final prayers = <Map<String, String>>[
      {"name": "Subuh", "time": jadwal["Fajr"]},
      {"name": "Dzuhur", "time": jadwal["Dhuhr"]},
      {"name": "Ashar", "time": jadwal["Asr"]},
      {"name": "Maghrib", "time": jadwal["Maghrib"]},
      {"name": "Isya", "time": jadwal["Isha"]},
    ];

    String nextName = prayers.first["name"]!;
    String nextTime = prayers.first["time"]!;
    for (final p in prayers) {
      final split = p["time"]!.split(":");
      final h = int.parse(split[0]);
      final m = int.parse(split[1]);
      if (h > now.hour || (h == now.hour && m > now.minute)) {
        nextName = p["name"]!;
        nextTime = p["time"]!;
        break;
      }
    }

    return Container(
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(is3DNeo ? 0 : _C.rLg),
        border: Border.all(color: _C.borderLit.withOpacity(0.5), width: 1.5),
        boxShadow: [
          BoxShadow(color: _C.success.withOpacity(0.3), blurRadius: 24,
            spreadRadius: 1, offset: const Offset(0, 10)),
          BoxShadow(color: _C.info.withOpacity(0.15), blurRadius: 30, spreadRadius: -4),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(is3DNeo ? 0 : _C.rLg),
        child: CustomPaint(
          painter: HoneycombPainter(),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    SizedBox(
                      width: 58, height: 58,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          const SizedBox(
                            width: 58, height: 58,
                            child: CircularProgressIndicator(
                              value: 0.72, strokeWidth: 4,
                              backgroundColor: _C.surface,
                              valueColor: AlwaysStoppedAnimation(Color(0xFFB79CFF)),
                            ),
                          ),
                          Container(
                            width: 44, height: 44,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle, gradient: _C.auroraGrad,
                            ),
                            child: const Icon(Icons.mosque_rounded, color: Colors.white, size: 22),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Prayer Times",
                            style: TextStyle(color: _C.text,
                              fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 0.5),
                          ),
                          const SizedBox(height: 3),
                          Row(
                            children: [
                              const Icon(Icons.location_on_rounded, color: _C.primary, size: 11),
                              const SizedBox(width: 3),
                              Expanded(
                                child: Text(data!["lokasi"] ?? city,
                                  maxLines: 1, overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(color: _C.textSub, fontSize: 11),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        gradient: _C.auroraGrad,
                        borderRadius: BorderRadius.circular(is3DNeo ? 0 : 30),
                        boxShadow: [BoxShadow(color: _C.pink.withOpacity(0.5), blurRadius: 12)],
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(width: 5, height: 5,
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle, color: Colors.white,
                              ),
                            ),
                          ),
                          SizedBox(width: 4),
                          Text("LIVE",
                            style: TextStyle(fontSize: 10, color: Colors.white,
                              fontWeight: FontWeight.bold, letterSpacing: 1),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(is3DNeo ? 0 : 18),
                    gradient: _C.auroraGrad,
                    boxShadow: [BoxShadow(color: _C.purple.withOpacity(0.4),
                      blurRadius: 20, spreadRadius: 1)],
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.schedule_rounded, color: Colors.white),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text("$nextName - $nextTime",
                          style: const TextStyle(color: Colors.white, fontSize: 14,
                            fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  height: 132,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    children: [
                      _PrayerItem(title: "SUBUH", time: jadwal["Fajr"],
                        icon: Icons.nightlight_round,
                        colors: const [Color(0xff7C3AED), Color(0xff4A42D4)], is3DNeo: is3DNeo),
                      const SizedBox(width: 12),
                      _PrayerItem(title: "DZUHUR", time: jadwal["Dhuhr"],
                        icon: Icons.wb_sunny_rounded,
                        colors: const [Color(0xffFFB300), Color(0xffF57C00)], is3DNeo: is3DNeo),
                      const SizedBox(width: 12),
                      _PrayerItem(title: "ASHAR", time: jadwal["Asr"],
                        icon: Icons.cloud,
                        colors: const [Color(0xffFF7043), Color(0xffF4511E)], is3DNeo: is3DNeo),
                      const SizedBox(width: 12),
                      _PrayerItem(title: "MAGHRIB", time: jadwal["Maghrib"],
                        icon: Icons.nights_stay,
                        colors: const [Color(0xffEC407A), Color(0xffC2185B)], is3DNeo: is3DNeo),
                      const SizedBox(width: 12),
                      _PrayerItem(title: "ISYA", time: jadwal["Isha"],
                        icon: Icons.dark_mode,
                        colors: const [Color(0xff5C6BC0), Color(0xff3949AB)], is3DNeo: is3DNeo),
                      const SizedBox(width: 12),
                      _PrayerItem(title: "SUNRISE", time: jadwal["Sunrise"],
                        icon: Icons.wb_twilight,
                        colors: const [Color(0xff26A69A), Color(0xff00897B)], is3DNeo: is3DNeo),
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                InkWell(
                  borderRadius: BorderRadius.circular(is3DNeo ? 0 : 30),
                  onTap: () async {
                    final controller = TextEditingController();
                    final result = await showDialog<String>(
                      context: context,
                      builder: (_) => AlertDialog(
                        backgroundColor: _C.surface,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(is3DNeo ? 0 : 20),
                          side: BorderSide(color: _C.borderLit, width: 2),
                        ),
                        title: const Text("Ganti Kota", style: TextStyle(color: _C.text)),
                        content: TextField(
                          controller: controller,
                          style: const TextStyle(color: _C.text),
                          decoration: const InputDecoration(
                            hintText: "Contoh: Yogyakarta",
                            hintStyle: TextStyle(color: _C.textDim),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: _C.border),
                              borderRadius: BorderRadius.all(Radius.circular(12)),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: _C.primary, width: 2),
                              borderRadius: BorderRadius.all(Radius.circular(12)),
                            ),
                          ),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text("Batal", style: TextStyle(color: _C.textSub)),
                          ),
                          ElevatedButton(
                            onPressed: () => Navigator.pop(context, controller.text.trim()),
                            style: ElevatedButton.styleFrom(backgroundColor: _C.primary),
                            child: const Text("Simpan"),
                          ),
                        ],
                      ),
                    );
                    if (result != null && result.isNotEmpty) {
                      await onChange(result);
                    }
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(city, style: const TextStyle(color: _C.textSub, fontWeight: FontWeight.w700)),
                      const SizedBox(width: 4),
                      const Icon(Icons.edit_location_alt_rounded, color: _C.primary, size: 18),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PrayerItem extends StatelessWidget {
  final String title, time;
  final IconData icon;
  final List<Color> colors;
  final bool is3DNeo;

  const _PrayerItem({
    required this.title, required this.time,
    required this.icon, required this.colors,
    this.is3DNeo = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 105, height: 125,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: colors),
        borderRadius: BorderRadius.circular(is3DNeo ? 0 : 18),
        border: is3DNeo ? Border.all(color: _C.border, width: 1.5) : null,
        boxShadow: [
          BoxShadow(color: colors.first.withOpacity(.5),
            blurRadius: 16, spreadRadius: 1, offset: const Offset(0, 6)),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const Spacer(),
            Text(title, style: const TextStyle(color: Colors.white70,
              fontWeight: FontWeight.w600, fontSize: 10)),
            const SizedBox(height: 3),
            Text(time, style: const TextStyle(color: Colors.white,
              fontWeight: FontWeight.bold, fontSize: 20, height: 1)),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DOA CARD
// ═══════════════════════════════════════════════════════════════════
class _DoaCard extends StatelessWidget {
  final Map<String, dynamic>? data;
  final bool loading;
  final bool is3DNeo;

  const _DoaCard({required this.data, required this.loading, this.is3DNeo = false});

  void _copy(BuildContext context, String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Copied"), duration: Duration(seconds: 1)),
    );
  }

  void _showDoaDetail(BuildContext context) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: "",
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 320),
      pageBuilder: (_, __, ___) {
        return SafeArea(
          child: Center(
            child: Material(
              color: Colors.transparent,
              child: Container(
                width: double.infinity,
                height: MediaQuery.of(context).size.height * .92,
                margin: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _C.card,
                  borderRadius: BorderRadius.circular(is3DNeo ? 0 : 28),
                  border: Border.all(color: _C.borderLit, width: 2),
                  boxShadow: [BoxShadow(color: _C.purple.withOpacity(0.4), blurRadius: 40)],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: const BoxDecoration(
                        gradient: _C.auroraGrad,
                        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                      ),
                      child: Row(
                        children: [
                          const Expanded(
                            child: Text("DOA OF THE DAY",
                              style: TextStyle(color: Colors.white,
                                fontWeight: FontWeight.bold, fontSize: 18),
                            ),
                          ),
                          IconButton(
                            onPressed: () => Navigator.pop(context),
                            icon: const Icon(Icons.close, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(data!["doa"],
                              style: const TextStyle(color: _C.text,
                                fontSize: 22, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 20),
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(18),
                              decoration: BoxDecoration(
                                color: _C.surface,
                                borderRadius: BorderRadius.circular(is3DNeo ? 0 : 18),
                                border: Border.all(color: _C.borderLit, width: 1.5),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(data!["ayat"],
                                    textAlign: TextAlign.right,
                                    style: const TextStyle(color: _C.text,
                                      fontSize: 26, height: 2),
                                  ),
                                  const SizedBox(height: 15),
                                  ElevatedButton.icon(
                                    onPressed: () => _copy(context, data!["ayat"]),
                                    style: ElevatedButton.styleFrom(backgroundColor: _C.primary),
                                    icon: const Icon(Icons.copy, color: Colors.white),
                                    label: const Text("Copy Ayat", style: TextStyle(color: Colors.white)),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 20),
                            const Text("Artinya",
                              style: TextStyle(color: _C.text, fontSize: 17,
                                fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 10),
                            Text(data!["artinya"],
                              style: const TextStyle(color: _C.textSub,
                                fontSize: 16, height: 1.8),
                            ),
                            const SizedBox(height: 15),
                            ElevatedButton.icon(
                              onPressed: () => _copy(context, data!["artinya"]),
                              style: ElevatedButton.styleFrom(backgroundColor: _C.primary),
                              icon: const Icon(Icons.copy, color: Colors.white),
                              label: const Text("Copy Arti", style: TextStyle(color: Colors.white)),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (_, animation, __, child) {
        return FadeTransition(
          opacity: animation,
          child: ScaleTransition(
            scale: Tween(begin: .94, end: 1.0)
                .animate(CurvedAnimation(parent: animation, curve: Curves.easeOut)),
            child: child,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Container(
        height: 220,
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(is3DNeo ? 0 : _C.rLg),
          border: Border.all(color: _C.border, width: 1.5),
        ),
        child: const Center(child: CircularProgressIndicator(color: _C.primary, strokeWidth: 3)),
      );
    }
    if (data == null) return const SizedBox();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(is3DNeo ? 0 : _C.rLg),
        border: Border.all(color: _C.borderLit.withOpacity(0.5), width: 1.5),
        boxShadow: [
          BoxShadow(color: _C.pink.withOpacity(0.3), blurRadius: 24,
            spreadRadius: 1, offset: const Offset(0, 10)),
          BoxShadow(color: _C.purple.withOpacity(0.15), blurRadius: 30, spreadRadius: -4),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  gradient: _C.auroraGrad,
                  borderRadius: BorderRadius.circular(is3DNeo ? 0 : 18),
                  boxShadow: [BoxShadow(color: _C.pink.withOpacity(0.5), blurRadius: 14)],
                ),
                child: const Icon(Icons.menu_book_rounded, color: Colors.white),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("DOA OF THE DAY",
                      style: TextStyle(color: _C.text,
                        fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 1),
                    ),
                    const SizedBox(height: 3),
                    Text(data!["doa"], maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: _C.textSub, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(is3DNeo ? 0 : 16),
              border: Border.all(color: _C.borderLit, width: 1.5),
            ),
            child: Text(data!["ayat"],
              textAlign: TextAlign.right,
              maxLines: 3, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _C.text, fontSize: 18, height: 1.6),
            ),
          ),
          const SizedBox(height: 14),
          Text(data!["artinya"], maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _C.textSub, fontSize: 14,
              height: 1.4, fontStyle: FontStyle.italic),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  gradient: _C.auroraGrad,
                  borderRadius: BorderRadius.circular(is3DNeo ? 0 : 12),
                ),
                child: Text("Doa #${data!["id"]}",
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                ),
              ),
              const Spacer(),
              InkWell(
                onTap: () => _showDoaDetail(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _C.primary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.borderLit),
                  ),
                  child: const Text("TAP",
                    style: TextStyle(color: _C.primary, fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DRAWER HEADER
// ═══════════════════════════════════════════════════════════════════
class _DrawerHeader extends StatelessWidget {
  final String username, role, expiredDate;
  final File? profileImage;
  final bool is3DNeo;

  const _DrawerHeader({
    required this.username, required this.role,
    required this.expiredDate, required this.profileImage,
    this.is3DNeo = false,
  });

  @override
  Widget build(BuildContext context) {
    final rColor = _roleColor(role);
    return Container(
      height: 258,
      clipBehavior: Clip.hardEdge,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A1F42), Color(0xFF0E1124)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        border: Border(bottom: BorderSide(
          color: _C.borderLit.withOpacity(0.5), width: 1.5)),
      ),
      child: Stack(
        children: [
          Positioned(top: -50, right: -50,
            child: Container(width: 220, height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  _C.purple.withOpacity(0.55), Colors.transparent,
                ]),
              ),
            ),
          ),
          Positioned(bottom: -70, left: -70,
            child: Container(width: 240, height: 240,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  _C.info.withOpacity(0.45), Colors.transparent,
                ]),
              ),
            ),
          ),
          Positioned.fill(
            child: CustomPaint(painter: _AuroraGridPainter()),
          ),
          Positioned.fill(
            child: SafeArea(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Container(
                        width: 84, height: 84,
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: is3DNeo ? BoxShape.rectangle : BoxShape.circle,
                          borderRadius: is3DNeo ? BorderRadius.circular(10) : null,
                          gradient: _C.auroraGrad,
                          boxShadow: [
                            BoxShadow(color: rColor.withOpacity(0.55),
                              blurRadius: 26, spreadRadius: 2),
                            BoxShadow(color: _C.purple.withOpacity(0.4),
                              blurRadius: 40, spreadRadius: -4),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(is3DNeo ? 8 : 100),
                          child: profileImage != null
                              ? Image.file(profileImage!, fit: BoxFit.cover)
                              : Container(
                                  color: _C.card,
                                  child: Icon(_roleIcon(role), size: 38, color: rColor),
                                ),
                        ),
                      ),
                      Positioned(
                        right: -2, bottom: -2,
                        child: Container(
                          width: 26, height: 26,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: _C.neonGrad,
                            border: Border.all(color: _C.surface, width: 2.5),
                            boxShadow: [BoxShadow(color: _C.info.withOpacity(0.6), blurRadius: 10)],
                          ),
                          child: const Icon(Icons.verified_rounded,
                            color: Colors.white, size: 13),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Text(username,
                    style: const TextStyle(color: _C.text, fontSize: 19,
                      fontWeight: FontWeight.w900, letterSpacing: 0.5),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: rColor.withOpacity(0.18),
                          borderRadius: BorderRadius.circular(is3DNeo ? 0 : 20),
                          border: Border.all(color: rColor, width: 1.4),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(_roleIcon(role), color: rColor, size: 11),
                            const SizedBox(width: 4),
                            Text(role.toUpperCase(),
                              style: TextStyle(color: rColor, fontSize: 9.5,
                                fontWeight: FontWeight.w900, letterSpacing: 1.2),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.schedule_rounded, color: _C.textSub, size: 11),
                      const SizedBox(width: 4),
                      Text('Exp: $expiredDate',
                        style: const TextStyle(color: _C.textSub,
                          fontSize: 10.5, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DRAWER ITEM
// ═══════════════════════════════════════════════════════════════════
class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isDestructive;
  final bool is3DNeo;
  final VoidCallback onTap;

  const _DrawerItem({
    required this.icon, required this.label,
    required this.onTap, this.isDestructive = false,
    this.is3DNeo = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = isDestructive ? _C.danger : _C.text;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: isDestructive
            ? [_C.danger.withOpacity(0.10), _C.danger.withOpacity(0.03)]
            : [_C.card.withOpacity(0.7), _C.surface.withOpacity(0.4)]),
          borderRadius: BorderRadius.circular(is3DNeo ? 0 : 16),
          border: Border.all(
            color: isDestructive
              ? _C.danger.withOpacity(0.4)
              : _C.borderLit.withOpacity(0.25),
            width: 1.2,
          ),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(is3DNeo ? 0 : 16),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              child: Row(
                children: [
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: isDestructive
                        ? [_C.danger.withOpacity(0.25), _C.danger.withOpacity(0.08)]
                        : [_C.purple.withOpacity(0.22), _C.info.withOpacity(0.08)]),
                      borderRadius: BorderRadius.circular(is3DNeo ? 0 : 11),
                      border: Border.all(
                        color: isDestructive
                          ? _C.danger.withOpacity(0.5)
                          : _C.borderLit.withOpacity(0.4),
                        width: 1,
                      ),
                    ),
                    child: Icon(icon, color: isDestructive ? _C.danger : _C.primary, size: 17),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(label,
                      style: TextStyle(color: color, fontSize: 13.5,
                        fontWeight: FontWeight.w700, letterSpacing: 0.2),
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded,
                    color: isDestructive ? _C.danger.withOpacity(0.6) : _C.textDim,
                    size: 18,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  MENU BTN
// ═══════════════════════════════════════════════════════════════════
class _MenuBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _MenuBtn({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.all(8),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF1A1F42), Color(0xFF141833)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.borderLit.withOpacity(0.5), width: 1.2),
          boxShadow: [BoxShadow(color: _C.purple.withOpacity(0.25), blurRadius: 12)],
        ),
        child: const Icon(Icons.menu_rounded, color: _C.text, size: 20),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  APPBAR ICON BTN
// ═══════════════════════════════════════════════════════════════════
class _AppBarIconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool is3DNeo;

  const _AppBarIconBtn({
    required this.icon, required this.onTap, this.is3DNeo = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF1A1F42), Color(0xFF141833)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(is3DNeo ? 0 : 14),
          border: Border.all(color: _C.borderLit.withOpacity(0.5), width: 1.2),
          boxShadow: [BoxShadow(color: _C.purple.withOpacity(0.25), blurRadius: 12)],
        ),
        child: Icon(icon, color: _C.text, size: 18),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  GRADIENT BUTTON
// ═══════════════════════════════════════════════════════════════════
class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;
  final bool is3DNeo;

  const _GradBtn({
    required this.label, required this.onTap,
    this.fullWidth = false, this.is3DNeo = false,
  });

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 46,
          width: widget.fullWidth ? double.infinity : null,
          padding: widget.fullWidth ? null : const EdgeInsets.symmetric(horizontal: 24),
          decoration: BoxDecoration(
            gradient: _C.auroraGrad,
            borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 14),
            boxShadow: _down
                ? []
                : [
                    BoxShadow(color: _C.purple.withOpacity(0.5),
                      blurRadius: 18, spreadRadius: 1, offset: const Offset(0, 6)),
                    BoxShadow(color: _C.pink.withOpacity(0.3),
                      blurRadius: 20, spreadRadius: -4),
                  ],
          ),
          child: Center(
            child: Text(widget.label,
              style: const TextStyle(color: Colors.white,
                fontWeight: FontWeight.w700, fontSize: 14),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  NEWS MEDIA
// ═══════════════════════════════════════════════════════════════════
class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => const SizedBox(),
      loadingBuilder: (_, child, loading) {
        if (loading == null) return child;
        return const Center(child: CircularProgressIndicator(color: _C.primary, strokeWidth: 2));
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  DASHBOARD PROFILE CARD
// ═══════════════════════════════════════════════════════════════════
class DashboardProfileCard extends StatefulWidget {
  final String username, role, expired;
  final File? profileImage;
  final String? networkImageUrl;
  final String androidId, sessionKey;
  final bool is3DNeo;
  final Widget? clockWidget;

  const DashboardProfileCard({
    super.key, required this.username, required this.role,
    required this.expired, this.profileImage, this.networkImageUrl,
    required this.androidId, required this.sessionKey,
    this.is3DNeo = false, this.clockWidget,
  });

  @override
  State<DashboardProfileCard> createState() => _DashboardProfileCardState();
}

class _DashboardProfileCardState extends State<DashboardProfileCard> {
  late Timer _timer;
  String _currentTime = '';
  int _batteryLevel = 0;
  double _ramUsage = 0.0;
  double _storageUsage = 0.0;
  String _systemInfo = 'Loading...';
  final String _networkStatus = "Connected";

  @override
  void initState() {
    super.initState();
    _loadDeviceInfo();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _loadDeviceInfo();
      _updateTime();
    });
  }

  void _updateTime() {
    final now = DateTime.now();
    setState(() {
      _currentTime = "${now.hour.toString().padLeft(2, '0')}:"
          "${now.minute.toString().padLeft(2, '0')}:"
          "${now.second.toString().padLeft(2, '0')}";
    });
  }

  @override
  void dispose() { _timer.cancel(); super.dispose(); }

  Future<void> _loadDeviceInfo() async {
    try {
      final battery = Battery();
      final batteryLevel = await battery.batteryLevel;
      final deviceInfo = DeviceInfoPlugin();
      final androidInfo = await deviceInfo.androidInfo;
      final totalRam = SysInfo.getTotalPhysicalMemory();
      final freeRam = SysInfo.getFreePhysicalMemory();
      final usedRam = totalRam - freeRam;
      final ramUsage = totalRam > 0 ? usedRam / totalRam : 0.0;
      final totalStorage = SysInfo.getTotalStorage();
      final freeStorage = SysInfo.getFreeStorage();
      final usedStorage = totalStorage - freeStorage;
      final storageUsage = totalStorage > 0 ? usedStorage / totalStorage : 0.0;

      if (!mounted) return;
      setState(() {
        _batteryLevel = batteryLevel;
        _ramUsage = ramUsage.clamp(0.0, 1.0);
        _storageUsage = storageUsage.clamp(0.0, 1.0);
        _systemInfo = '${androidInfo.model} (API ${androidInfo.version.sdkInt})';
      });
    } catch (e) {
      debugPrint('Failed to load device info: $e');
    }
  }

  Widget _buildInfoTile(String label, String value, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: _C.textSub, size: 14),
        const SizedBox(width: 8),
        Text(label, style: const TextStyle(color: _C.textSub, fontSize: 11)),
        const Spacer(),
        Flexible(
          child: Text(value,
            style: const TextStyle(color: _C.text, fontSize: 11,
              fontWeight: FontWeight.bold),
            overflow: TextOverflow.ellipsis, maxLines: 1,
          ),
        ),
      ],
    );
  }

  Widget _statChip({required IconData icon, required String label,
      required String value, required Color color, required double progress}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [color.withOpacity(0.14), color.withOpacity(0.04)],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.35), width: 1.2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 13),
              const SizedBox(width: 5),
              Expanded(
                child: Text(label,
                  maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: color.withOpacity(0.9),
                    fontSize: 9.5, fontWeight: FontWeight.w800, letterSpacing: 0.5),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(value,
            style: const TextStyle(color: _C.text, fontSize: 15,
              fontWeight: FontWeight.w900, letterSpacing: -0.3),
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: Stack(
              children: [
                Container(height: 4, color: _C.surface),
                FractionallySizedBox(
                  widthFactor: progress.clamp(0.0, 1.0),
                  child: Container(
                    height: 4,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [color, Color.lerp(color, Colors.white, 0.5)!],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ramPct = (_ramUsage * 100).toInt();
    return Container(
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 26),
        border: Border.all(color: _C.borderLit.withOpacity(0.5), width: 1.5),
        boxShadow: [
          BoxShadow(color: _C.purple.withOpacity(0.35),
            blurRadius: 28, spreadRadius: 2, offset: const Offset(0, 10)),
          BoxShadow(color: _C.info.withOpacity(0.2), blurRadius: 30, spreadRadius: -4),
        ],
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 26),
              child: CustomPaint(painter: HoneycombPainter()),
            ),
          ),
          Positioned(
            top: 0, left: 0, right: 0,
            child: Container(
              height: 4,
              decoration: const BoxDecoration(
                gradient: _C.auroraGrad,
                borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 68, height: 68,
                      padding: const EdgeInsets.all(2.5),
                      decoration: BoxDecoration(
                        shape: widget.is3DNeo ? BoxShape.rectangle : BoxShape.circle,
                        borderRadius: widget.is3DNeo ? BorderRadius.circular(8) : null,
                        gradient: _C.auroraGrad,
                        boxShadow: [
                          BoxShadow(color: _C.purple.withOpacity(0.5),
                            blurRadius: widget.is3DNeo ? 0 : 20, spreadRadius: 1),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(widget.is3DNeo ? 6 : 100),
                        child: widget.profileImage != null
                            ? Image.file(widget.profileImage!, fit: BoxFit.cover)
                            : widget.networkImageUrl != null && widget.networkImageUrl!.isNotEmpty
                                ? Image.network(widget.networkImageUrl!, fit: BoxFit.cover)
                                : Container(
                                    color: _C.card,
                                    child: const Icon(Icons.person, color: _C.primary, size: 34),
                                  ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("Selamat Datang",
                            style: TextStyle(color: _C.textSub, fontSize: 12),
                          ),
                          const SizedBox(height: 3),
                          ShaderMask(
                            shaderCallback: (bounds) => _C.auroraGrad.createShader(bounds),
                            child: Text(widget.username.toUpperCase(),
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white,
                                fontWeight: FontWeight.w900, fontSize: 21, letterSpacing: 1),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                            decoration: BoxDecoration(
                              color: _roleColor(widget.role).withOpacity(.15),
                              borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 25),
                              border: Border.all(
                                color: _roleColor(widget.role).withOpacity(0.6),
                                width: 1.5,
                              ),
                            ),
                            child: Text(widget.role.toUpperCase(),
                              style: TextStyle(color: _roleColor(widget.role),
                                fontSize: 11, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (widget.clockWidget != null) widget.clockWidget!,
                  ],
                ),
                const SizedBox(height: 20),
                const Divider(color: _C.border, height: 1),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: _statChip(
                        icon: Icons.battery_charging_full_rounded,
                        label: "Battery", value: "$_batteryLevel%",
                        color: _C.success, progress: _batteryLevel / 100,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _statChip(
                        icon: Icons.memory_rounded,
                        label: "RAM", value: "$ramPct%",
                        color: _C.info, progress: _ramUsage,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _statChip(
                        icon: Icons.sd_storage_rounded,
                        label: "Disk", value: "${(_storageUsage * 100).toInt()}%",
                        color: _C.warn, progress: _storageUsage,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                const Divider(color: _C.border, height: 1),
                const SizedBox(height: 14),
                _buildInfoTile("Device ID", widget.androidId, Icons.phone_android_rounded),
                const SizedBox(height: 10),
                _buildInfoTile("Network", _networkStatus, Icons.wifi_rounded),
                const SizedBox(height: 10),
                _buildInfoTile("System", _systemInfo, Icons.system_update_alt_rounded),
                const SizedBox(height: 10),
                _buildInfoTile("Session Key",
                  "${widget.sessionKey.substring(0, 8)}********", Icons.vpn_key_rounded),
                const SizedBox(height: 10),
                _buildInfoTile("Time", _currentTime, Icons.timer_rounded),
                const SizedBox(height: 20),
                Container(
                  height: 38,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [_C.surface, _C.cardSoft]),
                    borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 20),
                    border: Border.all(color: _C.borderLit.withOpacity(0.4), width: 1),
                  ),
                  child: Center(
                    child: RichText(
                      textAlign: TextAlign.center,
                      text: const TextSpan(children: [
                        TextSpan(text: "● Powered by ",
                          style: TextStyle(color: _C.text, fontWeight: FontWeight.w600,
                            fontSize: 12, letterSpacing: .5)),
                        TextSpan(text: "vinzzsukakmu",
                          style: TextStyle(color: _C.primary, fontWeight: FontWeight.w600,
                            fontSize: 12, letterSpacing: .5)),
                        TextSpan(text: " ●",
                          style: TextStyle(color: _C.text, fontWeight: FontWeight.w600,
                            fontSize: 12, letterSpacing: .5)),
                      ]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  SPONGEBOB STICKER
// ═══════════════════════════════════════════════════════════════════
class SpongebobSticker extends StatelessWidget {
  const SpongebobSticker({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 120, height: 160,
      child: Image.asset(
        'assets/images/spongebob.png',
        width: 120, height: 160,
        fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) {
          return const SizedBox(width: 120, height: 160);
        },
      ),
    );
  }
}
