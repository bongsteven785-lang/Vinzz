import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'firebase/firebase_init.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'developer_page.dart';
import 'partner_page.dart';
import 'landing.dart';
import 'welcome.dart';
import 'theme_manager.dart';
import 'custom_background.dart';

// ─────────────────────────────────────────────
//  COLOR SYSTEM — AURORA VIBRANT
// ─────────────────────────────────────────────
class _C {
  // Background — deep cosmic
  static const bg         = Color(0xFF090612);
  static const bgAlt      = Color(0xFF100A1B);
  static const surface    = Color(0xFF130D22);
  static const card       = Color(0xFF1B1230);
  static const cardAlt    = Color(0xFF25183D);

  static const border     = Color(0xFF49316F);
  static const borderLit  = Color(0xFF6D4C9E);

  // Vibrant palette
  static const steel      = Color(0xFF6D28D9);
  static const blueMid    = Color(0xFF8B5CF6);
  static const blueLight  = Color(0xFF9B6DFF);
  static const chrome     = Color(0xFF9B6DFF);
  static const frost      = Color(0xFFEDE7FF);

  static const green      = Color(0xFFB79CFF);
  static const amber      = Color(0xFF9B6DFF);
  static const red        = Color(0xFF8B5CF6);
  static const gold       = Color(0xFFB79CFF);

  static const text       = Color(0xFFF8FAFF);
  static const textSub    = Color(0xFFC7B8F5);
  static const textDim    = Color(0xFF8D7BAF);

  // Gradients
  static const LinearGradient metalGrad = LinearGradient(
    colors: [Color(0xFF6D28D9), Color(0xFF8B5CF6), Color(0xFF9B6DFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient auroraGrad = LinearGradient(
    colors: [Color(0xFF6D28D9), Color(0xFF8B5CF6), Color(0xFFB79CFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient neonGrad = LinearGradient(
    colors: [Color(0xFF6D28D9), Color(0xFF8B5CF6), Color(0xFFFF354D)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient luxeGrad = LinearGradient(
    colors: [Color(0xFF6D28D9), Color(0xFF8B5CF6), Color(0xFFB79CFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient surfaceGrad = LinearGradient(
    colors: [Color(0xFF1B1230), Color(0xFF130D22)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient bgGrad = LinearGradient(
    colors: [Color(0xFF090612), Color(0xFF130D22), Color(0xFF100A1B)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}

// ─────────────────────────────────────────────
//  THEME BUILDER
// ─────────────────────────────────────────────
class _AppTheme {
  static const _font = 'Orbitron';

  static ThemeData build() => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    fontFamily: _font,
    scaffoldBackgroundColor: _C.bg,

    colorScheme: const ColorScheme.dark(
      brightness:               Brightness.dark,
      primary:                  _C.blueLight,
      onPrimary:                Colors.white,
      primaryContainer:         _C.steel,
      onPrimaryContainer:       _C.frost,
      secondary:                _C.chrome,
      onSecondary:              _C.bg,
      secondaryContainer:       _C.borderLit,
      onSecondaryContainer:     _C.text,
      tertiary:                 _C.green,
      onTertiary:               _C.bg,
      error:                    _C.red,
      onError:                  Colors.white,
      surface:                  _C.surface,
      onSurface:                _C.text,
      surfaceContainerHighest:  _C.card,
      outline:                  _C.border,
      outlineVariant:           _C.borderLit,
      shadow:                   Color(0xFF6D28D9),
      scrim:                    Colors.black87,
      inverseSurface:           _C.frost,
      onInverseSurface:         _C.bg,
      inversePrimary:           _C.steel,
    ),

    appBarTheme: const AppBarTheme(
      backgroundColor:      Colors.transparent,
      foregroundColor:      _C.text,
      elevation:            0,
      scrolledUnderElevation: 0,
      centerTitle:          false,
      titleTextStyle: TextStyle(
        fontFamily:   _font,
        fontSize:     18,
        fontWeight:   FontWeight.w700,
        color:        _C.text,
        letterSpacing: 0.5,
      ),
      iconTheme:        IconThemeData(color: _C.chrome, size: 22),
      actionsIconTheme: IconThemeData(color: _C.textSub, size: 20),
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor:                    Colors.transparent,
        statusBarIconBrightness:           Brightness.light,
        statusBarBrightness:               Brightness.dark,
        systemNavigationBarColor:          _C.bg,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
    ),

    cardTheme: CardThemeData(
      color:        _C.card,
      elevation:    0,
      margin:       EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(color: _C.border, width: 1),
      ),
      clipBehavior: Clip.antiAlias,
    ),

    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.disabled)) return _C.border;
          if (s.contains(WidgetState.pressed))  return _C.steel;
          return _C.blueLight;
        }),
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.disabled)) return _C.textDim;
          return Colors.white;
        }),
        overlayColor:  WidgetStateProperty.all(_C.frost.withOpacity(0.15)),
        elevation:     WidgetStateProperty.all(0),
        shadowColor:   WidgetStateProperty.all(_C.blueLight.withOpacity(0.4)),
        padding:       WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 0.8),
        ),
        animationDuration: const Duration(milliseconds: 180),
      ),
    ),

    outlinedButtonTheme: OutlinedButtonThemeData(
      style: ButtonStyle(
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return _C.frost;
          return _C.chrome;
        }),
        side: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return const BorderSide(color: _C.chrome, width: 1.8);
          if (s.contains(WidgetState.focused)) return const BorderSide(color: _C.blueLight, width: 1.8);
          return const BorderSide(color: _C.borderLit, width: 1.2);
        }),
        backgroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return _C.blueLight.withOpacity(0.12);
          return Colors.transparent;
        }),
        overlayColor: WidgetStateProperty.all(_C.blueLight.withOpacity(0.08)),
        padding:      WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: 0.6),
        ),
      ),
    ),

    textButtonTheme: TextButtonThemeData(
      style: ButtonStyle(
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return _C.frost;
          return _C.chrome;
        }),
        overlayColor: WidgetStateProperty.all(_C.blueLight.withOpacity(0.1)),
        padding:      WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w600, letterSpacing: 0.4),
        ),
      ),
    ),

    inputDecorationTheme: InputDecorationTheme(
      filled:      true,
      fillColor:   _C.surface,
      hoverColor:  _C.card,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide:   const BorderSide(color: _C.border, width: 1.2),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide:   const BorderSide(color: _C.border, width: 1.2),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide:   const BorderSide(color: _C.blueLight, width: 2),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide:   const BorderSide(color: _C.red, width: 1.2),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide:   const BorderSide(color: _C.red, width: 2),
      ),
      disabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide:   const BorderSide(color: _C.textDim, width: 1),
      ),
      labelStyle:          const TextStyle(color: _C.textSub, fontSize: 13),
      hintStyle:           const TextStyle(color: _C.textDim, fontSize: 13),
      errorStyle:          const TextStyle(color: _C.red, fontSize: 11),
      prefixIconColor:     _C.textSub,
      suffixIconColor:     _C.textSub,
      floatingLabelStyle:  const TextStyle(color: _C.blueLight, fontSize: 12, fontWeight: FontWeight.w600),
    ),

    chipTheme: ChipThemeData(
      backgroundColor:     _C.surface,
      selectedColor:       _C.steel,
      disabledColor:       _C.border,
      deleteIconColor:     _C.textSub,
      labelStyle:          const TextStyle(color: _C.text, fontSize: 12, fontFamily: _font),
      secondaryLabelStyle: const TextStyle(color: _C.frost, fontSize: 12, fontFamily: _font),
      padding:             const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side:         const BorderSide(color: _C.border),
      ),
      side:            const BorderSide(color: _C.border),
      elevation:       0,
      pressElevation:  0,
      showCheckmark:   false,
    ),

    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor:      _C.surface,
      selectedItemColor:    _C.blueLight,
      unselectedItemColor:  _C.textDim,
      elevation:            0,
      type:                 BottomNavigationBarType.fixed,
      selectedLabelStyle:   TextStyle(fontSize: 10, fontFamily: _font, fontWeight: FontWeight.w700),
      unselectedLabelStyle: TextStyle(fontSize: 10, fontFamily: _font),
    ),

    navigationBarTheme: NavigationBarThemeData(
      backgroundColor:  _C.surface,
      indicatorColor:   _C.steel.withOpacity(0.5),
      iconTheme: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return const IconThemeData(color: _C.chrome, size: 22);
        return const IconThemeData(color: _C.textDim, size: 22);
      }),
      labelTextStyle: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) {
          return const TextStyle(color: _C.chrome, fontSize: 11, fontFamily: _font, fontWeight: FontWeight.w700);
        }
        return const TextStyle(color: _C.textDim, fontSize: 11, fontFamily: _font);
      }),
      elevation:     0,
      overlayColor:  WidgetStateProperty.all(_C.blueLight.withOpacity(0.08)),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
    ),

    drawerTheme: DrawerThemeData(
      backgroundColor:   _C.surface,
      elevation:         0,
      surfaceTintColor:  Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight:    Radius.circular(26),
          bottomRight: Radius.circular(26),
        ),
      ),
    ),

    dialogTheme: DialogThemeData(
      backgroundColor: _C.card,
      elevation:       0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side:         const BorderSide(color: _C.borderLit, width: 1.5),
      ),
      titleTextStyle: const TextStyle(
        fontFamily:    _font,
        fontSize:      18,
        fontWeight:    FontWeight.w700,
        color:         _C.text,
        letterSpacing: 0.3,
      ),
      contentTextStyle: const TextStyle(
        fontFamily: _font,
        fontSize:   14,
        color:      _C.textSub,
        height:     1.6,
      ),
    ),

    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor:      _C.surface,
      modalBackgroundColor: _C.surface,
      elevation:            0,
      modalElevation:       0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      showDragHandle:   true,
      dragHandleColor:  _C.borderLit,
      dragHandleSize:   Size(40, 4),
      clipBehavior:     Clip.antiAlias,
    ),

    snackBarTheme: SnackBarThemeData(
      backgroundColor:  _C.card,
      contentTextStyle: const TextStyle(color: _C.text, fontFamily: _font, fontSize: 13),
      actionTextColor:  _C.chrome,
      behavior:         SnackBarBehavior.floating,
      elevation:        0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side:         const BorderSide(color: _C.borderLit, width: 1.2),
      ),
    ),

    tabBarTheme: TabBarThemeData(
      labelColor:              _C.chrome,
      unselectedLabelColor:    _C.textDim,
      indicatorColor:          _C.chrome,
      indicatorSize:           TabBarIndicatorSize.label,
      labelStyle:              const TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w700),
      unselectedLabelStyle:    const TextStyle(fontFamily: _font, fontSize: 13),
      overlayColor:            WidgetStateProperty.all(_C.blueLight.withOpacity(0.08)),
      dividerColor:            _C.border,
    ),

    listTileTheme: const ListTileThemeData(
      tileColor:         Colors.transparent,
      selectedTileColor: Color(0x33A855F7),
      iconColor:         _C.textSub,
      selectedColor:     _C.chrome,
      textColor:         _C.text,
      subtitleTextStyle: TextStyle(color: _C.textSub, fontSize: 12),
      contentPadding:    EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(12)),
      ),
    ),

    dividerTheme: const DividerThemeData(
      color:     _C.border,
      thickness: 1,
      space:     1,
    ),

    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return _C.chrome;
        return _C.textDim;
      }),
      trackColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return _C.steel.withOpacity(0.5);
        return _C.border;
      }),
      trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
      overlayColor:      WidgetStateProperty.all(_C.blueLight.withOpacity(0.1)),
    ),

    checkboxTheme: CheckboxThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return _C.chrome;
        return Colors.transparent;
      }),
      checkColor:   WidgetStateProperty.all(_C.bg),
      side:         const BorderSide(color: _C.borderLit, width: 1.5),
      shape:        RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
      overlayColor: WidgetStateProperty.all(_C.blueLight.withOpacity(0.1)),
    ),

    radioTheme: RadioThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return _C.chrome;
        return _C.textDim;
      }),
      overlayColor: WidgetStateProperty.all(_C.blueLight.withOpacity(0.1)),
    ),

    sliderTheme: SliderThemeData(
      activeTrackColor:    _C.chrome,
      inactiveTrackColor:  _C.border,
      thumbColor:          _C.chrome,
      overlayColor:        _C.blueLight.withOpacity(0.15),
      valueIndicatorColor: _C.steel,
      valueIndicatorTextStyle: const TextStyle(color: _C.text, fontSize: 12, fontFamily: _font),
      trackHeight:         3,
      thumbShape:          const RoundSliderThumbShape(enabledThumbRadius: 7),
    ),

    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color:              _C.chrome,
      linearTrackColor:   _C.border,
      circularTrackColor: _C.border,
      linearMinHeight:    3,
    ),

    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor:    _C.blueLight,
      foregroundColor:    Colors.white,
      elevation:          0,
      focusElevation:     0,
      hoverElevation:     0,
      highlightElevation: 0,
      splashColor:        _C.frost.withOpacity(0.25),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),

    iconTheme:        const IconThemeData(color: _C.chrome, size: 22),
    primaryIconTheme: const IconThemeData(color: _C.blueLight, size: 22),

    popupMenuTheme: PopupMenuThemeData(
      color:            _C.card,
      elevation:        0,
      shadowColor:      Colors.transparent,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side:         const BorderSide(color: _C.borderLit, width: 1.2),
      ),
      textStyle: const TextStyle(color: _C.text, fontFamily: _font, fontSize: 13),
      labelTextStyle: WidgetStateProperty.all(
        const TextStyle(color: _C.text, fontFamily: _font, fontSize: 13),
      ),
      iconColor: _C.textSub,
    ),

    tooltipTheme: TooltipThemeData(
      decoration: BoxDecoration(
        color:        _C.surface,
        borderRadius: BorderRadius.circular(10),
        border:       Border.all(color: _C.borderLit, width: 1.2),
      ),
      textStyle: const TextStyle(color: _C.text, fontSize: 11, fontFamily: _font),
      padding:   const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    ),

    scrollbarTheme: ScrollbarThemeData(
      thumbColor:      WidgetStateProperty.all(_C.borderLit),
      trackColor:      WidgetStateProperty.all(_C.surface),
      radius:          const Radius.circular(4),
      thickness:       WidgetStateProperty.all(3),
      crossAxisMargin: 2,
    ),

    textSelectionTheme: const TextSelectionThemeData(
      cursorColor:          _C.chrome,
      selectionColor:       Color(0x40A855F7),
      selectionHandleColor: _C.chrome,
    ),

    splashColor:    _C.blueLight.withOpacity(0.1),
    highlightColor: _C.blueLight.withOpacity(0.06),
    hoverColor:     _C.blueLight.withOpacity(0.04),
    focusColor:     _C.blueLight.withOpacity(0.08),
    splashFactory:  InkRipple.splashFactory,

    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: _AuroraTransitionBuilder(),
        TargetPlatform.iOS:     _AuroraTransitionBuilder(),
        TargetPlatform.windows: _AuroraTransitionBuilder(),
        TargetPlatform.macOS:   _AuroraTransitionBuilder(),
        TargetPlatform.linux:   _AuroraTransitionBuilder(),
      },
    ),

    textTheme: const TextTheme(
      displayLarge:   TextStyle(fontFamily: _font, fontSize: 57, fontWeight: FontWeight.w800, color: _C.text, letterSpacing: -1.5),
      displayMedium:  TextStyle(fontFamily: _font, fontSize: 45, fontWeight: FontWeight.w700, color: _C.text, letterSpacing: -1.0),
      displaySmall:   TextStyle(fontFamily: _font, fontSize: 36, fontWeight: FontWeight.w700, color: _C.text, letterSpacing: -0.5),
      headlineLarge:  TextStyle(fontFamily: _font, fontSize: 32, fontWeight: FontWeight.w700, color: _C.text, letterSpacing: -0.3),
      headlineMedium: TextStyle(fontFamily: _font, fontSize: 26, fontWeight: FontWeight.w600, color: _C.text, letterSpacing: -0.2),
      headlineSmall:  TextStyle(fontFamily: _font, fontSize: 22, fontWeight: FontWeight.w600, color: _C.text),
      titleLarge:     TextStyle(fontFamily: _font, fontSize: 18, fontWeight: FontWeight.w600, color: _C.text, letterSpacing: 0.2),
      titleMedium:    TextStyle(fontFamily: _font, fontSize: 15, fontWeight: FontWeight.w500, color: _C.text, letterSpacing: 0.1),
      titleSmall:     TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w500, color: _C.textSub),
      bodyLarge:      TextStyle(fontFamily: _font, fontSize: 16, fontWeight: FontWeight.w400, color: _C.text, height: 1.6),
      bodyMedium:     TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w400, color: _C.text, height: 1.6),
      bodySmall:      TextStyle(fontFamily: _font, fontSize: 12, fontWeight: FontWeight.w400, color: _C.textSub, height: 1.5),
      labelLarge:     TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w600, color: _C.text, letterSpacing: 0.5),
      labelMedium:    TextStyle(fontFamily: _font, fontSize: 12, fontWeight: FontWeight.w500, color: _C.textSub, letterSpacing: 0.4),
      labelSmall:     TextStyle(fontFamily: _font, fontSize: 10, fontWeight: FontWeight.w500, color: _C.textDim, letterSpacing: 0.6),
    ),
  );
}

// ─────────────────────────────────────────────
//  CUSTOM PAGE TRANSITION
// ─────────────────────────────────────────────
class _AuroraTransitionBuilder extends PageTransitionsBuilder {
  const _AuroraTransitionBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final inCurve  = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
    final outCurve = CurvedAnimation(parent: secondaryAnimation, curve: Curves.easeInCubic);

    return FadeTransition(
      opacity: inCurve,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.04),
          end: Offset.zero,
        ).animate(inCurve),
        child: FadeTransition(
          opacity: Tween<double>(begin: 1.0, end: 0.85).animate(outCurve),
          child: ScaleTransition(
            scale: Tween<double>(begin: 1.0, end: 0.96).animate(outCurve),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  GLOBAL SNACKBAR HELPER
// ─────────────────────────────────────────────
class AppSnackbar {
  static void success(BuildContext context, String message) {
    _show(context, message, _C.green, Icons.check_circle_rounded);
  }

  static void error(BuildContext context, String message) {
    _show(context, message, _C.red, Icons.error_rounded);
  }

  static void info(BuildContext context, String message) {
    _show(context, message, _C.chrome, Icons.info_rounded);
  }

  static void warning(BuildContext context, String message) {
    _show(context, message, _C.amber, Icons.warning_rounded);
  }

  static void _show(BuildContext context, String message, Color color, IconData icon) {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [color, color.withOpacity(0.6)]),
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(color: color.withOpacity(0.5), blurRadius: 10),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 14),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  color: _C.text,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Orbitron',
                ),
              ),
            ),
          ],
        ),
        backgroundColor: _C.card,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: color.withOpacity(0.4), width: 1.2),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  SPLASH SCREEN
// ─────────────────────────────────────────────
class _SplashScreen extends StatefulWidget {
  final Widget child;
  const _SplashScreen({required this.child});

  @override
  State<_SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<_SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoCtrl;
  late AnimationController _fadeCtrl;
  late AnimationController _progressCtrl;

  late Animation<double> _logoScale;
  late Animation<double> _logoRotate;
  late Animation<double> _fadeOut;
  late Animation<double> _progress;

  bool _showSplash = true;

  @override
  void initState() {
    super.initState();

    _logoCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..forward();

    _logoScale = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _logoCtrl, curve: Curves.elasticOut),
    );

    _logoRotate = Tween<double>(begin: -0.15, end: 0).animate(
      CurvedAnimation(parent: _logoCtrl, curve: Curves.easeOutBack),
    );

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );

    _fadeOut = Tween<double>(begin: 1, end: 0).animate(
      CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut),
    );

    _progressCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..forward();

    _progress = CurvedAnimation(parent: _progressCtrl, curve: Curves.easeInOut);

    Timer(const Duration(milliseconds: 2400), () {
      _fadeCtrl.forward().then((_) {
        if (mounted) setState(() => _showSplash = false);
      });
    });
  }

  @override
  void dispose() {
    _logoCtrl.dispose();
    _fadeCtrl.dispose();
    _progressCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,
        if (_showSplash)
          FadeTransition(
            opacity: _fadeOut,
            child: Container(
              color: _C.bg,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: CustomPaint(painter: _SplashBgPainter()),
                  ),
                  Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AnimatedBuilder(
                          animation: _logoCtrl,
                          builder: (_, __) => Transform.scale(
                            scale: _logoScale.value,
                            child: Transform.rotate(
                              angle: _logoRotate.value,
                              child: Container(
                                width: 130,
                                height: 130,
                                // ✅ padding di Container (bukan di BoxDecoration)
                                padding: const EdgeInsets.all(3),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(34),
                                  gradient: _C.auroraGrad,
                                  // padding DIHAPUS dari sini
                                  boxShadow: [
                                    BoxShadow(
                                      color: _C.blueLight.withOpacity(0.6),
                                      blurRadius: 40,
                                      spreadRadius: 4,
                                    ),
                                    BoxShadow(
                                      color: _C.red.withOpacity(0.3),
                                      blurRadius: 60,
                                    ),
                                  ],
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(31),
                                  child: Container(
                                    color: _C.card,
                                    child: Image.asset(
                                      'assets/images/reze.png',
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => Container(
                                        decoration: BoxDecoration(
                                          // ✅ GANTI dari _C.luxeGrad ke _C.auroraGrad
                                          gradient: _C.auroraGrad,
                                          borderRadius: BorderRadius.circular(31),
                                        ),
                                        child: const Icon(
                                          Icons.auto_awesome_rounded,
                                          color: Colors.white,
                                          size: 50,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 30),
                        AnimatedBuilder(
                          animation: _logoCtrl,
                          builder: (_, __) => Opacity(
                            opacity: _logoCtrl.value.clamp(0.0, 1.0),
                            child: ShaderMask(
                              shaderCallback: (b) => _C.auroraGrad.createShader(b),
                              child: const Text(
                                'NIGHT CORE',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 26,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Qaxer',
                                  letterSpacing: 6,
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'POWERED BY @mikkyyZz',
                          style: TextStyle(
                            color: _C.textSub.withOpacity(0.7),
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(height: 40),
                        Container(
                          width: 200,
                          height: 4,
                          decoration: BoxDecoration(
                            color: _C.surface,
                            borderRadius: BorderRadius.circular(2),
                          ),
                          child: AnimatedBuilder(
                            animation: _progress,
                            builder: (_, __) => FractionallySizedBox(
                              alignment: Alignment.centerLeft,
                              widthFactor: _progress.value.clamp(0.0, 1.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: _C.auroraGrad,
                                  borderRadius: BorderRadius.circular(2),
                                  boxShadow: [
                                    BoxShadow(
                                      color: _C.chrome.withOpacity(0.6),
                                      blurRadius: 10,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        AnimatedBuilder(
                          animation: _progress,
                          builder: (_, __) => Text(
                            '${(_progress.value * 100).toInt()}%',
                            style: const TextStyle(
                              color: _C.chrome,
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _SplashBgPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final orb1 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.blueLight.withOpacity(0.3),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.2, size.height * 0.3),
        radius: 300,
      ));
    canvas.drawCircle(Offset(size.width * 0.2, size.height * 0.3), 300, orb1);

    final orb2 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.chrome.withOpacity(0.25),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.85, size.height * 0.7),
        radius: 280,
      ));
    canvas.drawCircle(Offset(size.width * 0.85, size.height * 0.7), 280, orb2);

    final orb3 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.red.withOpacity(0.2),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.5, size.height * 0.9),
        radius: 250,
      ));
    canvas.drawCircle(Offset(size.width * 0.5, size.height * 0.9), 250, orb3);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// ─────────────────────────────────────────────
//  GLOBAL AURORA BACKGROUND WRAPPER
// ─────────────────────────────────────────────
class AuroraBackground extends StatelessWidget {
  final Widget child;
  const AuroraBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: Container(
            decoration: const BoxDecoration(gradient: _C.bgGrad),
            child: CustomPaint(painter: _AuroraBgPainter()),
          ),
        ),
        child,
      ],
    );
  }
}

class _AuroraBgPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _C.border.withOpacity(0.08)
      ..strokeWidth = 0.5;
    const step = 50.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    final orb1 = Paint()
      ..shader = RadialGradient(
        colors: [_C.blueLight.withOpacity(0.15), Colors.transparent],
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.1, size.height * 0.1),
        radius: 250,
      ));
    canvas.drawCircle(Offset(size.width * 0.1, size.height * 0.1), 250, orb1);

    final orb2 = Paint()
      ..shader = RadialGradient(
        colors: [_C.chrome.withOpacity(0.12), Colors.transparent],
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.9, size.height * 0.5),
        radius: 280,
      ));
    canvas.drawCircle(Offset(size.width * 0.9, size.height * 0.5), 280, orb2);

    final orb3 = Paint()
      ..shader = RadialGradient(
        colors: [_C.red.withOpacity(0.1), Colors.transparent],
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.3, size.height * 0.9),
        radius: 260,
      ));
    canvas.drawCircle(Offset(size.width * 0.3, size.height * 0.9), 260, orb3);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// ─────────────────────────────────────────────
//  ROUTE BUILDER
// ─────────────────────────────────────────────
Route<dynamic>? _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;

  Widget page;

  switch (settings.name) {
    case '/':
    case '/welcome':
      page = const WelcomePage();
      break;

    case '/custom-background':
      page = const CustomBackgroundSettingsPage();
      break;

    case '/landing':
      page = const LandingPage();
      break;

    case '/login':
      page = const LoginPage();
      break;

    case '/dashboard':
      page = DashboardPage(
        username:     args!['username']    as String,
        password:     args['password']     as String,
        role:         args['role']         as String,
        sessionKey:   args['key']          as String,
        expiredDate:  args['expiredDate']  as String,
        listBug:      List<Map<String, dynamic>>.from(args['listBug']      ?? []),
        listBugGroup: List<Map<String, dynamic>>.from(args['listBugGroup'] ?? []),
        listDoos:     List<Map<String, dynamic>>.from(args['listDoos']     ?? []),
        news:         List<dynamic>.from(args['news']     ?? []),
        jjVideos:     List<dynamic>.from(args['jjVideos'] ?? []),
        thanksTo:     List<dynamic>.from(args['thanksTo'] ?? []),
      );
      break;

    case '/home':
      page = HomePage(
        username:     args!['username']    as String,
        password:     args['password']     as String,
        role:         args['role']         as String,
        expiredDate:  args['expiredDate']  as String,
        sessionKey:   args['sessionKey']   as String,
        listBug:      List<Map<String, dynamic>>.from(args['listBug']      ?? []),
        listBugGroup: List<Map<String, dynamic>>.from(args['listBugGroup'] ?? []),
      );
      break;

    case '/seller':
      page = SellerPage(keyToken: args!['keyToken'] as String);
      break;

    case '/admin':
      page = AdminPage(sessionKey: args!['sessionKey'] as String);
      break;

    case '/partner':
      page = PartnerPage(
        sessionKey: args!['sessionKey'] as String,
        username:   args['username']    as String,
      );
      break;

    case '/owner':
      page = OwnerPage(
        sessionKey: args!['sessionKey'] as String,
        username:   args['username']    as String,
      );
      break;

    case '/developer':
      page = DeveloperPage(
        sessionKey: args!['sessionKey'] as String,
        username:   args['username']    as String,
      );
      break;

    default:
      page = _NotFoundPage(routeName: settings.name ?? 'unknown');
  }

  return PageRouteBuilder<dynamic>(
    settings: settings,
    transitionDuration:        const Duration(milliseconds: 320),
    reverseTransitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, secondaryAnimation, child) {
      final inCurve  = CurvedAnimation(parent: animation,          curve: Curves.easeOutCubic);
      final outCurve = CurvedAnimation(parent: secondaryAnimation, curve: Curves.easeInCubic);

      return FadeTransition(
        opacity: inCurve,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.035),
            end:   Offset.zero,
          ).animate(inCurve),
          child: FadeTransition(
            opacity: Tween<double>(begin: 1.0, end: 0.82).animate(outCurve),
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.0, end: 0.97).animate(outCurve),
              child: child,
            ),
          ),
        ),
      );
    },
  );
}

// ─────────────────────────────────────────────
//  404 PAGE
// ─────────────────────────────────────────────
class _NotFoundPage extends StatefulWidget {
  const _NotFoundPage({required this.routeName});
  final String routeName;

  @override
  State<_NotFoundPage> createState() => _NotFoundPageState();
}

class _NotFoundPageState extends State<_NotFoundPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double>   _fade;
  late final Animation<Offset>   _slide;
  late final Animation<double>   _glow;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))
      ..forward();

    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _glow  = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0.5, 1, curve: Curves.easeOut)));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: AuroraBackground(
        child: Center(
          child: FadeTransition(
            opacity: _fade,
            child: SlideTransition(
              position: _slide,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedBuilder(
                      animation: _glow,
                      builder: (_, child) => Container(
                        width: 96, height: 96,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: _C.surfaceGrad,
                          border: Border.all(color: _C.borderLit, width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color: _C.blueLight.withOpacity(0.3 * _glow.value),
                              blurRadius: 50,
                              spreadRadius: 8,
                            ),
                            BoxShadow(
                              color: _C.chrome.withOpacity(0.2 * _glow.value),
                              blurRadius: 70,
                            ),
                          ],
                        ),
                        child: child,
                      ),
                      child: const Icon(Icons.explore_off_rounded, color: _C.chrome, size: 38),
                    ),

                    const SizedBox(height: 28),

                    ShaderMask(
                      shaderCallback: (bounds) => _C.auroraGrad.createShader(bounds),
                      child: const Text(
                        '404',
                        style: TextStyle(
                          fontFamily:    'ShareTechMono',
                          fontSize:      78,
                          fontWeight:    FontWeight.w800,
                          color:         Colors.white,
                          height:        1,
                          letterSpacing: -3,
                        ),
                      ),
                    ),

                    const SizedBox(height: 10),

                    const Text(
                      'Route not found',
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        fontSize:   16,
                        fontWeight: FontWeight.w600,
                        color:      _C.textSub,
                        letterSpacing: 0.3,
                      ),
                    ),

                    const SizedBox(height: 6),

                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        gradient: _C.surfaceGrad,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _C.borderLit, width: 1),
                      ),
                      child: Text(
                        '"${widget.routeName}"',
                        style: const TextStyle(
                          fontFamily: 'Orbitron',
                          fontSize:   12,
                          color:      _C.textDim,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ),

                    const SizedBox(height: 36),

                    OutlinedButton.icon(
                      onPressed: () =>
                          Navigator.of(context).pushNamedAndRemoveUntil('/', (_) => false),
                      icon:  const Icon(Icons.arrow_back_rounded, size: 16),
                      label: const Text('Back to Home'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  ENTRY POINT
// ─────────────────────────────────────────────
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FirebaseInit();
  await QaxerThemeManager.loadSaved();
  await CustomBackgroundManager.load();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:                    Colors.transparent,
    statusBarIconBrightness:           Brightness.light,
    statusBarBrightness:               Brightness.dark,
    systemNavigationBarColor:          _C.bg,
    systemNavigationBarDividerColor:   Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const _OrcaApp());
}

// ─────────────────────────────────────────────
//  ROOT APP WIDGET
// ─────────────────────────────────────────────
class _OrcaApp extends StatelessWidget {
  const _OrcaApp();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<QaxerPalette>(
      valueListenable: QaxerThemeManager.current,
      builder: (context, palette, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'QAXER SIGNATURE 2027',
          theme: QaxerThemeManager.apply(_AppTheme.build(), palette),
          initialRoute: '/welcome',
          onGenerateRoute: _generateRoute,
          builder: (context, child) {
            final mq = MediaQuery.of(context);
            return MediaQuery(
              data: mq.copyWith(
                textScaler: TextScaler.linear(mq.textScaleFactor.clamp(0.85, 1.2)),
              ),
              child: CustomBackgroundLayer(
                child: _SplashScreen(child: child ?? const SizedBox.shrink()),
              ),
            );
          },
        );
      },
    );
  }
}
