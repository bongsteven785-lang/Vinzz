// welcome.dart - MODERN CLEAN EDITION
// Warna: BUMBLE PURPLE - PUTIH dengan efek merah.
// Flow: Welcome -> Landing.
// Style: glassmorphism modern, thin border, soft shadow.

import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage>
    with TickerProviderStateMixin {
  // ─── Warna (tetap dari kode lama) ───
  static const _red = Color(0xFFFF354D);
  static const _redLight = Color(0xFF8B5CF6);
  static const _redDark = Color(0xFF6D28D9);
  static const _deepRed = Color(0xFF8B5CF6);
  static const _black = Color(0xFF080808);
  static const _surface = Color(0xFF130D22);
  static const _elevated = Color(0xFF1B1230);
  static const _muted = Color(0xFFFFFFFF);
  static const _dim = Color(0xFF8B5CF6);
  static const _textLight = Color(0xFFFFFFFF);
  static const _textSub = Color(0xFFFFFFFF);

  late final PageController _pageController;
  late final AnimationController _ambient;

  int _page = 0;
  double _pagePosition = 0;
  bool _navigating = false;

  final List<_Slide> _slides = const [
    _Slide(
      eyebrow: 'WELCOME',
      title: 'Selamat Datang di\nMortix PROJECT',
      subtitle: 'A new experience, made with intention.',
      description:
          'Nikmati tampilan yang lebih halus, modern, dan terasa personal sejak langkah pertama.',
      icon: CupertinoIcons.sparkles,
      tag: 'Mortix PROJECT',
      accent: _red,
      metric: '01',
      detail: 'NEW EXPERIENCE',
    ),
    _Slide(
      eyebrow: 'DESIGN',
      title: 'Detail yang\nterasa.',
      subtitle: 'Every detail has its own reason.',
      description:
          'Dibangun dengan perhatian pada detail, glass interface, dan animasi lembut yang jadi identitas Mortix PROJECT.',
      icon: CupertinoIcons.paintbrush_fill,
      tag: 'DESIGN',
      accent: _redLight,
      metric: '02',
      detail: 'GLASS / MOTION / DETAIL',
    ),
    _Slide(
      eyebrow: 'CREATIVE',
      title: 'Design by\nvinzzsukakmu',
      subtitle: 'A creative touch behind the experience.',
      description:
          'Konsep visual Mortix PROJECT dirancang dengan perhatian pada detail, motion, dan identitas yang clean.',
      icon: CupertinoIcons.heart_circle_fill,
      tag: 'vinzzsukakmu',
      accent: _redLight,
      metric: '03',
      detail: 'CREATIVE DIRECTION',
    ),
    _Slide(
      eyebrow: 'DEVELOPMENT',
      title: 'Developer by\nvinzzsukakmu',
      subtitle: 'Built with patience. Refined over time.',
      description:
          'vinzzsukakmu menjadi bagian dari pengembangan Mortix PROJECT, membawa perhatian pada detail dan pengalaman aplikasi.',
      icon: CupertinoIcons.wrench_fill,
      tag: 'vinzzsukakmu',
      accent: _redLight,
      metric: '04',
      detail: 'BUILD / REFINE / EVOLVE',
    ),
    _Slide(
      eyebrow: 'FUTURE',
      title: 'Terus\nberkembang.',
      subtitle: 'Keep supporting Mortix PROJECT.',
      description:
          'Terima kasih telah menggunakan Mortix PROJECT. Dukunganmu berarti untuk perjalanan ke depannya.',
      icon: CupertinoIcons.arrow_up_right_diamond_fill,
      tag: 'FUTURE',
      accent: _red,
      metric: '05',
      detail: 'SEE YOU INSIDE',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.88);
    _pageController.addListener(_onPageScroll);

    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();
  }

  void _onPageScroll() {
    if (!_pageController.hasClients) return;
    final v = _pageController.page ?? _page.toDouble();
    if (mounted) setState(() => _pagePosition = v);
  }

  @override
  void dispose() {
    _pageController
      ..removeListener(_onPageScroll)
      ..dispose();
    _ambient.dispose();
    super.dispose();
  }

  Future<void> _next() async {
    if (_navigating) return;
    if (_page < _slides.length - 1) {
      HapticFeedback.selectionClick();
      await _pageController.nextPage(
        duration: const Duration(milliseconds: 460),
        curve: Curves.easeOutCubic,
      );
      return;
    }
    await _continue();
  }

  Future<void> _continue() async {
    if (_navigating) return;
    setState(() => _navigating = true);
    HapticFeedback.mediumImpact();
    if (!mounted) return;
    Navigator.of(context).pushReplacementNamed('/landing');
  }

  void _onPageChanged(int index) {
    if (index != _page) HapticFeedback.selectionClick();
    setState(() => _page = index);
  }

  // ============================================================
  //  BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final bottom = MediaQuery.paddingOf(context).bottom;
    final compact = size.height < 720;

    return Scaffold(
      backgroundColor: _black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
                  child: _buildTopBar(),
                ),
                SizedBox(height: compact ? 18 : 26),
                _buildHeroHeader(compact),
                SizedBox(height: compact ? 12 : 18),
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    itemCount: _slides.length,
                    onPageChanged: _onPageChanged,
                    physics: const BouncingScrollPhysics(),
                    itemBuilder: (context, i) => _buildPageCard(i, compact),
                  ),
                ),
                SizedBox(height: compact ? 8 : 12),
                _buildPageIndicator(),
                SizedBox(height: compact ? 12 : 16),
                Padding(
                  padding: EdgeInsets.fromLTRB(20, 0, 20, 12 + bottom),
                  child: _buildBottomAction(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  //  BACKGROUND — 2 glow blob halus + subtle grid, no rotation
  // ============================================================
  Widget _buildBackground() {
    return AnimatedBuilder(
      animation: _ambient,
      builder: (context, _) {
        final t = _ambient.value * math.pi * 2;
        return Stack(
          fit: StackFit.expand,
          children: [
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFF080808),
                    Color(0xFF080808),
                    Color(0xFF080808),
                  ],
                ),
              ),
            ),
            Positioned(
              left: -160 + math.sin(t) * 60,
              top: 80 + math.cos(t * 0.8) * 50,
              child: _glow(360, _red, 0.10),
            ),
            Positioned(
              right: -180 + math.cos(t * 0.7) * 70,
              bottom: 120 + math.sin(t) * 55,
              child: _glow(390, _deepRed, 0.10),
            ),
            IgnorePointer(
              child: CustomPaint(
                painter: _SoftGridPainter(),
                size: Size.infinite,
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _glow(double size, Color color, double opacity) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [
              color.withValues(alpha: opacity),
              color.withValues(alpha: opacity * 0.18),
              Colors.transparent,
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  //  TOP BAR
  // ============================================================
  Widget _buildTopBar() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _glassPill(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 7,
                height: 7,
                decoration: const BoxDecoration(
                  color: _red,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'Mortix PROJECT',
                style: GoogleFonts.inter(
                  color: _textLight,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2.2,
                ),
              ),
            ],
          ),
        ),
        _glassPill(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                CupertinoIcons.circle_grid_3x3_fill,
                color: _redLight,
                size: 12,
              ),
              const SizedBox(width: 6),
              Text(
                'V4 • ${(_page + 1).toString().padLeft(2, '0')}',
                style: GoogleFonts.inter(
                  color: _muted,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _glassPill({required Widget child}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(999),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.055),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.085),
              width: 0.8,
            ),
          ),
          child: child,
        ),
      ),
    );
  }

  // ============================================================
  //  HERO HEADER
  // ============================================================
  Widget _buildHeroHeader(bool compact) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          _buildBrandOrb(compact ? 48 : 56),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Mortix PROJECT',
                  style: GoogleFonts.plusJakartaSans(
                    color: _textLight,
                    fontSize: compact ? 22 : 26,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -1.0,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Modern dark interface.',
                  style: GoogleFonts.inter(
                    color: _textLight.withValues(alpha: 0.43),
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.6,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '01 — 05',
                style: GoogleFonts.inter(
                  color: _textLight.withValues(alpha: 0.28),
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                'SWIPE →',
                style: GoogleFonts.inter(
                  color: _redLight.withValues(alpha: 0.65),
                  fontSize: 8,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.3,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBrandOrb(double size) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_redLight, _red, _redDark],
        ),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.18),
          width: 0.9,
        ),
        boxShadow: [
          BoxShadow(
            color: _red.withValues(alpha: 0.24),
            blurRadius: 26,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Icon(
        CupertinoIcons.bolt_fill,
        color: Colors.white,
        size: size * 0.42,
      ),
    );
  }

  // ============================================================
  //  PAGE CARD
  // ============================================================
  Widget _buildPageCard(int index, bool compact) {
    final slide = _slides[index];
    final distance = (index - _pagePosition).abs().clamp(0.0, 1.0);
    final selected = distance < 0.15;
    final scale = 1 - (distance * 0.055);
    final translateY = distance * 12;
    final opacity = 1 - (distance * 0.35);

    return Transform.translate(
      offset: Offset(0, translateY),
      child: Transform.scale(
        scale: scale,
        child: Opacity(
          opacity: opacity,
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: compact ? 3 : 6,
              vertical: compact ? 5 : 10,
            ),
            child: _GlassCard(
              accent: slide.accent,
              selected: selected,
              child: Padding(
                padding: EdgeInsets.fromLTRB(
                  compact ? 20 : 24,
                  compact ? 20 : 24,
                  compact ? 20 : 24,
                  compact ? 18 : 22,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildTag(slide),
                        Text(
                          slide.metric,
                          style: GoogleFonts.plusJakartaSans(
                            color: Colors.white.withValues(alpha: 0.14),
                            fontSize: 30,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -1.5,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: compact ? 16 : 22),
                    _buildIconPlate(slide),
                    SizedBox(height: compact ? 16 : 22),
                    Text(
                      slide.eyebrow,
                      style: GoogleFonts.inter(
                        color: slide.accent.withValues(alpha: 0.85),
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.45,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      slide.title,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.plusJakartaSans(
                        color: _textLight,
                        fontSize: compact ? 24 : 28,
                        fontWeight: FontWeight.w800,
                        height: 1.08,
                        letterSpacing: -0.9,
                      ),
                    ),
                    const SizedBox(height: 9),
                    Text(
                      slide.subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.inter(
                        color: Colors.white.withValues(alpha: 0.54),
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        height: 1.35,
                      ),
                    ),
                    SizedBox(height: compact ? 13 : 18),
                    Container(
                      height: 1,
                      width: double.infinity,
                      color: Colors.white.withValues(alpha: 0.065),
                    ),
                    SizedBox(height: compact ? 12 : 16),
                    Expanded(
                      child: Text(
                        slide.description,
                        style: GoogleFonts.inter(
                          color: Colors.white.withValues(alpha: 0.53),
                          fontSize: compact ? 11 : 12,
                          height: 1.62,
                        ),
                      ),
                    ),
                    _buildCardBottom(slide),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTag(_Slide slide) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: slide.accent.withValues(alpha: 0.075),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: slide.accent.withValues(alpha: 0.16),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: BoxDecoration(
              color: slide.accent,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 7),
          Text(
            slide.tag,
            style: GoogleFonts.inter(
              color: slide.accent.withValues(alpha: 0.86),
              fontSize: 8,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.15,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIconPlate(_Slide slide) {
    return Container(
      width: 58,
      height: 58,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            slide.accent.withValues(alpha: 0.19),
            slide.accent.withValues(alpha: 0.045),
          ],
        ),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.09),
        ),
        boxShadow: [
          BoxShadow(
            color: slide.accent.withValues(alpha: 0.12),
            blurRadius: 24,
            spreadRadius: -4,
          ),
        ],
      ),
      child: Icon(
        slide.icon,
        color: Colors.white,
        size: 25,
      ),
    );
  }

  Widget _buildCardBottom(_Slide slide) {
    return Row(
      children: [
        Expanded(
          child: Text(
            slide.detail,
            style: GoogleFonts.inter(
              color: Colors.white.withValues(alpha: 0.25),
              fontSize: 8,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.25,
            ),
          ),
        ),
        Icon(
          CupertinoIcons.arrow_right,
          color: slide.accent.withValues(alpha: 0.72),
          size: 15,
        ),
      ],
    );
  }

  // ============================================================
  //  INDICATOR
  // ============================================================
  Widget _buildPageIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(_slides.length, (index) {
        final active = index == _page;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 260),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 3.5),
          width: active ? 24 : 6,
          height: 5,
          decoration: BoxDecoration(
            color: active ? _red : Colors.white.withValues(alpha: 0.14),
            borderRadius: BorderRadius.circular(999),
            boxShadow: active
                ? [
                    BoxShadow(
                      color: _red.withValues(alpha: 0.32),
                      blurRadius: 10,
                    ),
                  ]
                : null,
          ),
        );
      }),
    );
  }

  // ============================================================
  //  BOTTOM ACTION
  // ============================================================
  Widget _buildBottomAction() {
    final last = _page == _slides.length - 1;
    return Column(
      children: [
        Text(
          last
              ? 'Lanjut bersama Mortix PROJECT ke langkah berikutnya.'
              : 'Geser untuk melanjutkan',
          style: GoogleFonts.inter(
            color: Colors.white.withValues(alpha: 0.30),
            fontSize: 9,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.7,
          ),
        ),
        const SizedBox(height: 9),
        GestureDetector(
          onTap: _next,
          child: AnimatedScale(
            duration: const Duration(milliseconds: 140),
            scale: _navigating ? 0.97 : 1.0,
            child: Container(
              width: double.infinity,
              height: 54,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: last
                      ? const [_redLight, _red, _redDark]
                      : [
                          _elevated.withValues(alpha: 0.9),
                          _surface.withValues(alpha: 0.72),
                        ],
                ),
                border: Border.all(
                  color: last
                      ? Colors.white.withValues(alpha: 0.14)
                      : Colors.white.withValues(alpha: 0.09),
                ),
                boxShadow: [
                  BoxShadow(
                    color: last
                        ? _red.withValues(alpha: 0.24)
                        : Colors.black.withValues(alpha: 0.24),
                    blurRadius: 24,
                    offset: const Offset(0, 9),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    last ? 'Mulai Sekarang' : 'Lanjut',
                    style: GoogleFonts.inter(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.1,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    width: 27,
                    height: 27,
                    decoration: BoxDecoration(
                      color: Colors.white
                          .withValues(alpha: last ? 0.13 : 0.055),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.10),
                      ),
                    ),
                    child: Icon(
                      last
                          ? CupertinoIcons.arrow_right
                          : CupertinoIcons.chevron_right_2,
                      color: Colors.white,
                      size: 13,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 7),
        Text(
          '© 2026 Mortix PROJECT • Made for the journey ahead',
          textAlign: TextAlign.center,
          style: GoogleFonts.inter(
            color: Colors.white.withValues(alpha: 0.19),
            fontSize: 8,
            letterSpacing: 0.2,
          ),
        ),
      ],
    );
  }
}

// ============================================================
//  DATA MODEL
// ============================================================
class _Slide {
  final String eyebrow;
  final String title;
  final String subtitle;
  final String description;
  final IconData icon;
  final String tag;
  final Color accent;
  final String metric;
  final String detail;

  const _Slide({
    required this.eyebrow,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.icon,
    required this.tag,
    required this.accent,
    required this.metric,
    required this.detail,
  });
}

// ============================================================
//  GLASS CARD
// ============================================================
class _GlassCard extends StatelessWidget {
  final Widget child;
  final Color accent;
  final bool selected;

  const _GlassCard({
    required this.child,
    required this.accent,
    required this.selected,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: selected ? 25 : 18,
          sigmaY: selected ? 25 : 18,
        ),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: const Color(0xFF171020)
                .withValues(alpha: selected ? 0.68 : 0.54),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: selected
                  ? Colors.white.withValues(alpha: 0.105)
                  : Colors.white.withValues(alpha: 0.065),
              width: selected ? 0.95 : 0.8,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.34),
                blurRadius: 34,
                offset: const Offset(0, 18),
              ),
              BoxShadow(
                color: accent.withValues(alpha: selected ? 0.075 : 0.025),
                blurRadius: 35,
                spreadRadius: -8,
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

// ============================================================
//  BACKGROUND PAINTER (grid statis, no animation)
// ============================================================
class _SoftGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFFF1744).withValues(alpha: 0.012)
      ..strokeWidth = 0.7;

    const gap = 48.0;
    for (double x = 0; x < size.width + gap; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height + gap; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _SoftGridPainter oldDelegate) => false;
}