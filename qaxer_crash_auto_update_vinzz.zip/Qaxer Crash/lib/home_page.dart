import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:Fiona/Qaxer/.dart';

final _baseUrl = Api.api;

// ═══════════════════════════════════════════════════════════════════
// PALETTE — AURORA VIBRANT (dipertahankan)
// ═══════════════════════════════════════════════════════════════════
class _C {
  static const bg         = Color(0xFF060918);
  static const bgAlt      = Color(0xFF0A0D24);
  static const surface    = Color(0xFF0F1530);
  static const card       = Color(0xFF141C3D);
  static const cardAlt    = Color(0xFF1A2450);

  static const border     = Color(0xFF2A3566);
  static const borderLit  = Color(0xFF4A5DA8);

  static const red        = Color(0xFF6D28D9);
  static const redMid     = Color(0xFF8B5CF6);
  static const redLight   = Color(0xFF9B6DFF);
  static const redFrost   = Color(0xFFEDE7FF);
  static const pink       = Color(0xFF8B5CF6);
  static const gold       = Color(0xFF9B6DFF);
  static const mint       = Color(0xFFB79CFF);

  static const green      = Color(0xFFB79CFF);
  static const greenDim   = Color(0xFF059669);
  static const amber      = Color(0xFF9B6DFF);
  static const purple     = Color(0xFF9B6DFF);

  static const text       = Color(0xFFF8FAFF);
  static const textSub    = Color(0xFFB4C0E0);
  static const textDim    = Color(0xFF6B78A0);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFF6D28D9), Color(0xFF8B5CF6), Color(0xFF9B6DFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient auroraGrad = LinearGradient(
    colors: [
      Color(0xFF6D28D9), Color(0xFF8B5CF6),
      Color(0xFF9B6DFF), Color(0xFFB79CFF),
      Color(0xFF9B6DFF), Color(0xFF8B5CF6),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient neonGrad = LinearGradient(
    colors: [Color(0xFF9B6DFF), Color(0xFF8B5CF6), Color(0xFF8B5CF6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient surfaceGrad = LinearGradient(
    colors: [Color(0xFF141C3D), Color(0xFF0F1530)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient bgGrad = LinearGradient(
    colors: [Color(0xFF060918), Color(0xFF0F1530), Color(0xFF0A0D24)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developer': return const Color(0xFF9B6DFF);
    case 'owner':     return const Color(0xFF9B6DFF);
    case 'admin':     return const Color(0xFF9B6DFF);
    case 'moderator': return const Color(0xFFB79CFF);
    case 'partner':   return const Color(0xFF9B6DFF);
    case 'vip':       return const Color(0xFF9B6DFF);
    case 'reseller':  return const Color(0xFFB79CFF);
    default:          return const Color(0xFF9B6DFF);
  }
}

// ═══════════════════════════════════════════════════════════════════
// HOME PAGE — BUG ATTACK (UNIFIED MODE)
// ═══════════════════════════════════════════════════════════════════
class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.listBugGroup,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  // ── Controllers
  final targetCtrl = TextEditingController();
  final loopCtrl = TextEditingController();
  final codeCtrl = TextEditingController();
  late VideoPlayerController _videoController;

  // ── State
  int _mode = 0; // 0=Number, 1=Group, 2=TestFunc
  String selectedBugId = '';
  String _senderType = 'private';
  bool _isSending = false;
  String? _responseMsg;
  List<String> _globalSenders = [];
  bool _isLoadingSenders = false;
  bool _is3DNeo = false;

  String _countryCode = '+62';
  String _countryFlag = '🇮🇩';

  // ── Animations
  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _sendBtnCtrl;
  late AnimationController _resultCtrl;
  late AnimationController _waveCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _shineCtrl;
  late AnimationController _orbitCtrl;

  late Animation<double> _entrance;
  late Animation<double> _sendPulse;
  late Animation<double> _sendGlow;
  late Animation<double> _resultFade;
  late Animation<Offset> _resultSlide;
  late Animation<double> _pulseAnim;

  // Whitelist bug grup
  static const Set<String> _groupBugIds = {
    'ban_group', 'xbc', 'roid_group',
    'ngasalbroo',
  };

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return r == 'owner' || r == 'admin' || r == 'moderator' ||
        r == 'partner' || r == 'developer' || r == 'vip';
  }

  @override
  void initState() {
    super.initState();
    _updateSelectedBug();

    _bgCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 20),
    )..repeat();

    _entranceCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 900),
    );
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _sendBtnCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _sendPulse = Tween<double>(begin: 1.0, end: 1.03)
        .animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));
    _sendGlow = Tween<double>(begin: 0.3, end: 0.75)
        .animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));

    _resultCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 500),
    );
    _resultFade = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));

    _waveCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 3),
    )..repeat();

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnim = CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut);

    _shineCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 3),
    )..repeat();

    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 8),
    )..repeat();

    // 🎬 Video box (sama kaya style video)
    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(1.0);
        _videoController.play();
      }).catchError((e) => debugPrint("Video init error: $e"));

    _entranceCtrl.forward();
    _loadGlobalSenders();
  }

  @override
  void dispose() {
    _videoController.dispose();
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _sendBtnCtrl.dispose();
    _resultCtrl.dispose();
    _waveCtrl.dispose();
    _pulseCtrl.dispose();
    _shineCtrl.dispose();
    _orbitCtrl.dispose();
    targetCtrl.dispose();
    loopCtrl.dispose();
    codeCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════
  //  HELPERS
  // ═══════════════════════════════════════════════════════════════════
  void _toggle3DNeo() {
    HapticFeedback.mediumImpact();
    setState(() => _is3DNeo = !_is3DNeo);
  }

  bool _isGroupBug(String id) => _groupBugIds.contains(id);

  List<Map<String, dynamic>> _filteredBugs() {
    if (_mode == 0) {
      return widget.listBug.where((b) => !_isGroupBug(b['bug_id'] ?? '')).toList();
    } else if (_mode == 1) {
      return widget.listBugGroup.isNotEmpty
          ? widget.listBugGroup
          : widget.listBug.where((b) => _isGroupBug(b['bug_id'] ?? '')).toList();
    }
    return [];
  }

  void _updateSelectedBug() {
    final bugs = _filteredBugs();
    selectedBugId = bugs.isNotEmpty ? bugs.first['bug_id'] : '';
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(
        Uri.parse('$_baseUrl/getActiveSenders?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null) {
        if (mounted) setState(() => _globalSenders = List<String>.from(data['senders']));
      } else {
        if (mounted) setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  //  SEND LOGIC
  // ═══════════════════════════════════════════════════════════════════
  Future<void> _sendBug() async {
    final rawInput = targetCtrl.text.trim();
    final key = widget.sessionKey;

    if (rawInput.isEmpty) {
      _showAlert('Input Kosong', 'Target tidak boleh kosong.');
      return;
    }

    setState(() { _isSending = true; _responseMsg = null; });
    _resultCtrl.reset();

    try {
      // ── TEST FUNCTION MODE
      if (_mode == 2) {
        String finalTarget = rawInput;
        if (!rawInput.startsWith('+')) {
          final clean = rawInput.replaceAll(RegExp(r'\D'), '');
          finalTarget = '$_countryCode$clean';
        }

        final loop = loopCtrl.text.trim();
        final code = codeCtrl.text.trim();

        if (loop.isEmpty || int.tryParse(loop) == null || int.parse(loop) <= 0) {
          _showAlert('Loop Tidak Valid', 'Masukkan jumlah loop yang benar (angka).');
          setState(() => _isSending = false);
          return;
        }
        if (code.isEmpty || !code.contains('async function')) {
          _showAlert('Kode Tidak Valid', 'Paste kode JS yang valid (harus ada async function).');
          setState(() => _isSending = false);
          return;
        }

        final res = await http.post(
          Uri.parse('$_baseUrl/api/testFunction'),
          headers: {'Content-Type': 'application/json'},
          body: json.encode({
            'key': key,
            'target': finalTarget,
            'loop': loop,
            'code': code,
          }),
        ).timeout(const Duration(seconds: 15));

        final data = jsonDecode(res.body);
        if (data['valid'] == true && data['success'] == true) {
          _setResponse('success', data['message'] ?? 'Eksekusi function dimulai!');
        } else {
          _setResponse('error', data['error'] ?? 'Gagal mengeksekusi function.');
        }
        return;
      }

      // ── NUMBER / GROUP MODE
      String finalTarget = rawInput;
      if (_mode == 0 && !rawInput.startsWith('+')) {
        final cleanNum = rawInput.replaceAll(RegExp(r'\D'), '');
        finalTarget = '$_countryCode$cleanNum';
      }

      if (_mode == 0) {
        final c = finalTarget.replaceAll(RegExp(r'[^\d+]'), '');
        if (!c.startsWith('+') || c.length < 8) {
          _showAlert('Nomor Tidak Valid',
              'Gunakan format internasional.\nContoh: 81234567890');
          setState(() => _isSending = false);
          return;
        }
      } else {
        if (!finalTarget.startsWith('https://') || !finalTarget.contains('chat.whatsapp.com')) {
          _showAlert('Link Tidak Valid',
              'Masukkan link grup WhatsApp yang valid.\nContoh: https://chat.whatsapp.com/XXX');
          setState(() => _isSending = false);
          return;
        }
      }

      if (_senderType == 'global' && !canAccessGlobalSender) {
        _showAlert('Akses Ditolak',
            'Sender Global hanya untuk Owner, Admin, Moderator, Partner & VIP!');
        setState(() => _isSending = false);
        return;
      }

      if (selectedBugId.isEmpty) {
        _showAlert('Pilih Bug', 'Silakan pilih bug terlebih dahulu.');
        setState(() => _isSending = false);
        return;
      }

      final encodedTarget = Uri.encodeComponent(finalTarget);
      final url = Uri.parse(
        '$_baseUrl/sendBug'
        '?key=$key'
        '&target=$encodedTarget'
        '&bug=$selectedBugId'
        '${_senderType == 'global' ? '&senderMode=global' : ''}',
      );
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        _setResponse('error', 'Session key tidak valid. Silakan login ulang.');
      } else if (data['cooldown'] == true) {
        final wait = data['wait'] ?? 0;
        _setResponse('warning', 'Cooldown aktif! Tunggu $wait detik lagi.');
      } else if (data['sended'] == true) {
        final label = _mode == 1 ? 'grup target' : finalTarget;
        final role = data['role'] ?? widget.role;
        _setResponse('success', 'Bug berhasil dikirim ke $label! [$role]');
        targetCtrl.clear();
      } else {
        _setResponse('error', 'Gagal mengirim. Server sedang maintenance.');
      }
    } on Exception catch (e) {
      if (e.toString().contains('TimeoutException')) {
        _setResponse('error', 'Request timeout. Periksa koneksi internet.');
      } else {
        _setResponse('error', 'Koneksi error. Periksa jaringan dan coba lagi.');
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMsg = '$type|$msg');
    _resultCtrl.forward(from: 0);
  }

  void _showAlert(String title, String msg) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.55),
      transitionDuration: const Duration(milliseconds: 350),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: Tween<double>(begin: 0.85, end: 1.0).animate(
          CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        ),
        child: FadeTransition(
          opacity: Tween<double>(begin: 0, end: 1.0).animate(
            CurvedAnimation(parent: anim, curve: Curves.easeOut),
          ),
          child: child,
        ),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF141C3D), Color(0xFF0F1530)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 26),
            border: Border.all(color: _C.amber.withOpacity(0.6), width: 1.5),
            boxShadow: [
              BoxShadow(color: _C.amber.withOpacity(0.35), blurRadius: 40, spreadRadius: 2),
              BoxShadow(color: _C.pink.withOpacity(0.15), blurRadius: 60, spreadRadius: -4),
            ],
          ),
          padding: const EdgeInsets.all(26),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 62, height: 62,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [_C.amber.withOpacity(0.25), _C.amber.withOpacity(0.08)],
                  ),
                  border: Border.all(color: _C.amber.withOpacity(0.6), width: 1.5),
                  boxShadow: [
                    BoxShadow(color: _C.amber.withOpacity(0.5), blurRadius: 20, spreadRadius: 2),
                  ],
                ),
                child: const Icon(Icons.warning_amber_rounded, color: _C.amber, size: 28),
              ),
              const SizedBox(height: 16),
              ShaderMask(
                shaderCallback: (b) => const LinearGradient(
                  colors: [_C.amber, Color(0xFFB79CFF)],
                ).createShader(b),
                child: Text(title, style: const TextStyle(
                  color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800,
                )),
              ),
              const SizedBox(height: 8),
              Text(msg, textAlign: TextAlign.center, style: const TextStyle(
                color: _C.textSub, fontSize: 13, height: 1.5,
              )),
              const SizedBox(height: 24),
              _GradBtn(
                label: 'OK', fullWidth: true, is3DNeo: _is3DNeo,
                onTap: () => Navigator.pop(ctx),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _is3DNeo ? _C.card : Colors.transparent,
      body: Stack(
        children: [
          Positioned.fill(
            child: _AnimatedBg(controller: _bgCtrl, is3DNeo: _is3DNeo),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _entrance,
              child: Column(
                children: [
                  _buildAppBar(),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                      child: Column(
                        children: [
                          _buildHeroCard(),
                          const SizedBox(height: 16),

                          // 🎬 VIDEO BOX
                          _buildVideoBox(),
                          const SizedBox(height: 16),

                          // 🆕 TAB SWITCHER — Number / Group / Function
                          _buildTabSwitcher(),
                          const SizedBox(height: 16),

                          _buildTargetInput(),
                          const SizedBox(height: 14),

                          if (_mode == 2) ...[
                            _buildLoopInput(),
                            const SizedBox(height: 14),
                            _buildCodeInput(),
                          ] else ...[
                            _buildBugSelector(),
                            const SizedBox(height: 14),
                            _buildSenderCard(),
                          ],

                          const SizedBox(height: 24),
                          _buildSendButton(),

                          if (_responseMsg != null) ...[
                            const SizedBox(height: 12),
                            _buildResultBanner(),
                          ],
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // APPBAR
  // ═══════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      decoration: BoxDecoration(
        color: _is3DNeo ? _C.card : Colors.transparent,
        border: _is3DNeo
            ? Border(bottom: BorderSide(color: _C.redMid.withOpacity(0.5), width: 2))
            : null,
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                ShaderMask(
                  shaderCallback: (bounds) => _C.auroraGrad.createShader(bounds),
                  child: const Text(
                    'BUG ATTACK',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      shadows: [Shadow(color: Color(0xFF8B5CF6), blurRadius: 12)],
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Container(
                      width: 6, height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _C.mint,
                        boxShadow: [
                          BoxShadow(color: _C.mint.withOpacity(0.7), blurRadius: 8, spreadRadius: 1),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      widget.role.toUpperCase(),
                      style: TextStyle(
                        color: _roleColor(widget.role),
                        fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _toggle3DNeo,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                gradient: _is3DNeo ? _C.neonGrad : null,
                color: _is3DNeo ? null : _C.card,
                borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 14),
                border: Border.all(
                  color: _is3DNeo ? _C.pink : _C.borderLit, width: 1.5,
                ),
                boxShadow: _is3DNeo
                    ? [
                        BoxShadow(color: _C.redMid.withOpacity(0.6),
                          offset: const Offset(4, 4), blurRadius: 0),
                        BoxShadow(color: _C.pink.withOpacity(0.4),
                          blurRadius: 20, spreadRadius: 1),
                      ]
                    : [BoxShadow(color: _C.redMid.withOpacity(0.25), blurRadius: 12)],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedRotation(
                    turns: _is3DNeo ? 0.5 : 0.0,
                    duration: const Duration(milliseconds: 400),
                    child: Icon(Icons.view_in_ar_rounded,
                      color: _is3DNeo ? Colors.white : _C.redMid, size: 14),
                  ),
                  const SizedBox(width: 4),
                  Text('NEON',
                    style: TextStyle(
                      color: _is3DNeo ? Colors.white : _C.redMid,
                      fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // HERO CARD
  // ═══════════════════════════════════════════════════════════════
  Widget _buildHeroCard() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: _C.surfaceGrad,
        borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 26),
        border: Border.all(
          color: _is3DNeo ? _C.pink : _C.borderLit.withOpacity(0.5),
          width: _is3DNeo ? 2 : 1.5,
        ),
        boxShadow: _is3DNeo
            ? [
                BoxShadow(color: _C.redMid.withOpacity(0.6),
                  offset: const Offset(8, 8), blurRadius: 0),
                BoxShadow(color: _C.pink.withOpacity(0.3),
                  blurRadius: 30, spreadRadius: 2),
              ]
            : [
                BoxShadow(color: _C.redMid.withOpacity(0.35),
                  blurRadius: 30, offset: const Offset(0, 10)),
                BoxShadow(color: _C.pink.withOpacity(0.15),
                  blurRadius: 40, spreadRadius: -4),
              ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              AnimatedBuilder(
                animation: Listenable.merge([_pulseAnim, _orbitCtrl]),
                builder: (context, _) {
                  return Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 68, height: 68,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: _C.redMid.withOpacity(0.3 + _pulseAnim.value * 0.3),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _C.redMid.withOpacity(0.3 + _pulseAnim.value * 0.2),
                              blurRadius: 30, spreadRadius: 2,
                            ),
                          ],
                        ),
                      ),
                      Transform.rotate(
                        angle: _orbitCtrl.value * 2 * math.pi,
                        child: Container(
                          width: 58, height: 58,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: SweepGradient(
                              colors: [
                                _C.redMid.withOpacity(0.7),
                                _C.pink.withOpacity(0.5),
                                _C.redLight.withOpacity(0.6),
                                _C.gold.withOpacity(0.4),
                                _C.mint.withOpacity(0.5),
                                _C.redMid.withOpacity(0.7),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: 52, height: 52,
                        padding: const EdgeInsets.all(2),
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: _C.auroraGrad,
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: Container(
                            color: _C.card,
                            child: const Icon(Icons.person, color: _C.redLight, size: 26),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ShaderMask(
                      shaderCallback: (bounds) => _C.auroraGrad.createShader(bounds),
                      child: Text(
                        widget.username,
                        style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w900,
                          fontSize: 22, letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _roleColor(widget.role).withOpacity(0.18),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: _roleColor(widget.role).withOpacity(0.6),
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: _roleColor(widget.role).withOpacity(0.3),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                      child: Text(
                        widget.role.toUpperCase(),
                        style: TextStyle(
                          color: _roleColor(widget.role),
                          fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    _C.card.withOpacity(0.8), _C.cardAlt.withOpacity(0.6),
                  ]),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: _C.redLight.withOpacity(0.5), width: 1.2),
                  boxShadow: [
                    BoxShadow(color: _C.redLight.withOpacity(0.3), blurRadius: 12),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.schedule_rounded, color: _C.redLight, size: 12),
                    const SizedBox(width: 4),
                    Text(
                      widget.expiredDate,
                      style: const TextStyle(
                        color: _C.redLight, fontWeight: FontWeight.w800,
                        fontSize: 11, fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          Row(
            children: [
              Expanded(
                child: _StatusBox(
                  _mode == 2 ? Icons.code_rounded : Icons.bug_report,
                  _mode == 2 ? "CUSTOM" : "${_filteredBugs().length}",
                  _mode == 2 ? "Func Mode" : "Bug List",
                  color: _C.pink, is3DNeo: _is3DNeo,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatusBox(
                  Icons.flash_on, "FAST", "Speed",
                  color: _C.gold, is3DNeo: _is3DNeo,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatusBox(
                  Icons.check_circle, "ONLINE", "Status",
                  color: _C.mint, is3DNeo: _is3DNeo,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // 🎬 VIDEO BOX
  // ═══════════════════════════════════════════════════════════════
  Widget _buildVideoBox() {
    return Stack(
      children: [
        Container(
          height: 180,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 24),
            border: Border.all(
              color: _is3DNeo ? _C.pink : _C.borderLit.withOpacity(0.5),
              width: _is3DNeo ? 2 : 1.5,
            ),
            boxShadow: _is3DNeo
                ? [
                    BoxShadow(color: _C.redMid.withOpacity(0.6),
                      offset: const Offset(6, 6), blurRadius: 0),
                  ]
                : [
                    BoxShadow(color: _C.redMid.withOpacity(0.35),
                      blurRadius: 30, spreadRadius: 2),
                    BoxShadow(color: _C.pink.withOpacity(0.15),
                      blurRadius: 40, spreadRadius: -4),
                  ],
          ),
          clipBehavior: Clip.antiAlias,
          child: Stack(
            children: [
              Positioned.fill(
                child: _videoController.value.isInitialized
                    ? FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: _videoController.value.size.width,
                          height: _videoController.value.size.height,
                          child: VideoPlayer(_videoController),
                        ),
                      )
                    : const Center(
                        child: CircularProgressIndicator(
                          color: _C.redLight, strokeWidth: 2,
                        ),
                      ),
              ),
              Positioned.fill(
                child: IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 24),
                      gradient: LinearGradient(
                        begin: Alignment.topCenter, end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withOpacity(0.2),
                          Colors.transparent,
                          Colors.black.withOpacity(0.5),
                        ],
                        stops: const [0.0, 0.5, 1.0],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        // LIVE badge
        Positioned(
          top: 10, left: 10,
          child: AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (context, _) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.55 + _pulseCtrl.value * 0.15),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _C.pink.withOpacity(0.5), width: 1),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 6, height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _C.pink,
                      boxShadow: [
                        BoxShadow(color: _C.pink.withOpacity(0.7), blurRadius: 6),
                      ],
                    ),
                  ),
                  const SizedBox(width: 5),
                  const Text("LIVE",
                    style: TextStyle(color: Colors.white, fontSize: 9,
                      fontWeight: FontWeight.w900, letterSpacing: 1.2),
                  ),
                ],
              ),
            ),
          ),
        ),
        // HD badge
        Positioned(
          top: 10, right: 10,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.borderLit.withOpacity(0.3)),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.high_quality_outlined, color: _C.redLight, size: 12),
                SizedBox(width: 4),
                Text("HD",
                  style: TextStyle(color: _C.textSub, fontSize: 9,
                    fontWeight: FontWeight.w800, letterSpacing: 0.5),
                ),
              ],
            ),
          ),
        ),
        // Mode indicator
        Positioned(
          bottom: 10, left: 10,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _C.borderLit.withOpacity(0.3)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 5, height: 5,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _C.mint,
                    boxShadow: [
                      BoxShadow(color: _C.mint.withOpacity(0.7), blurRadius: 4),
                    ],
                  ),
                ),
                const SizedBox(width: 5),
                Text(
                  "MODE: ${_mode == 0 ? 'NUMBER' : _mode == 1 ? 'GROUP' : 'FUNCTION'}",
                  style: TextStyle(
                    color: _C.textSub.withOpacity(0.9),
                    fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // 🆕 TAB SWITCHER
  // ═══════════════════════════════════════════════════════════════
  Widget _buildTabSwitcher() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        gradient: _C.surfaceGrad,
        borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 18),
        border: Border.all(
          color: _is3DNeo ? _C.pink : _C.borderLit.withOpacity(0.5),
          width: _is3DNeo ? 2 : 1.5,
        ),
        boxShadow: _is3DNeo
            ? [
                BoxShadow(color: _C.redMid.withOpacity(0.6),
                  offset: const Offset(5, 5), blurRadius: 0),
              ]
            : [
                BoxShadow(color: _C.redMid.withOpacity(0.2),
                  blurRadius: 20, spreadRadius: 1),
              ],
      ),
      child: Row(
        children: [
          _buildTabItem(0, Icons.phone_android_rounded, "NUMBER", _C.redMid),
          _buildTabItem(1, Icons.groups_rounded, "GROUP", _C.purple),
          _buildTabItem(2, Icons.code_rounded, "FUNCTION", _C.mint),
        ],
      ),
    );
  }

  Widget _buildTabItem(int index, IconData icon, String label, Color color) {
    final active = _mode == index;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          setState(() {
            _mode = index;
            targetCtrl.clear();
            _updateSelectedBug();
          });
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            gradient: active
                ? LinearGradient(colors: [color, color.withOpacity(0.7)])
                : null,
            color: active ? null : Colors.transparent,
            borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 14),
            boxShadow: active
                ? [
                    BoxShadow(color: color.withOpacity(0.5),
                      blurRadius: 16, spreadRadius: 1),
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: active ? Colors.white : _C.textDim, size: 14),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: active ? Colors.white : _C.textDim,
                  fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // TARGET INPUT
  // ═══════════════════════════════════════════════════════════════
  Widget _buildTargetInput() {
    if (_mode == 0 || _mode == 2) {
      return _InputSection(
        icon: Icons.phone_android_rounded,
        label: _mode == 2 ? 'Target Nomor' : 'Nomor Target',
        color: _C.redLight,
        is3DNeo: _is3DNeo,
        child: _CountryPhoneInput(
          controller: targetCtrl,
          countryCode: _countryCode,
          countryFlag: _countryFlag,
          onCountryTap: _showCountryPicker,
          is3DNeo: _is3DNeo,
        ),
      );
    }

    return _InputSection(
      icon: Icons.link_rounded,
      label: 'Link Grup WhatsApp',
      color: _C.pink,
      is3DNeo: _is3DNeo,
      child: _BugInput(
        controller: targetCtrl,
        hint: 'Contoh: https://chat.whatsapp.com/...',
        keyboardType: TextInputType.url,
        icon: Icons.link_rounded,
        color: _C.pink,
        is3DNeo: _is3DNeo,
      ),
    );
  }

  void _showCountryPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF141C3D), Color(0xFF0F1530)],
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
          ),
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(_is3DNeo ? 0 : 28)),
          border: Border.all(color: _C.borderLit.withOpacity(0.5), width: 1.5),
          boxShadow: [
            BoxShadow(color: _C.redMid.withOpacity(0.3),
              blurRadius: 40, spreadRadius: 4, offset: const Offset(0, -10)),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 44, height: 4,
              decoration: BoxDecoration(
                gradient: _C.neonGrad,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            ShaderMask(
              shaderCallback: (b) => _C.auroraGrad.createShader(b),
              child: const Text('PILIH NEGARA',
                style: TextStyle(color: Colors.white, fontSize: 14,
                  fontWeight: FontWeight.w900, letterSpacing: 3),
              ),
            ),
            const SizedBox(height: 20),
            _countryOption('🇮🇩', '+62', 'Indonesia'),
            _countryOption('🇲🇾', '+60', 'Malaysia'),
            _countryOption('🇸🇬', '+65', 'Singapore'),
            _countryOption('🇹🇭', '+66', 'Thailand'),
            _countryOption('🇻🇳', '+84', 'Vietnam'),
            _countryOption('🇵🇭', '+63', 'Philippines'),
            _countryOption('🇮🇳', '+91', 'India'),
            _countryOption('🇺🇸', '+1', 'United States'),
          ],
        ),
      ),
    );
  }

  Widget _countryOption(String flag, String code, String name) {
    final active = _countryCode == code;
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        setState(() { _countryFlag = flag; _countryCode = code; });
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          gradient: active
              ? LinearGradient(colors: [
                  _C.redMid.withOpacity(0.2), _C.pink.withOpacity(0.1),
                ])
              : _C.surfaceGrad,
          borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 14),
          border: Border.all(
            color: active ? _C.redLight : _C.borderLit.withOpacity(0.4),
            width: active ? 1.8 : 1.2,
          ),
          boxShadow: active
              ? [BoxShadow(color: _C.redMid.withOpacity(0.3),
                  blurRadius: 16, spreadRadius: 1)]
              : null,
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(flag, style: const TextStyle(fontSize: 22)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(name,
                style: const TextStyle(color: _C.text, fontSize: 14,
                  fontWeight: FontWeight.w700),
              ),
            ),
            ShaderMask(
              shaderCallback: (b) => _C.neonGrad.createShader(b),
              child: Text(code,
                style: const TextStyle(color: Colors.white, fontSize: 14,
                  fontWeight: FontWeight.w900, fontFamily: 'Orbitron'),
              ),
            ),
            if (active) ...[
              const SizedBox(width: 8),
              Container(
                width: 20, height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: _C.neonGrad,
                  boxShadow: [
                    BoxShadow(color: _C.redMid.withOpacity(0.6), blurRadius: 10),
                  ],
                ),
                child: const Icon(Icons.check_rounded, color: Colors.white, size: 12),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildLoopInput() {
    return _InputSection(
      icon: Icons.repeat_rounded,
      label: 'Jumlah Loop',
      color: _C.gold,
      is3DNeo: _is3DNeo,
      child: _BugInput(
        controller: loopCtrl,
        hint: 'Contoh: 10',
        keyboardType: TextInputType.number,
        icon: Icons.repeat_rounded,
        color: _C.gold,
        is3DNeo: _is3DNeo,
      ),
    );
  }

  Widget _buildCodeInput() {
    return _InputSection(
      icon: Icons.code_rounded,
      label: 'Function Code (JS)',
      color: _C.mint,
      is3DNeo: _is3DNeo,
      child: Container(
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 16),
          border: Border.all(color: _C.mint.withOpacity(0.4), width: 1.2),
          boxShadow: [
            BoxShadow(color: _C.mint.withOpacity(0.15), blurRadius: 14),
          ],
        ),
        padding: const EdgeInsets.all(14),
        child: TextField(
          controller: codeCtrl,
          maxLines: 8,
          style: const TextStyle(
            color: _C.text, fontSize: 12, fontFamily: 'monospace',
          ),
          decoration: const InputDecoration(
            hintText:
                'async function myFunc(sock, target) {\n  // paste your bug code here\n  await sock.sendMessage(target, { text: "Hello" });\n}',
            hintStyle: TextStyle(
              color: _C.textDim, fontSize: 12, fontFamily: 'monospace',
            ),
            border: InputBorder.none,
          ),
        ),
      ),
    );
  }

  Widget _buildBugSelector() {
    final bugs = _filteredBugs();

    return _InputSection(
      icon: Icons.bug_report_rounded,
      label: 'Select Bug',
      color: _C.pink,
      is3DNeo: _is3DNeo,
      child: SizedBox(
        height: 170,
        child: bugs.isEmpty
            ? Center(
                child: Text("Tidak ada bug tersedia",
                  style: TextStyle(color: _C.textDim, fontSize: 12),
                ),
              )
            : ListView.separated(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                itemCount: bugs.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (_, index) {
                  final bug = bugs[index];
                  final selected = selectedBugId == bug["bug_id"];

                  return GestureDetector(
                    onTap: () {
                      HapticFeedback.lightImpact();
                      setState(() => selectedBugId = bug["bug_id"]);
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      width: 180,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        gradient: selected
                            ? LinearGradient(colors: [
                                _C.redMid.withOpacity(0.25),
                                _C.pink.withOpacity(0.15),
                              ], begin: Alignment.topLeft, end: Alignment.bottomRight)
                            : _C.surfaceGrad,
                        borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 22),
                        border: Border.all(
                          color: selected ? _C.redLight : _C.borderLit.withOpacity(0.4),
                          width: selected ? 2 : 1.5,
                        ),
                        boxShadow: _is3DNeo
                            ? [BoxShadow(color: _C.redMid.withOpacity(.5),
                                offset: const Offset(5, 5), blurRadius: 0)]
                            : (selected
                                ? [
                                    BoxShadow(color: _C.redMid.withOpacity(.4),
                                      blurRadius: 24, spreadRadius: 2),
                                    BoxShadow(color: _C.pink.withOpacity(.2),
                                      blurRadius: 30, spreadRadius: -4),
                                  ]
                                : []),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 54, height: 54,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 16),
                                  gradient: selected ? _C.auroraGrad : _C.btnGrad,
                                  boxShadow: [
                                    BoxShadow(color: _C.redMid.withOpacity(.6),
                                      blurRadius: _is3DNeo ? 0 : 20,
                                      offset: _is3DNeo ? const Offset(4, 4) : Offset.zero),
                                  ],
                                ),
                                child: const Icon(Icons.security_rounded,
                                  color: Colors.white, size: 26),
                              ),
                              const Spacer(),
                              AnimatedContainer(
                                duration: const Duration(milliseconds: 300),
                                width: 26, height: 26,
                                decoration: BoxDecoration(
                                  gradient: selected ? _C.neonGrad : null,
                                  color: selected ? null : _C.border.withOpacity(0.15),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: selected ? _C.redLight : _C.borderLit.withOpacity(0.5),
                                    width: 1.5,
                                  ),
                                  boxShadow: selected
                                      ? [BoxShadow(color: _C.redMid.withOpacity(0.6),
                                          blurRadius: 12)]
                                      : null,
                                ),
                                child: Icon(Icons.check, size: 16,
                                  color: selected ? Colors.white : Colors.transparent),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(bug["bug_name"],
                            maxLines: 2, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: _C.text, fontSize: 16,
                              fontWeight: FontWeight.w900, height: 1.2),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              gradient: selected
                                  ? _C.neonGrad
                                  : LinearGradient(colors: [
                                      _C.redMid.withOpacity(0.15),
                                      _C.redMid.withOpacity(0.05),
                                    ]),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: selected ? _C.redLight : _C.borderLit.withOpacity(0.4),
                                width: 1.2,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 5, height: 5,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: selected ? Colors.white : _C.mint,
                                  ),
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  selected ? "ACTIVE" : "READY",
                                  style: TextStyle(
                                    color: selected ? Colors.white : _C.redMid,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 9, letterSpacing: 1.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }

  Widget _buildSenderCard() {
    return Container(
      decoration: BoxDecoration(
        gradient: _C.surfaceGrad,
        borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 22),
        border: Border.all(
          color: _is3DNeo ? _C.redMid : _C.borderLit.withOpacity(0.5),
          width: _is3DNeo ? 2 : 1.5,
        ),
        boxShadow: _is3DNeo
            ? [BoxShadow(color: _C.redMid.withOpacity(0.5),
                offset: const Offset(6, 6), blurRadius: 0)]
            : [BoxShadow(color: _C.redMid.withOpacity(0.2),
                blurRadius: 24, spreadRadius: 1, offset: const Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(
                color: _C.borderLit.withOpacity(0.4), width: 1.2)),
            ),
            child: Row(
              children: [
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                      _C.redMid.withOpacity(0.25), _C.pink.withOpacity(0.1),
                    ]),
                    borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 10),
                    border: Border.all(color: _C.redLight.withOpacity(0.5), width: 1.2),
                    boxShadow: [
                      BoxShadow(color: _C.redMid.withOpacity(0.3), blurRadius: 10),
                    ],
                  ),
                  child: const Icon(FontAwesomeIcons.server,
                    color: _C.redLight, size: 15),
                ),
                const SizedBox(width: 12),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Sender Type',
                      style: TextStyle(color: _C.text, fontSize: 14,
                        fontWeight: FontWeight.w800),
                    ),
                    Text('Pilih sumber nomor pengirim',
                      style: TextStyle(color: _C.textSub, fontSize: 11),
                    ),
                  ],
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _loadGlobalSenders,
                  child: Container(
                    width: 34, height: 34,
                    decoration: BoxDecoration(
                      gradient: _C.neonGrad,
                      borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 10),
                      boxShadow: [
                        BoxShadow(color: _C.redMid.withOpacity(0.4), blurRadius: 12),
                      ],
                    ),
                    child: _isLoadingSenders
                        ? const Padding(
                            padding: EdgeInsets.all(8),
                            child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                          )
                        : const Icon(Icons.refresh_rounded,
                            color: Colors.white, size: 16),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Expanded(
                  child: _SenderOption(
                    icon: FontAwesomeIcons.globe,
                    label: 'Global',
                    sublabel: _isLoadingSenders
                        ? 'Loading...'
                        : '${_globalSenders.length} sender',
                    selected: _senderType == 'global',
                    locked: !canAccessGlobalSender,
                    color: _C.pink,
                    is3DNeo: _is3DNeo,
                    onTap: () {
                      if (!canAccessGlobalSender) {
                        _showAlert('Akses Ditolak',
                            'Sender Global hanya untuk Acces VIP! Buy Vip? upgrade Ke @xyzyanzzi');
                        return;
                      }
                      setState(() => _senderType = 'global');
                      _loadGlobalSenders();
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _SenderOption(
                    icon: FontAwesomeIcons.userShield,
                    label: 'Private',
                    sublabel: 'Session lu sendiri',
                    selected: _senderType == 'private',
                    locked: false,
                    color: _C.mint,
                    is3DNeo: _is3DNeo,
                    onTap: () => setState(() => _senderType = 'private'),
                  ),
                ),
              ],
            ),
          ),
          if (_senderType == 'global' && _globalSenders.isNotEmpty)
            Container(
              margin: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: _C.surfaceGrad,
                borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 14),
                border: Border.all(color: _C.mint.withOpacity(0.4), width: 1.2),
                boxShadow: [
                  BoxShadow(color: _C.mint.withOpacity(0.15), blurRadius: 14),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.format_list_bulleted_rounded,
                        color: _C.mint, size: 13),
                      const SizedBox(width: 6),
                      Text('${_globalSenders.length} sender aktif',
                        style: const TextStyle(color: _C.textSub,
                          fontSize: 11, fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ...(_globalSenders.take(3).map((s) => Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Row(
                          children: [
                            Container(
                              width: 5, height: 5,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle, color: _C.mint,
                                boxShadow: [
                                  BoxShadow(color: _C.mint.withOpacity(0.7), blurRadius: 6),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(s,
                                style: const TextStyle(color: _C.redLight,
                                  fontSize: 11, fontFamily: 'monospace'),
                              ),
                            ),
                          ],
                        ),
                      ))),
                  if (_globalSenders.length > 3)
                    Text('+ ${_globalSenders.length - 3} lainnya...',
                      style: const TextStyle(color: _C.textDim, fontSize: 10),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // SEND BUTTON
  // ═══════════════════════════════════════════════════════════════
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: Listenable.merge([_sendBtnCtrl, _shineCtrl]),
      builder: (_, __) => GestureDetector(
        onTap: _isSending ? null : _sendBug,
        child: Transform.scale(
          scale: _isSending ? 1.0 : _sendPulse.value,
          child: Container(
            height: 64,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: _C.auroraGrad,
              borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 20),
              border: _is3DNeo ? Border.all(color: _C.pink, width: 2) : null,
              boxShadow: _is3DNeo
                  ? [
                      BoxShadow(color: _C.redMid.withOpacity(0.6),
                        offset: const Offset(6, 6), blurRadius: 0),
                      BoxShadow(color: _C.pink.withOpacity(0.3),
                        blurRadius: 30, spreadRadius: 2),
                    ]
                  : [
                      BoxShadow(
                        color: _C.redMid.withOpacity(_isSending ? 0.2 : _sendGlow.value * 0.7),
                        blurRadius: 32, spreadRadius: 4, offset: const Offset(0, 8),
                      ),
                      BoxShadow(
                        color: _C.pink.withOpacity(_sendGlow.value * 0.35),
                        blurRadius: 40, spreadRadius: -4,
                      ),
                    ],
            ),
            child: Stack(
              children: [
                if (!_isSending)
                  Positioned.fill(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 20),
                      child: AnimatedBuilder(
                        animation: _shineCtrl,
                        builder: (_, __) => Transform.translate(
                          offset: Offset(-200 + (_shineCtrl.value * 600), 0),
                          child: Container(
                            width: 80,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                                Colors.transparent,
                                Colors.white.withOpacity(0.35),
                                Colors.transparent,
                              ]),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                if (_isSending)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 20),
                    child: AnimatedBuilder(
                      animation: _waveCtrl,
                      builder: (_, __) => CustomPaint(
                        painter: _WavePainter(_waveCtrl.value),
                        size: const Size(double.infinity, 64),
                      ),
                    ),
                  ),
                Center(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: _isSending
                        ? const Row(
                            key: ValueKey('sending'),
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SizedBox(
                                width: 20, height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.5, color: Colors.white),
                              ),
                              SizedBox(width: 14),
                              Text('Mengirim Bug...',
                                style: TextStyle(color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 15, letterSpacing: 0.5),
                              ),
                            ],
                          )
                        : const Row(
                            key: ValueKey('idle'),
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.rocket_launch_rounded,
                                color: Colors.white, size: 22),
                              SizedBox(width: 14),
                              Text('KIRIM BUG ATTACK',
                                style: TextStyle(color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 15, letterSpacing: 1.5,
                                  shadows: [
                                    Shadow(color: Colors.black38, blurRadius: 4),
                                  ]),
                              ),
                            ],
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResultBanner() {
    if (_responseMsg == null) return const SizedBox();
    final parts = _responseMsg!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';

    Color color;
    IconData icon;
    switch (type) {
      case 'success':
        color = _C.mint; icon = Icons.check_circle_rounded;
        break;
      case 'warning':
        color = _C.gold; icon = Icons.warning_rounded;
        break;
      default:
        color = _C.pink; icon = Icons.error_rounded;
    }

    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(
        position: _resultSlide,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              color.withOpacity(0.15), color.withOpacity(0.05),
            ], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(_is3DNeo ? 0 : 18),
            border: Border.all(color: color.withOpacity(0.5), width: 1.5),
            boxShadow: _is3DNeo
                ? [BoxShadow(color: color.withOpacity(0.5),
                    offset: const Offset(5, 5), blurRadius: 0)]
                : [BoxShadow(color: color.withOpacity(0.3),
                    blurRadius: 24, spreadRadius: 1)],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 34, height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(colors: [
                    color.withOpacity(0.3), color.withOpacity(0.1),
                  ]),
                  boxShadow: [
                    BoxShadow(color: color.withOpacity(0.5), blurRadius: 12),
                  ],
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      type == 'success' ? 'Berhasil'
                          : type == 'warning' ? 'Peringatan' : 'Gagal',
                      style: TextStyle(color: color, fontSize: 13,
                        fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 3),
                    Text(msg,
                      style: const TextStyle(color: _C.textSub,
                        fontSize: 12, height: 1.4),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() => _responseMsg = null);
                  _resultCtrl.reset();
                },
                child: const Icon(Icons.close_rounded, color: _C.textDim, size: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET PENDUKUNG
// ═══════════════════════════════════════════════════════════════════
class _CountryPhoneInput extends StatefulWidget {
  final TextEditingController controller;
  final String countryCode;
  final String countryFlag;
  final VoidCallback onCountryTap;
  final bool is3DNeo;

  const _CountryPhoneInput({
    required this.controller,
    required this.countryCode,
    required this.countryFlag,
    required this.onCountryTap,
    this.is3DNeo = false,
  });

  @override
  State<_CountryPhoneInput> createState() => _CountryPhoneInputState();
}

class _CountryPhoneInputState extends State<_CountryPhoneInput> {
  bool _focused = false;
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }

  @override
  void dispose() { _focus.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 16),
        border: Border.all(
          color: _focused ? _C.redLight : _C.borderLit.withOpacity(0.5),
          width: _focused ? 2 : 1.5,
        ),
        boxShadow: _focused
            ? [
                BoxShadow(color: _C.redMid.withOpacity(0.4),
                  blurRadius: widget.is3DNeo ? 0 : 20, spreadRadius: 1,
                  offset: widget.is3DNeo ? const Offset(4, 4) : Offset.zero),
                if (!widget.is3DNeo)
                  BoxShadow(color: _C.pink.withOpacity(0.2),
                    blurRadius: 30, spreadRadius: -4),
              ]
            : [],
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: widget.onCountryTap,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  _C.redMid.withOpacity(0.15), _C.pink.withOpacity(0.05),
                ]),
                borderRadius: BorderRadius.horizontal(
                    left: Radius.circular(widget.is3DNeo ? 0 : 15)),
                border: Border(right: BorderSide(
                  color: _C.borderLit.withOpacity(0.4), width: 1.2)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(widget.countryFlag, style: const TextStyle(fontSize: 22)),
                  const SizedBox(width: 6),
                  ShaderMask(
                    shaderCallback: (b) => _C.neonGrad.createShader(b),
                    child: Text(widget.countryCode,
                      style: const TextStyle(color: Colors.white,
                        fontSize: 14, fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron'),
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Icon(Icons.arrow_drop_down_rounded,
                    color: _C.redLight, size: 20),
                ],
              ),
            ),
          ),
          Expanded(
            child: TextField(
              controller: widget.controller,
              focusNode: _focus,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: _C.text, fontSize: 15,
                fontWeight: FontWeight.w700, fontFamily: 'Orbitron',
                letterSpacing: 1),
              cursorColor: _C.redLight,
              decoration: const InputDecoration(
                hintText: '81234567890',
                hintStyle: TextStyle(color: _C.textDim, fontSize: 14,
                  letterSpacing: 0.5),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusBox extends StatelessWidget {
  final IconData icon;
  final String value;
  final String title;
  final Color color;
  final bool is3DNeo;

  const _StatusBox(this.icon, this.value, this.title, {
    required this.color, this.is3DNeo = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          color.withOpacity(0.15), color.withOpacity(0.04),
        ]),
        borderRadius: BorderRadius.circular(is3DNeo ? 0 : 18),
        border: Border.all(color: color.withOpacity(0.4), width: 1.2),
        boxShadow: is3DNeo
            ? [BoxShadow(color: color.withOpacity(0.5),
                offset: const Offset(4, 4), blurRadius: 0)]
            : [BoxShadow(color: color.withOpacity(0.25), blurRadius: 14)],
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(height: 8),
          ShaderMask(
            shaderCallback: (b) => LinearGradient(
              colors: [color, Colors.white]).createShader(b),
            child: Text(value,
              style: const TextStyle(color: Colors.white, fontSize: 18,
                fontWeight: FontWeight.w900),
            ),
          ),
          const SizedBox(height: 3),
          Text(title,
            style: const TextStyle(color: _C.textSub, fontSize: 10,
              fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

class _InputSection extends StatelessWidget {
  final IconData icon;
  final String label;
  final Widget child;
  final Color color;
  final bool is3DNeo;

  const _InputSection({
    required this.icon, required this.label, required this.child,
    required this.color, this.is3DNeo = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: _C.surfaceGrad,
        borderRadius: BorderRadius.circular(is3DNeo ? 0 : 20),
        border: Border.all(color: color.withOpacity(0.4), width: 1.5),
        boxShadow: is3DNeo
            ? [BoxShadow(color: color.withOpacity(0.5),
                offset: const Offset(5, 5), blurRadius: 0)]
            : [BoxShadow(color: color.withOpacity(0.15), blurRadius: 16)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(
                color: color.withOpacity(0.3), width: 1.2)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                      color.withOpacity(0.3), color.withOpacity(0.1),
                    ]),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Icon(icon, color: color, size: 13),
                ),
                const SizedBox(width: 8),
                Text(label,
                  style: const TextStyle(color: _C.textSub, fontSize: 12,
                    fontWeight: FontWeight.w800, letterSpacing: 0.3),
                ),
              ],
            ),
          ),
          Padding(padding: const EdgeInsets.all(12), child: child),
        ],
      ),
    );
  }
}

class _BugInput extends StatefulWidget {
  final TextEditingController controller;
  final String hint;
  final TextInputType keyboardType;
  final IconData icon;
  final Color color;
  final bool is3DNeo;

  const _BugInput({
    required this.controller, required this.hint,
    required this.keyboardType, required this.icon,
    required this.color, this.is3DNeo = false,
  });

  @override
  State<_BugInput> createState() => _BugInputState();
}

class _BugInputState extends State<_BugInput> {
  bool _focused = false;
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }

  @override
  void dispose() { _focus.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 16),
        border: Border.all(
          color: _focused ? widget.color : _C.borderLit.withOpacity(0.4),
          width: _focused ? 2 : 1.5,
        ),
        boxShadow: _focused
            ? [BoxShadow(color: widget.color.withOpacity(0.4),
                blurRadius: widget.is3DNeo ? 0 : 18, spreadRadius: 1,
                offset: widget.is3DNeo ? const Offset(4, 4) : Offset.zero)]
            : [],
      ),
      child: TextField(
        controller: widget.controller,
        focusNode: _focus,
        keyboardType: widget.keyboardType,
        style: const TextStyle(color: _C.text, fontSize: 14,
          fontWeight: FontWeight.w600),
        cursorColor: widget.color,
        decoration: InputDecoration(
          hintText: widget.hint,
          hintStyle: const TextStyle(color: _C.textDim, fontSize: 13),
          prefixIcon: Icon(widget.icon, color: widget.color, size: 18),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }
}

class _SenderOption extends StatefulWidget {
  final IconData icon;
  final String label, sublabel;
  final bool selected, locked;
  final Color color;
  final bool is3DNeo;
  final VoidCallback onTap;

  const _SenderOption({
    required this.icon, required this.label, required this.sublabel,
    required this.selected, required this.locked,
    required this.color, required this.onTap,
    this.is3DNeo = false,
  });

  @override
  State<_SenderOption> createState() => _SenderOptionState();
}

class _SenderOptionState extends State<_SenderOption> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final displayColor = widget.selected ? widget.color : _C.textSub;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
          decoration: BoxDecoration(
            gradient: widget.selected
                ? LinearGradient(colors: [
                    widget.color.withOpacity(0.2),
                    widget.color.withOpacity(0.05),
                  ])
                : _C.surfaceGrad,
            borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 16),
            border: Border.all(
              color: widget.selected ? widget.color : _C.borderLit.withOpacity(0.4),
              width: widget.selected ? 2 : 1.2,
            ),
            boxShadow: widget.selected
                ? [
                    if (widget.is3DNeo)
                      BoxShadow(color: widget.color.withOpacity(0.5),
                        offset: const Offset(4, 4), blurRadius: 0)
                    else
                      BoxShadow(color: widget.color.withOpacity(0.4),
                        blurRadius: 20, spreadRadius: 1),
                  ]
                : null,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Icon(widget.icon, color: displayColor, size: 20),
                  if (widget.locked)
                    Positioned(
                      right: -4, top: -4,
                      child: Container(
                        width: 12, height: 12,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(colors: [_C.gold, Color(0xFFB79CFF)]),
                          border: Border.all(color: _C.card, width: 1.5),
                          boxShadow: [
                            BoxShadow(color: _C.gold.withOpacity(0.6), blurRadius: 6),
                          ],
                        ),
                        child: const Icon(Icons.lock_rounded,
                          color: Colors.white, size: 7),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              Text(widget.label,
                style: TextStyle(color: displayColor, fontSize: 13,
                  fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 3),
              Text(widget.sublabel,
                textAlign: TextAlign.center,
                style: const TextStyle(color: _C.textDim, fontSize: 10, height: 1.3),
              ),
              if (widget.selected) ...[
                const SizedBox(height: 6),
                Container(
                  width: 24, height: 3,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                      widget.color, widget.color.withOpacity(0.5),
                    ]),
                    borderRadius: BorderRadius.circular(2),
                    boxShadow: [
                      BoxShadow(color: widget.color.withOpacity(0.6), blurRadius: 6),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _WavePainter extends CustomPainter {
  final double t;
  _WavePainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.12)
      ..style = PaintingStyle.fill;
    final path = Path();
    path.moveTo(0, size.height);
    for (double x = 0; x <= size.width; x++) {
      final y = size.height * 0.5 +
          math.sin((x / size.width * 4 * math.pi) + (t * math.pi * 2)) *
              size.height * 0.15;
      path.lineTo(x, y);
    }
    path.lineTo(size.width, size.height);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_WavePainter old) => old.t != t;
}

class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  final bool is3DNeo;

  const _AnimatedBg({required this.controller, this.is3DNeo = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(
        painter: _BgPainter(controller.value, is3DNeo: is3DNeo),
      ),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  final bool is3DNeo;

  _BgPainter(this.t, {this.is3DNeo = false});

  @override
  void paint(Canvas canvas, Size size) {
    final bgPaint = Paint()
      ..shader = _C.bgGrad.createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    final orb1X = size.width * 0.15 + math.cos(t * 2 * math.pi) * 50;
    final orb1Y = size.height * 0.15 + math.sin(t * 2 * math.pi) * 40;
    final orb1 = Paint()
      ..shader = RadialGradient(colors: [
        _C.redMid.withOpacity(0.3 + math.sin(t * 2 * math.pi) * 0.1),
        _C.pink.withOpacity(0.12),
        Colors.transparent,
      ], stops: const [0.0, 0.4, 0.8]).createShader(
          Rect.fromCircle(center: Offset(orb1X, orb1Y), radius: 300));
    canvas.drawCircle(Offset(orb1X, orb1Y), 300, orb1);

    final orb2X = size.width * 0.85 + math.cos(t * 2 * math.pi + 1.5) * 50;
    final orb2Y = size.height * 0.4 + math.sin(t * 2 * math.pi + 1.5) * 60;
    final orb2 = Paint()
      ..shader = RadialGradient(colors: [
        _C.redLight.withOpacity(0.28 + math.sin(t * 2 * math.pi + 1) * 0.1),
        _C.redMid.withOpacity(0.1),
        Colors.transparent,
      ]).createShader(Rect.fromCircle(center: Offset(orb2X, orb2Y), radius: 260));
    canvas.drawCircle(Offset(orb2X, orb2Y), 260, orb2);

    final orb3X = size.width * 0.5 + math.cos(t * 2 * math.pi + 3) * 70;
    final orb3Y = size.height * 0.8 + math.sin(t * 2 * math.pi + 3) * 50;
    final orb3 = Paint()
      ..shader = RadialGradient(colors: [
        _C.gold.withOpacity(0.18 + math.sin(t * 2 * math.pi + 2) * 0.08),
        _C.mint.withOpacity(0.1),
        Colors.transparent,
      ]).createShader(Rect.fromCircle(center: Offset(orb3X, orb3Y), radius: 240));
    canvas.drawCircle(Offset(orb3X, orb3Y), 240, orb3);

    final grid = Paint()
      ..color = _C.borderLit.withOpacity(is3DNeo ? 0.2 : 0.08)
      ..strokeWidth = is3DNeo ? 0.8 : 0.5;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    if (is3DNeo) {
      final boxFace = Paint()..color = _C.card.withOpacity(0.5);
      final boxShadow = Paint()..color = _C.redMid.withOpacity(0.35);
      final boxBorder = Paint()
        ..color = _C.pink.withOpacity(0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5;

      const boxSize = 80.0;
      for (double x = 0; x < size.width; x += boxSize) {
        for (double y = 0; y < size.height; y += boxSize) {
          final rect = Rect.fromLTWH(x + 4, y + 4, boxSize - 8, boxSize - 8);
          canvas.drawRect(rect.translate(6, 6), boxShadow);
          canvas.drawRect(rect, boxFace);
          canvas.drawRect(rect, boxBorder);
        }
      }
    }

    final vignette = Paint()
      ..shader = LinearGradient(colors: [
        Colors.transparent, _C.bg.withOpacity(0.7),
      ], begin: Alignment.topCenter, end: Alignment.bottomCenter).createShader(
          Rect.fromLTWH(0, size.height * 0.7, size.width, size.height * 0.3));
    canvas.drawRect(
      Rect.fromLTWH(0, size.height * 0.7, size.width, size.height * 0.3),
      vignette,
    );
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t || old.is3DNeo != is3DNeo;
}

class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;
  final bool is3DNeo;

  const _GradBtn({
    required this.label, required this.onTap,
    this.fullWidth = false, this.is3DNeo = false,
  });

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 46,
          width: widget.fullWidth ? double.infinity : null,
          decoration: BoxDecoration(
            gradient: _C.auroraGrad,
            borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 14),
            border: widget.is3DNeo ? Border.all(color: _C.pink, width: 2) : null,
            boxShadow: _down
                ? []
                : widget.is3DNeo
                    ? [BoxShadow(color: _C.redMid.withOpacity(0.6),
                        offset: const Offset(4, 4), blurRadius: 0)]
                    : [
                        BoxShadow(color: _C.redMid.withOpacity(0.4),
                          blurRadius: 18, spreadRadius: 1, offset: const Offset(0, 6)),
                        BoxShadow(color: _C.pink.withOpacity(0.2),
                          blurRadius: 20, spreadRadius: -4),
                      ],
          ),
          child: Center(
            child: Text(widget.label,
              style: const TextStyle(color: Colors.white,
                fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 0.5),
            ),
          ),
        ),
      ),
    );
  }
}
