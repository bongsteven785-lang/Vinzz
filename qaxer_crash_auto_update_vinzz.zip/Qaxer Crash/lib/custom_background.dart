import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

class CustomBackgroundConfig {
  final String? path;
  final bool isVideo;
  final double opacity;
  const CustomBackgroundConfig({this.path, this.isVideo = false, this.opacity = .30});
  CustomBackgroundConfig copyWith({String? path, bool? isVideo, double? opacity}) => CustomBackgroundConfig(path: path ?? this.path, isVideo: isVideo ?? this.isVideo, opacity: opacity ?? this.opacity);
}

class CustomBackgroundManager {
  CustomBackgroundManager._();
  static final ValueNotifier<CustomBackgroundConfig> current = ValueNotifier(const CustomBackgroundConfig());
  static const _pathKey = 'night_core_custom_bg_path';
  static const _videoKey = 'night_core_custom_bg_video';
  static const _opacityKey = 'night_core_custom_bg_opacity';

  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString(_pathKey);
    final isVideo = prefs.getBool(_videoKey) ?? false;
    final opacity = prefs.getDouble(_opacityKey) ?? .30;
    if (path != null && File(path).existsSync()) {
      current.value = CustomBackgroundConfig(path: path, isVideo: isVideo, opacity: opacity);
    }
  }

  static Future<void> pick({required bool video}) async {
    final picker = ImagePicker();
    final XFile? selected = video
        ? await picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 5))
        : await picker.pickImage(source: ImageSource.gallery, imageQuality: 92);
    if (selected == null) return;
    final directory = await getApplicationDocumentsDirectory();
    final extension = selected.path.contains('.') ? selected.path.substring(selected.path.lastIndexOf('.')) : (video ? '.mp4' : '.jpg');
    final destination = File('${directory.path}/night_core_custom_background${video ? '_video' : '_image'}$extension');
    await File(selected.path).copy(destination.path);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_pathKey, destination.path);
    await prefs.setBool(_videoKey, video);
    current.value = current.value.copyWith(path: destination.path, isVideo: video);
  }

  static Future<void> setOpacity(double value) async {
    current.value = current.value.copyWith(opacity: value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_opacityKey, value);
  }

  static Future<void> clear() async {
    final old = current.value.path;
    current.value = const CustomBackgroundConfig();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_pathKey);
    await prefs.remove(_videoKey);
    if (old != null) { try { final f = File(old); if (await f.exists()) await f.delete(); } catch (_) {} }
  }
}

/// App-wide background layer. It sits behind routes and respects a dark tint
/// so foreground text remains readable.
class CustomBackgroundLayer extends StatelessWidget {
  final Widget child;
  const CustomBackgroundLayer({super.key, required this.child});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<CustomBackgroundConfig>(
    valueListenable: CustomBackgroundManager.current,
    builder: (context, config, _) => Stack(fit: StackFit.expand, children: [
      const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF100A1B), Color(0xFF090612)]))),
      if (config.path != null && File(config.path!).existsSync())
        Positioned.fill(child: config.isVideo ? _LoopingBackgroundVideo(path: config.path!, opacity: config.opacity) : Opacity(opacity: config.opacity, child: Image.file(File(config.path!), fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()))),
      // Subtle active-theme wash makes theme changes visible even on routes
      // containing legacy widgets with fixed colors, without recoloring text.
      Positioned.fill(
        child: IgnorePointer(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Theme.of(context).colorScheme.primary.withOpacity(config.path == null ? 0.035 : 0.07),
                  Colors.transparent,
                  Theme.of(context).colorScheme.secondary.withOpacity(config.path == null ? 0.02 : 0.045),
                ],
              ),
            ),
          ),
        ),
      ),
      Positioned.fill(child: ColoredBox(color: Colors.black.withOpacity(config.path == null ? 0 : .20))),
      child,
    ]),
  );
}

class _LoopingBackgroundVideo extends StatefulWidget {
  final String path;
  final double opacity;
  const _LoopingBackgroundVideo({required this.path, required this.opacity});
  @override
  State<_LoopingBackgroundVideo> createState() => _LoopingBackgroundVideoState();
}
class _LoopingBackgroundVideoState extends State<_LoopingBackgroundVideo> {
  VideoPlayerController? _controller;
  @override
  void initState() { super.initState(); _init(); }
  Future<void> _init() async {
    final c = VideoPlayerController.file(File(widget.path));
    _controller = c;
    try { await c.initialize(); await c.setLooping(true); await c.setVolume(0); await c.play(); if (mounted) setState(() {}); }
    catch (_) { await c.dispose(); }
  }
  @override
  void didUpdateWidget(covariant _LoopingBackgroundVideo oldWidget) { super.didUpdateWidget(oldWidget); if (oldWidget.path != widget.path) { _controller?.dispose(); _controller = null; _init(); } }
  @override
  void dispose() { _controller?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) { final c = _controller; if (c == null || !c.value.isInitialized) return const SizedBox.expand(); return Opacity(opacity: widget.opacity, child: FittedBox(fit: BoxFit.cover, child: SizedBox(width: c.value.size.width, height: c.value.size.height, child: VideoPlayer(c)))); }
}

class CustomBackgroundSettingsPage extends StatefulWidget {
  const CustomBackgroundSettingsPage({super.key});
  @override
  State<CustomBackgroundSettingsPage> createState() => _CustomBackgroundSettingsPageState();
}
class _CustomBackgroundSettingsPageState extends State<CustomBackgroundSettingsPage> {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Background Kustom')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: theme.colorScheme.surface.withOpacity(.88), borderRadius: BorderRadius.circular(22), border: Border.all(color: theme.colorScheme.primary.withOpacity(.65))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.wallpaper_rounded, size: 38, color: theme.colorScheme.primary), const SizedBox(height: 12),
          Text('Background dari Galeri', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 8),
          Text('Pilih foto atau video sendiri. Background disimpan di perangkat dan dipakai di belakang halaman aplikasi yang transparan.', style: theme.textTheme.bodyMedium), const SizedBox(height: 18),
          Wrap(spacing: 10, runSpacing: 10, children: [
            FilledButton.icon(onPressed: () async { await CustomBackgroundManager.pick(video: false); if (mounted) setState(() {}); }, icon: const Icon(Icons.photo_library_rounded), label: const Text('Pilih Foto')),
            FilledButton.icon(onPressed: () async { await CustomBackgroundManager.pick(video: true); if (mounted) setState(() {}); }, icon: const Icon(Icons.video_library_rounded), label: const Text('Pilih Video')),
            OutlinedButton.icon(onPressed: () async { await CustomBackgroundManager.clear(); if (mounted) setState(() {}); }, icon: const Icon(Icons.restart_alt_rounded), label: const Text('Reset')),
          ]),
        ])),
        const SizedBox(height: 16),
        ValueListenableBuilder<CustomBackgroundConfig>(valueListenable: CustomBackgroundManager.current, builder: (context, config, _) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(config.path == null ? 'Belum ada background kustom' : (config.isVideo ? 'Video aktif' : 'Foto aktif'), style: theme.textTheme.titleMedium), const SizedBox(height: 6),
          Text(config.path ?? 'Pilih media dari galeri untuk mulai.', style: theme.textTheme.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis), const SizedBox(height: 14),
          Text('Kekuatan background: ${(config.opacity * 100).round()}%'),
          Slider(value: config.opacity, min: .08, max: .70, divisions: 31, onChanged: (v) => CustomBackgroundManager.setOpacity(v)),
          const Text('Tip: opacity rendah membuat teks dan kartu lebih mudah dibaca.'),
        ])))),
      ]),
    );
  }
}
