import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'music_page.dart';
import 'package:Fiona/Qaxer/.dart';
final baseUrl = Api.api;

// ────────────────────────────────────────────────────────────────────────────
//  PALETTE — AURORA VIBRANT
// ────────────────────────────────────────────────────────────────────────────
class _C {
  // Background — deep cosmic
  static const bg         = Color(0xFF060918);
  static const bgAlt      = Color(0xFF0A0D24);
  static const surface    = Color(0xFF0F1530);
  static const card       = Color(0xFF141C3D);
  static const cardAlt    = Color(0xFF1A2450);
  static const border     = Color(0xFF2A3566);
  static const borderLit  = Color(0xFF4A5DA8);

  // Vibrant palette
  static const steel      = Color(0xFF6D28D9);
  static const blueMid    = Color(0xFF8B5CF6);
  static const blueLight  = Color(0xFF9B6DFF);
  static const chrome     = Color(0xFF9B6DFF);
  static const frost      = Color(0xFFEDE7FF);

  static const pink       = Color(0xFF8B5CF6);
  static const gold       = Color(0xFF9B6DFF);
  static const mint       = Color(0xFFB79CFF);

  // Status
  static const green      = Color(0xFFB79CFF);
  static const amber      = Color(0xFF9B6DFF);
  static const red        = Color(0xFF8B5CF6);

  // Text
  static const text       = Color(0xFFF8FAFF);
  static const textSub    = Color(0xFFB4C0E0);
  static const textDim    = Color(0xFF6B78A0);

  // Gradient utama
  static const LinearGradient metalGrad = LinearGradient(
    colors: [Color(0xFF6D28D9), Color(0xFF8B5CF6), Color(0xFF9B6DFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient auroraGrad = LinearGradient(
    colors: [
      Color(0xFF6D28D9), Color(0xFF8B5CF6),
      Color(0xFF9B6DFF), Color(0xFFB79CFF),
      Color(0xFF9B6DFF), Color(0xFF8B5CF6),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient neonGrad = LinearGradient(
    colors: [Color(0xFF9B6DFF), Color(0xFF8B5CF6), Color(0xFF8B5CF6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient creamGrad = LinearGradient(
    colors: [Color(0xFF060918), Color(0xFF0F1530), Color(0xFF0A0D24)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient textGrad = LinearGradient(
    colors: [Color(0xFF9B6DFF), Color(0xFF8B5CF6), Color(0xFF8B5CF6)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient surfaceGrad = LinearGradient(
    colors: [Color(0xFF141C3D), Color(0xFF0F1530)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ────────────────────────────────────────────────────────────────────────────
//  LOGIN PAGE
// ────────────────────────────────────────────────────────────────────────────
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userCtrl    = TextEditingController();
  final passCtrl    = TextEditingController();
  final _formKey    = GlobalKey<FormState>();
  static const platform = MethodChannel('app_security');

  bool _isLoading       = false;
  bool _obscurePass     = true;
  String? _androidId;

  // ═══ TEMA NEON ═══
  bool _is3DNeoMode = false;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _logoCtrl;
  late AnimationController _btnCtrl;
  late AnimationController _shakeCtrl;
  late AnimationController _orbitCtrl;
  late AnimationController _shineCtrl;

  late Animation<double> _fade;
  late Animation<Offset>  _slide;
  late Animation<double>  _logoGlow;
  late Animation<double>  _btnPulse;
  late Animation<double>  _shake;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 20))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    _fade  = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl, curve: Curves.easeOutCubic));

    _logoCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);
    _logoGlow = Tween<double>(begin: 0.3, end: 0.85)
        .animate(CurvedAnimation(parent: _logoCtrl, curve: Curves.easeInOut));

    _btnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1600))
      ..repeat(reverse: true);
    _btnPulse = Tween<double>(begin: 1.0, end: 1.03)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));

    _orbitCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 8))
      ..repeat();

    _shineCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 3))
      ..repeat();

    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -10.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -10.0, end: 10.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 10.0, end: -7.0),  weight: 2),
      TweenSequenceItem(tween: Tween(begin: -7.0, end: 7.0),   weight: 2),
      TweenSequenceItem(tween: Tween(begin: 7.0, end: 0.0),    weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    _entranceCtrl.forward();
    _initLogin();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _logoCtrl.dispose();
    _btnCtrl.dispose();
    _shakeCtrl.dispose();
    _orbitCtrl.dispose();
    _shineCtrl.dispose();
    userCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  void _toggle3DNeo() {
    HapticFeedback.mediumImpact();
    setState(() => _is3DNeoMode = !_is3DNeoMode);
  }

  Future<void> _initLogin() async {
    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      _androidId = deviceInfo.id;

      final packageInfo = await PackageInfo.fromPlatform();
      final appVersion = packageInfo.version;

      String appCertificate;
      try {
        appCertificate =
            await platform.invokeMethod<String>('getSignature') ?? '';
      } catch (_) {
        appCertificate = '';
      }

      if (appVersion.isEmpty || appCertificate.isEmpty) {
        if (!mounted) return;
        _showAlert(
          title: 'APK Tidak Valid',
          message: 'Informasi keamanan aplikasi tidak dapat diverifikasi.',
          type: _AlertType.error,
          showContact: true,
        );
        return;
      }

      final prefs = await SharedPreferences.getInstance();
      final savedUser = prefs.getString('username');
      final savedPass = prefs.getString('password');
      final savedKey = prefs.getString('key');

      if (savedUser == null || savedPass == null || savedKey == null) {
        return;
      }

      final uri = Uri.parse('$baseUrl/myInfo').replace(
        queryParameters: {
          'username': savedUser,
          'password': savedPass,
          'androidId': _androidId ?? '',
          'key': savedKey,
          'appVersion': appVersion,
          'appCertificate': appCertificate,
        },
      );

      final res = await http.get(uri);
      final data = jsonDecode(res.body);

      if (data['error'] == 'SECURITY_FAILED' ||
          data['error'] == 'SECURITY_REQUIRED') {
        if (!mounted) return;
        _showAlert(
          title: 'Akses Ditolak',
          message: data['message'] ?? 'APK tidak valid.',
          type: _AlertType.error,
          showContact: true,
        );
        return;
      }

      if (data['valid'] == true && mounted) {
        await _updateFCM(savedKey);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => MusicIntroPage(
              username: savedUser,
              password: savedPass,
              role: data['role'],
              sessionKey: data['key'],
              expiredDate: data['expiredDate'],
              listBug: _parseList(data['listBug']),
              listBugGroup: _parseList(data['listBugGroup']),
              listDoos: _parseList(data['listDDoS']),
              news: _parseList(data['news']),
              jjVideos: _parseList(data['jjVideos']),
              thanksTo: _parseList(data['thanksTo']),
            ),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      _showAlert(
        title: 'Koneksi Error',
        message: 'Gagal terhubung ke server. Periksa jaringan Anda.',
        type: _AlertType.error,
      );
    }
  }

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  Future<void> _updateFCM(String sessionKey) async {
    try {
      await FirebaseMessaging.instance.requestPermission();
      final token = await FirebaseMessaging.instance.getToken();
      if (token == null) return;
      await http.get(
        Uri.parse('$baseUrl/updateFCM?key=$sessionKey&token=${Uri.encodeComponent(token)}'),
      );
    } catch(_){}
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    setState(() => _isLoading = true);

    try {
      String appVersion = "";
      String appCertificate = "";

      final info = await PackageInfo.fromPlatform();
      appVersion = info.version;

      try {
        appCertificate =
            await platform.invokeMethod<String>('getSignature') ?? '';
      } catch (_) {
        appCertificate = '';
      }

      if (appVersion.isEmpty || appCertificate.isEmpty) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'APK Tidak Valid',
          message: 'Informasi keamanan aplikasi tidak dapat diverifikasi.',
          type: _AlertType.error,
          showContact: true,
        );
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      final res = await http.post(Uri.parse('$baseUrl/validate'), body: {
        'username': username,
        'password': password,
        'androidId': _androidId ?? 'unknown',
        'appVersion': appVersion,
        'appCertificate': appCertificate,
      });

      final data = jsonDecode(res.body);

      if (data['error'] == 'SECURITY_FAILED') {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akses Ditolak',
          message: data['message'] ?? 'APK tidak valid.',
          type: _AlertType.error,
          showContact: true,
        );
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      if (data['maintenance'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Maintenance',
          message: data['message'] ?? 'Server sedang dalam pemeliharaan.',
          type: _AlertType.warning,
        );
      } else if (data['banned'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akun Dibanned',
          message: data['message'] ?? 'Akun Anda telah dibanned oleh Admin.',
          type: _AlertType.error,
        );
      } else if (data['expired'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akses Habis',
          message: 'Masa akses Anda telah berakhir. Silakan perpanjang.',
          type: _AlertType.warning,
          showContact: true,
        );
      } else if (data['valid'] != true) {
        _shakeCtrl.forward(from: 0);
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') || msg.contains('device') ||
            msg.contains('another')) {
          _showAlert(
            title: 'Sesi Aktif',
            message: 'Akun ini sedang login di perangkat lain.',
            type: _AlertType.warning,
          );
        } else {
          _showAlert(
            title: 'Login Gagal',
            message: 'Username atau password salah.',
            type: _AlertType.error,
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('username', username);
        prefs.setString('password', password);
        prefs.setString('key', data['key']);
        await _updateFCM(data['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => MusicIntroPage(
              username: username, password: password,
              role: data['role'], sessionKey: data['key'],
              expiredDate: data['expiredDate'],
              listBug:  _parseList(data['listBug']),
              listBugGroup:  _parseList(data['listBugGroup']),
              listDoos: _parseList(data['listDDoS']),
              news:     _parseList(data['news']),
              jjVideos: _parseList(data['jjVideos']),
              thanksTo: _parseList(data['thanksTo']),
            )),
          );
        }
      }
    } catch (_) {
      _shakeCtrl.forward(from: 0);
      _showAlert(
        title: 'Koneksi Error',
        message: 'Gagal terhubung ke server. Periksa jaringan Anda.',
        type: _AlertType.error,
      );
    }

    if (mounted) setState(() => _isLoading = false);
  }

  void _showAlert({
    required String title,
    required String message,
    required _AlertType type,
    bool showContact = false,
  }) {
    final color = switch (type) {
      _AlertType.error   => _C.red,
      _AlertType.warning => _C.amber,
      _AlertType.success => _C.green,
    };
    final icon = switch (type) {
      _AlertType.error   => Icons.error_rounded,
      _AlertType.warning => Icons.warning_amber_rounded,
      _AlertType.success => Icons.check_circle_rounded,
    };

    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.55),
      transitionDuration: const Duration(milliseconds: 320),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF141C3D), Color(0xFF0F1530)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(_is3DNeoMode ? 0 : 26),
            border: Border.all(color: color.withOpacity(0.6), width: 1.5),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.35), blurRadius: 40, spreadRadius: 2),
              BoxShadow(color: color.withOpacity(0.15), blurRadius: 60, spreadRadius: -4),
            ],
          ),
          padding: const EdgeInsets.all(26),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 62, height: 62,
              decoration: BoxDecoration(
                shape: _is3DNeoMode ? BoxShape.rectangle : BoxShape.circle,
                borderRadius: _is3DNeoMode ? BorderRadius.circular(8) : null,
                gradient: LinearGradient(
                  colors: [color.withOpacity(0.25), color.withOpacity(0.08)],
                ),
                border: Border.all(color: color.withOpacity(0.6), width: 1.5),
                boxShadow: [
                  BoxShadow(color: color.withOpacity(0.5), blurRadius: 20, spreadRadius: 2),
                ],
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(height: 18),
            ShaderMask(
              shaderCallback: (b) => LinearGradient(
                colors: [color, Colors.white],
              ).createShader(b),
              child: Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Aktura',
                  letterSpacing: 0.3,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: _C.textSub,
                fontSize: 13,
                height: 1.5,
                fontFamily: 'Aktura',
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 22),
            if (showContact) ...[
              _GradBtn(
                label: 'Hubungi Admin',
                fullWidth: true,
                is3DNeo: _is3DNeoMode,
                onTap: () async {
                  Navigator.pop(ctx);
                  await launchUrl(Uri.parse('https://t.me/vinzzsukakmu'), mode: LaunchMode.externalApplication);
                },
              ),
              const SizedBox(height: 10),
            ],
            _OutlineBtn(
              label: showContact ? 'Tutup' : 'OK',
              fullWidth: true,
              is3DNeo: _is3DNeoMode,
              onTap: () => Navigator.pop(ctx),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl, is3DNeo: _is3DNeoMode)),

          Positioned(
            top: 12,
            right: 16,
            child: SafeArea(
              child: _build3DNeoButton(),
            ),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: Center(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 60),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildLogo(),
                        const SizedBox(height: 32),
                        _buildHeading(),
                        const SizedBox(height: 36),
                        AnimatedBuilder(
                          animation: _shake,
                          builder: (_, child) => Transform.translate(
                            offset: Offset(_shake.value, 0),
                            child: child,
                          ),
                          child: _buildForm(),
                        ),
                        const SizedBox(height: 28),
                        _buildFooter(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // TOMBOL NEON
  // ═══════════════════════════════════════════════════════════════
  Widget _build3DNeoButton() {
    return GestureDetector(
      onTap: _toggle3DNeo,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          gradient: _is3DNeoMode ? _C.neonGrad : null,
          color: _is3DNeoMode ? null : _C.card,
          borderRadius: BorderRadius.circular(_is3DNeoMode ? 0 : 12),
          border: Border.all(
            color: _is3DNeoMode ? _C.pink : _C.borderLit,
            width: 1.5,
          ),
          boxShadow: _is3DNeoMode
              ? [
                  BoxShadow(color: _C.blueMid.withOpacity(0.6), offset: const Offset(4, 4), blurRadius: 0),
                  BoxShadow(color: _C.pink.withOpacity(0.3), blurRadius: 20, spreadRadius: 1),
                ]
              : [
                  BoxShadow(color: _C.blueMid.withOpacity(0.25), blurRadius: 12, offset: const Offset(0, 4)),
                ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedRotation(
              turns: _is3DNeoMode ? 0.5 : 0.0,
              duration: const Duration(milliseconds: 400),
              child: Icon(
                Icons.view_in_ar_rounded,
                size: 16,
                color: _is3DNeoMode ? Colors.white : _C.blueMid,
              ),
            ),
            const SizedBox(width: 6),
            Text(
              'NEON',
              style: TextStyle(
                color: _is3DNeoMode ? Colors.white : _C.blueMid,
                fontSize: 11,
                fontWeight: FontWeight.w900,
                fontFamily: 'Aktura',
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // LOGO — FIXED ✅ (padding pindah ke Container)
  // ═══════════════════════════════════════════════════════════════
  Widget _buildLogo() {
    return AnimatedBuilder(
      animation: Listenable.merge([_logoGlow, _orbitCtrl]),
      builder: (_, __) => Stack(
        alignment: Alignment.center,
        children: [
          // Ring luar
          Container(
            width: 130, height: 130,
            decoration: BoxDecoration(
              shape: _is3DNeoMode ? BoxShape.rectangle : BoxShape.circle,
              borderRadius: _is3DNeoMode ? BorderRadius.circular(0) : null,
              border: Border.all(
                color: _C.blueMid.withOpacity(_logoGlow.value * 0.3),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: _C.blueMid.withOpacity(_logoGlow.value * 0.25),
                  blurRadius: 40,
                  spreadRadius: 4,
                ),
              ],
            ),
          ),
          // Orbit sweep gradient
          Transform.rotate(
            angle: _orbitCtrl.value * 2 * math.pi,
            child: Container(
              width: 110, height: 110,
              decoration: BoxDecoration(
                shape: _is3DNeoMode ? BoxShape.rectangle : BoxShape.circle,
                borderRadius: _is3DNeoMode ? BorderRadius.circular(0) : null,
                gradient: SweepGradient(
                  colors: [
                    _C.blueMid.withOpacity(_logoGlow.value * 0.6),
                    _C.pink.withOpacity(_logoGlow.value * 0.4),
                    _C.chrome.withOpacity(_logoGlow.value * 0.5),
                    _C.gold.withOpacity(_logoGlow.value * 0.3),
                    _C.mint.withOpacity(_logoGlow.value * 0.4),
                    _C.blueMid.withOpacity(_logoGlow.value * 0.6),
                  ],
                ),
              ),
            ),
          ),
          // Ring dalam
          Container(
            width: 100, height: 100,
            decoration: BoxDecoration(
              shape: _is3DNeoMode ? BoxShape.rectangle : BoxShape.circle,
              borderRadius: _is3DNeoMode ? BorderRadius.circular(0) : null,
              border: Border.all(
                color: _C.chrome.withOpacity(_logoGlow.value * 0.5),
                width: 1.5,
              ),
            ),
          ),
          // ═══ LOGO UTAMA — FIXED ✅ ═══
          Hero(
            tag: 'logo',
            child: Container(
              width: 84, height: 84,
              // ✅ padding PINDAH KE CONTAINER
              padding: const EdgeInsets.all(2.5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(_is3DNeoMode ? 0 : 24),
                gradient: _C.auroraGrad,
                // ❌ padding DIHAPUS dari BoxDecoration
                boxShadow: _is3DNeoMode
                    ? [
                        BoxShadow(color: _C.blueMid.withOpacity(0.5), offset: const Offset(5, 5), blurRadius: 0),
                        BoxShadow(color: Colors.black.withOpacity(0.3), offset: const Offset(8, 8), blurRadius: 0),
                      ]
                    : [
                        BoxShadow(
                          color: _C.blueMid.withOpacity(_logoGlow.value * 0.6),
                          blurRadius: 30,
                          spreadRadius: 3,
                        ),
                        BoxShadow(
                          color: _C.pink.withOpacity(_logoGlow.value * 0.3),
                          blurRadius: 40,
                        ),
                      ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(_is3DNeoMode ? 0 : 22),
                child: Container(
                  color: _C.card,
                  child: Image.asset(
                    'assets/images/logo.png',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.water_rounded,
                      color: _C.chrome,
                      size: 36,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeading() {
    return Column(children: [
      ShaderMask(
        shaderCallback: (b) => _C.auroraGrad.createShader(b),
        child: Text(
          'Selamat Datang',
          style: TextStyle(
            fontSize: 30,
            fontFamily: "Aktura",
            fontWeight: FontWeight.w900,
            color: Colors.white,
            letterSpacing: -0.5,
            shadows: _is3DNeoMode
                ? const [
                    Shadow(color: Color(0xFF46516A), offset: Offset(2, 2)),
                    Shadow(color: Color(0xFF30394A), offset: Offset(3, 3)),
                  ]
                : [
                    const Shadow(color: Color(0xFF8B5CF6), blurRadius: 20),
                  ],
          ),
        ),
      ),
      const SizedBox(height: 6),
      Text(
        'Masuk untuk melanjutkan',
        style: TextStyle(
          color: _C.textSub,
          fontSize: 14,
          fontFamily: 'Aktura',
          fontWeight: FontWeight.w600,
        ),
      ),
    ]);
  }

  // ═══════════════════════════════════════════════════════════════
  // FORM
  // ═══════════════════════════════════════════════════════════════
  Widget _buildForm() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      decoration: BoxDecoration(
        gradient: _C.surfaceGrad,
        borderRadius: BorderRadius.circular(_is3DNeoMode ? 0 : 26),
        border: Border.all(
          color: _is3DNeoMode ? _C.pink : _C.borderLit.withOpacity(0.6),
          width: _is3DNeoMode ? 2 : 1.5,
        ),
        boxShadow: _is3DNeoMode
            ? [
                BoxShadow(color: _C.pink.withOpacity(0.6), offset: const Offset(8, 8), blurRadius: 0),
                BoxShadow(color: _C.blueMid.withOpacity(0.3), offset: const Offset(12, 12), blurRadius: 0),
              ]
            : [
                BoxShadow(color: _C.blueMid.withOpacity(0.35), blurRadius: 30, offset: const Offset(0, 10)),
                BoxShadow(color: _C.pink.withOpacity(0.15), blurRadius: 40, spreadRadius: -4),
              ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(_is3DNeoMode ? 0 : 26),
        child: Stack(
          children: [
            Positioned(
              top: 0, left: 0, right: 0,
              child: Container(
                height: 3,
                decoration: const BoxDecoration(gradient: _C.auroraGrad),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 24, 22, 22),
              child: Form(
                key: _formKey,
                child: Column(children: [
                  Row(children: [
                    Container(
                      width: 4,
                      height: 20,
                      decoration: BoxDecoration(
                        gradient: _C.auroraGrad,
                        borderRadius: BorderRadius.circular(_is3DNeoMode ? 0 : 2),
                        boxShadow: [
                          BoxShadow(color: _C.blueMid.withOpacity(0.5), blurRadius: 10),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      'Kredensial Akun',
                      style: TextStyle(
                        color: _C.text,
                        fontSize: 14,
                        fontFamily: "Aktura",
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ]),
                  const SizedBox(height: 20),
                  _LoginField(
                    controller: userCtrl,
                    label: 'Username',
                    icon: Icons.person_outline_rounded,
                    is3DNeo: _is3DNeoMode,
                    validator: (v) => (v == null || v.isEmpty) ? 'Username tidak boleh kosong' : null,
                  ),
                  const SizedBox(height: 14),
                  _LoginField(
                    controller: passCtrl,
                    label: 'Password',
                    icon: Icons.lock_outline_rounded,
                    obscure: _obscurePass,
                    is3DNeo: _is3DNeoMode,
                    onToggleObscure: () => setState(() => _obscurePass = !_obscurePass),
                    validator: (v) => (v == null || v.isEmpty) ? 'Password tidak boleh kosong' : null,
                  ),
                  const SizedBox(height: 24),
                  _LoginButton(
                    isLoading: _isLoading,
                    pulseAnim: _btnPulse,
                    shineAnim: _shineCtrl,
                    is3DNeo: _is3DNeoMode,
                    onTap: _login,
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(
          'Belum punya akses ',
          style: TextStyle(
            color: _C.textSub,
            fontSize: 13,
            fontFamily: 'Aktura',
            fontWeight: FontWeight.w600,
          ),
        ),
        GestureDetector(
          onTap: () => launchUrl(Uri.parse('https://t.me/vinzzsukakmu'), mode: LaunchMode.externalApplication),
          child: ShaderMask(
            shaderCallback: (b) => _C.auroraGrad.createShader(b),
            child: const Text(
              'Beli Sekarang',
              style: TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                fontFamily: 'Aktura',
                letterSpacing: 0.3,
              ),
            ),
          ),
        ),
      ]),
      const SizedBox(height: 20),
      RichText(
        text: const TextSpan(
          style: TextStyle(color: _C.textDim, fontSize: 11),
          children: [
            TextSpan(text: '© ', style: TextStyle(fontFamily: 'ready')),
            TextSpan(text: '2026 ', style: TextStyle(fontFamily: 'Ready')),
            TextSpan(text: 'Mortix', style: TextStyle(fontFamily: 'Qaxer')),
          ],
        ),
      ),
    ]);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  LOGIN FIELD
// ═══════════════════════════════════════════════════════════════════════════
class _LoginField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final bool obscure;
  final bool is3DNeo;
  final VoidCallback? onToggleObscure;
  final String? Function(String?)? validator;

  const _LoginField({
    required this.controller,
    required this.label,
    required this.icon,
    this.obscure = false,
    this.is3DNeo = false,
    this.onToggleObscure,
    this.validator,
  });

  @override
  State<_LoginField> createState() => _LoginFieldState();
}

class _LoginFieldState extends State<_LoginField>
    with SingleTickerProviderStateMixin {
  bool _focused = false;
  final _focus = FocusNode();
  late AnimationController _glowCtrl;

  @override
  void initState() {
    super.initState();
    _focus.addListener(() {
      setState(() => _focused = _focus.hasFocus);
      if (_focus.hasFocus) {
        _glowCtrl.repeat(reverse: true);
      } else {
        _glowCtrl.stop();
        _glowCtrl.value = 0;
      }
    });
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
  }

  @override
  void dispose() {
    _focus.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _glowCtrl,
      builder: (_, __) {
        final glowValue = _focused ? 0.4 + _glowCtrl.value * 0.3 : 0.0;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 14),
            border: Border.all(
              color: _focused ? _C.chrome : _C.borderLit.withOpacity(0.5),
              width: _focused ? 2 : 1.2,
            ),
            boxShadow: _focused
                ? [
                    if (widget.is3DNeo) ...[
                      BoxShadow(color: _C.blueMid.withOpacity(0.5), offset: const Offset(4, 4), blurRadius: 0),
                    ] else ...[
                      BoxShadow(
                        color: _C.chrome.withOpacity(glowValue),
                        blurRadius: 20,
                        spreadRadius: 1,
                      ),
                      BoxShadow(
                        color: _C.blueMid.withOpacity(glowValue * 0.6),
                        blurRadius: 30,
                      ),
                    ],
                  ]
                : [],
          ),
          child: TextFormField(
            controller: widget.controller,
            focusNode: _focus,
            obscureText: widget.obscure,
            validator: widget.validator,
            style: const TextStyle(
              color: _C.text,
              fontSize: 14,
              fontWeight: FontWeight.w600,
              fontFamily: 'Aktura',
            ),
            cursorColor: _C.chrome,
            decoration: InputDecoration(
              labelText: widget.label,
              labelStyle: const TextStyle(
                color: _C.textSub,
                fontSize: 13,
                fontFamily: 'Aktura',
                fontWeight: FontWeight.w600,
              ),
              floatingLabelStyle: TextStyle(
                color: _focused ? _C.chrome : _C.blueMid,
                fontSize: 11,
                fontFamily: 'Aktura',
                fontWeight: FontWeight.w700,
              ),
              prefixIcon: Icon(
                widget.icon,
                color: _focused ? _C.chrome : _C.textSub,
                size: 18,
              ),
              suffixIcon: widget.onToggleObscure != null
                  ? IconButton(
                      icon: Icon(
                        widget.obscure
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: _focused ? _C.chrome : _C.textSub,
                        size: 18,
                      ),
                      onPressed: widget.onToggleObscure,
                    )
                  : null,
              errorStyle: const TextStyle(
                color: _C.pink,
                fontSize: 11,
                fontFamily: 'Aktura',
                fontWeight: FontWeight.w600,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  LOGIN BUTTON
// ═══════════════════════════════════════════════════════════════════════════
class _LoginButton extends StatefulWidget {
  final bool isLoading;
  final Animation<double> pulseAnim;
  final AnimationController shineAnim;
  final bool is3DNeo;
  final VoidCallback onTap;

  const _LoginButton({
    required this.isLoading,
    required this.pulseAnim,
    required this.shineAnim,
    required this.is3DNeo,
    required this.onTap,
  });

  @override
  State<_LoginButton> createState() => _LoginButtonState();
}

class _LoginButtonState extends State<_LoginButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedBuilder(
        animation: Listenable.merge([widget.pulseAnim, widget.shineAnim]),
        builder: (_, __) => Transform.scale(
          scale: widget.isLoading || _down ? 1.0 : widget.pulseAnim.value,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            height: 56,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: _C.auroraGrad,
              borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 16),
              border: widget.is3DNeo
                  ? Border.all(color: _C.pink, width: 2)
                  : null,
              boxShadow: _down || widget.isLoading
                  ? []
                  : widget.is3DNeo
                      ? [
                          BoxShadow(color: _C.blueMid.withOpacity(0.6), offset: const Offset(6, 6), blurRadius: 0),
                          BoxShadow(color: _C.pink.withOpacity(0.4), offset: const Offset(9, 9), blurRadius: 0),
                        ]
                      : [
                          BoxShadow(
                            color: _C.blueMid.withOpacity(widget.pulseAnim.value * 0.6),
                            blurRadius: 24,
                            offset: const Offset(0, 8),
                          ),
                          BoxShadow(
                            color: _C.pink.withOpacity(widget.pulseAnim.value * 0.3),
                            blurRadius: 32,
                            spreadRadius: -4,
                          ),
                        ],
            ),
            child: Stack(
              children: [
                if (!widget.isLoading)
                  Positioned.fill(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 16),
                      child: AnimatedBuilder(
                        animation: widget.shineAnim,
                        builder: (_, __) => Transform.translate(
                          offset: Offset(
                            -200 + (widget.shineAnim.value * 600),
                            0,
                          ),
                          child: Container(
                            width: 80,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  Colors.white.withOpacity(0.35),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                Center(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 220),
                    child: widget.isLoading
                        ? const SizedBox(
                            key: ValueKey('loading'),
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: Colors.white,
                            ),
                          )
                        : const Row(
                            key: ValueKey('idle'),
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.login_rounded, color: Colors.white, size: 20),
                              SizedBox(width: 10),
                              Text(
                                'Masuk',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 0.8,
                                  fontFamily: 'Aktura',
                                  shadows: [
                                    Shadow(color: Colors.black38, offset: Offset(1, 1), blurRadius: 2),
                                  ],
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  GRADIENT BUTTON
// ═══════════════════════════════════════════════════════════════════════════
class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;
  final bool is3DNeo;
  const _GradBtn({
    required this.label,
    required this.onTap,
    this.fullWidth = false,
    this.is3DNeo = false,
  });

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 48,
          width: widget.fullWidth ? double.infinity : null,
          decoration: BoxDecoration(
            gradient: _C.auroraGrad,
            borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 14),
            border: widget.is3DNeo ? Border.all(color: _C.pink, width: 2) : null,
            boxShadow: _down
                ? []
                : widget.is3DNeo
                    ? [
                        BoxShadow(color: _C.blueMid.withOpacity(0.5), offset: const Offset(4, 4), blurRadius: 0),
                      ]
                    : [
                        BoxShadow(
                          color: _C.blueMid.withOpacity(0.4),
                          blurRadius: 16,
                          offset: const Offset(0, 6),
                        ),
                        BoxShadow(
                          color: _C.pink.withOpacity(0.2),
                          blurRadius: 20,
                          spreadRadius: -4,
                        ),
                      ],
          ),
          child: Center(
            child: Text(
              widget.label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: 14,
                fontFamily: 'Aktura',
                letterSpacing: 0.3,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  OUTLINE BUTTON
// ═══════════════════════════════════════════════════════════════════════════
class _OutlineBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;
  final bool is3DNeo;
  const _OutlineBtn({
    required this.label,
    required this.onTap,
    this.fullWidth = false,
    this.is3DNeo = false,
  });

  @override
  State<_OutlineBtn> createState() => _OutlineBtnState();
}

class _OutlineBtnState extends State<_OutlineBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        height: 48,
        width: widget.fullWidth ? double.infinity : null,
        decoration: BoxDecoration(
          color: _down ? _C.border.withOpacity(0.4) : Colors.transparent,
          borderRadius: BorderRadius.circular(widget.is3DNeo ? 0 : 14),
          border: Border.all(
            color: _C.borderLit,
            width: widget.is3DNeo ? 2 : 1.5,
          ),
          boxShadow: widget.is3DNeo && !_down
              ? [
                  BoxShadow(color: _C.border.withOpacity(0.5), offset: const Offset(4, 4), blurRadius: 0),
                ]
              : null,
        ),
        child: Center(
          child: Text(
            widget.label,
            style: const TextStyle(
              color: _C.textSub,
              fontWeight: FontWeight.w700,
              fontSize: 14,
              fontFamily: 'Aktura',
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  ANIMATED BACKGROUND — AURORA MESH
// ═══════════════════════════════════════════════════════════════════════════
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  final bool is3DNeo;
  const _AnimatedBg({required this.controller, this.is3DNeo = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(
        painter: _BgPainter(controller.value, is3DNeo: is3DNeo),
      ),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  final bool is3DNeo;

  _BgPainter(this.t, {this.is3DNeo = false});

  @override
  void paint(Canvas canvas, Size size) {
    // Background gradient
    final bgPaint = Paint()
      ..shader = _C.creamGrad.createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    // Aurora orbs
    final orb1X = size.width * 0.15 + math.cos(t * 2 * math.pi) * 50;
    final orb1Y = size.height * 0.15 + math.sin(t * 2 * math.pi) * 40;
    final orb1 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.blueMid.withOpacity(0.35 + math.sin(t * 2 * math.pi) * 0.1),
          _C.pink.withOpacity(0.15),
          Colors.transparent,
        ],
        stops: const [0.0, 0.4, 0.8],
      ).createShader(Rect.fromCircle(center: Offset(orb1X, orb1Y), radius: 280));
    canvas.drawCircle(Offset(orb1X, orb1Y), 280, orb1);

    final orb2X = size.width * 0.85 + math.cos(t * 2 * math.pi + 1.5) * 50;
    final orb2Y = size.height * 0.4 + math.sin(t * 2 * math.pi + 1.5) * 60;
    final orb2 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.chrome.withOpacity(0.3 + math.sin(t * 2 * math.pi + 1) * 0.1),
          _C.blueMid.withOpacity(0.1),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: Offset(orb2X, orb2Y), radius: 240));
    canvas.drawCircle(Offset(orb2X, orb2Y), 240, orb2);

    final orb3X = size.width * 0.5 + math.cos(t * 2 * math.pi + 3) * 70;
    final orb3Y = size.height * 0.8 + math.sin(t * 2 * math.pi + 3) * 50;
    final orb3 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.gold.withOpacity(0.2 + math.sin(t * 2 * math.pi + 2) * 0.08),
          _C.mint.withOpacity(0.1),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: Offset(orb3X, orb3Y), radius: 220));
    canvas.drawCircle(Offset(orb3X, orb3Y), 220, orb3);

    // Grid subtle
    final grid = Paint()
      ..color = _C.borderLit.withOpacity(is3DNeo ? 0.2 : 0.1)
      ..strokeWidth = is3DNeo ? 0.8 : 0.5;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // 3D Neo floating boxes
    if (is3DNeo) {
      final boxFace = Paint()
        ..color = _C.card.withOpacity(0.6)
        ..style = PaintingStyle.fill;
      final boxShadow = Paint()
        ..color = _C.blueMid.withOpacity(0.35)
        ..style = PaintingStyle.fill;
      final boxBorder = Paint()
        ..color = _C.pink.withOpacity(0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5;

      const boxSize = 80.0;
      for (double x = 0; x < size.width; x += boxSize) {
        for (double y = 0; y < size.height; y += boxSize) {
          final rect = Rect.fromLTWH(x + 4, y + 4, boxSize - 8, boxSize - 8);
          canvas.drawRect(rect.translate(6, 6), boxShadow);
          canvas.drawRect(rect, boxFace);
          canvas.drawRect(rect, boxBorder);
        }
      }
    }

    // Vignette bottom
    final vignette = Paint()
      ..shader = LinearGradient(
        colors: [Colors.transparent, _C.bg.withOpacity(0.7)],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, size.height * 0.7, size.width, size.height * 0.3));
    canvas.drawRect(
      Rect.fromLTWH(0, size.height * 0.7, size.width, size.height * 0.3),
      vignette,
    );
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t || old.is3DNeo != is3DNeo;
}

enum _AlertType { error, warning, success }
