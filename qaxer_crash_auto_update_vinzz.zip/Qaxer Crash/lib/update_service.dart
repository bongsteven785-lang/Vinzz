import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

/// Checks the latest public GitHub Release and notifies the user when a newer
/// version is available. Android still asks the user to confirm APK install.
class AppUpdateService {
  // TODO: Replace these two values with your real public GitHub repository.
  static const String githubOwner = 'bongsteven785-lang';
  static const String githubRepo = 'Vinzz';

  static Future<void> check(BuildContext context) async {
    try {
      final response = await http.get(
        Uri.https('api.github.com', '/repos/$githubOwner/$githubRepo/releases/latest'),
        headers: const {
          'Accept': 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28',
        },
      ).timeout(const Duration(seconds: 12));

      if (response.statusCode != 200) {
        debugPrint('Auto update: GitHub returned ${response.statusCode}.');
        return;
      }

      final decoded = jsonDecode(response.body);
      if (decoded is! Map<String, dynamic>) return;

      final tag = decoded['tag_name'] as String?;
      final releaseUrl = decoded['html_url'] as String?;
      if (tag == null || releaseUrl == null) return;

      final latestVersion = tag.replaceFirst(RegExp(r'^[vV]'), '').trim();
      final packageInfo = await PackageInfo.fromPlatform();
      final currentVersion = packageInfo.version;

      if (!_isNewer(latestVersion, currentVersion) || !context.mounted) return;

      await showDialog<void>(
        context: context,
        barrierDismissible: true,
        builder: (dialogContext) => AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.system_update_alt_rounded),
              SizedBox(width: 10),
              Expanded(child: Text('Update tersedia')),
            ],
          ),
          content: Text(
            'Versi terbaru: $latestVersion\n'
            'Versi terpasang: $currentVersion\n\n'
            'Buka GitHub untuk mengunduh APK terbaru. Pemasangan tetap perlu '
            'disetujui melalui Android.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Nanti'),
            ),
            FilledButton.icon(
              icon: const Icon(Icons.download_rounded),
              label: const Text('Update'),
              onPressed: () async {
                Navigator.of(dialogContext).pop();
                final uri = Uri.tryParse(releaseUrl);
                if (uri == null ||
                    (uri.scheme != 'https' || uri.host != 'github.com')) {
                  debugPrint('Auto update: invalid GitHub release URL.');
                  return;
                }
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              },
            ),
          ],
        ),
      );
    } catch (error) {
      // Update checking must never prevent the dashboard from opening.
      debugPrint('Auto update check failed: $error');
    }
  }

  static bool _isNewer(String latest, String current) {
    final latestParts = _versionParts(latest);
    final currentParts = _versionParts(current);
    if (latestParts.isEmpty || currentParts.isEmpty) return false;

    final length = latestParts.length > currentParts.length
        ? latestParts.length
        : currentParts.length;
    for (var i = 0; i < length; i++) {
      final a = i < latestParts.length ? latestParts[i] : 0;
      final b = i < currentParts.length ? currentParts[i] : 0;
      if (a > b) return true;
      if (a < b) return false;
    }
    return false;
  }

  static List<int> _versionParts(String version) {
    final clean = version.split('+').first.trim();
    final parts = clean.split('.');
    if (parts.isEmpty || parts.any((part) => int.tryParse(part) == null)) {
      return const [];
    }
    return parts.map(int.parse).toList();
  }
}
