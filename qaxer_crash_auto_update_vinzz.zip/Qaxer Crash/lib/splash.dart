import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

// ═══════════════════════════════════════════════════════════════════
//  PALETTE — MODERN NEO-BLUE
// ═══════════════════════════════════════════════════════════════════
class _C {
  static const bg        = Color(0xFF050810);
  static const surface   = Color(0xFF0A1220);
  static const card      = Color(0xFF0E1A2E);
  static const steel     = Color(0xFF1A4F8A);
  static const blueMid   = Color(0xFF2370BE);
  static const blueLight = Color(0xFF4A94E8);
  static const chrome    = Color(0xFF7AB4E8);
  static const frost     = Color(0xFFADD4F5);
  static const text      = Color(0xFFE8F2FC);
  static const textSub   = Color(0xFF6A92B8);
  static const textDim   = Color(0xFF3A5878);
  static const border    = Color(0xFF1A2D4A);
  static const accent    = Color(0xFF5BA0F0);
  static const glow      = Color(0xFF3A7BD5);
  static const cyan      = Color(0xFF9B6DFF);

  static const LinearGradient titleGrad = LinearGradient(
    colors: [frost, chrome, blueLight, frost],
    stops: [0.0, 0.3, 0.7, 1.0],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient progressGrad = LinearGradient(
    colors: [steel, blueMid, blueLight, chrome],
    stops: [0.0, 0.35, 0.7, 1.0],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );

  static const SweepGradient ringGrad = SweepGradient(
    colors: [
      Color(0x007AB4E8),
      Color(0xFFFF7AB4E8),
      Color(0xFFFF4A94E8),
      Color(0xFFFF22D3EE),
      Color(0xFFFF2370BE),
      Color(0x007AB4E8),
    ],
    stops: [0.0, 0.25, 0.5, 0.65, 0.85, 1.0],
  );
}

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listBugGroup;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final List<dynamic> jjVideos;
  final List<dynamic> thanksTo;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listBugGroup,
    required this.listDoos,
    required this.news,
    required this.jjVideos,
    required this.thanksTo,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoCtrl;
  bool _videoReady = false;
  bool _fadeOutStarted = false;
  bool _isSkipped = false;

  // ─── Animations
  late AnimationController _fadeOutCtrl;
  late AnimationController _uiCtrl;
  late AnimationController _ringCtrl;
  late AnimationController _progressCtrl;
  late AnimationController _particleCtrl;
  late AnimationController _skipBtnCtrl;

  late Animation<double> _uiFade;
  late Animation<Offset>  _uiSlide;
  late Animation<double>  _fadeOut;
  late Animation<double>  _skipBtnOpacity;
  late Animation<Offset>  _skipBtnSlide;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _initVideo();
  }

  void _initAnimations() {
    _fadeOutCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1000));
    _fadeOut = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _fadeOutCtrl, curve: Curves.easeInCubic));

    _uiCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1200));
    _uiFade = CurvedAnimation(
      parent: _uiCtrl, curve: const Interval(0.15, 1.0, curve: Curves.easeOut));
    _uiSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _uiCtrl, curve: Curves.easeOutCubic));

    _ringCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 8))..repeat();

    _progressCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 5));

    _particleCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 10))..repeat();

    _skipBtnCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 700));
    _skipBtnOpacity = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _skipBtnCtrl, curve: Curves.easeOut));
    _skipBtnSlide = Tween<Offset>(begin: const Offset(0, -0.6), end: Offset.zero)
        .animate(CurvedAnimation(parent: _skipBtnCtrl, curve: Curves.easeOutBack));

    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _skipBtnCtrl.forward();
    });
  }

  void _initVideo() {
    _videoCtrl = VideoPlayerController.asset('assets/videos/splash.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _videoReady = true);
        _videoCtrl.setLooping(false);
        _videoCtrl.setVolume(1.0);
        _videoCtrl.play();

        Future.delayed(const Duration(milliseconds: 400), () {
          if (mounted) {
            _uiCtrl.forward();
            _progressCtrl.forward();
          }
        });

        _videoCtrl.addListener(_onVideoProgress);
      }).catchError((_) {
        if (mounted) {
          setState(() => _videoReady = false);
          _uiCtrl.forward();
          _progressCtrl.forward();
          Future.delayed(const Duration(seconds: 4), _navigate);
        }
      });
  }

  void _onVideoProgress() {
    if (!mounted || _isSkipped) return;
    final pos = _videoCtrl.value.position;
    final dur = _videoCtrl.value.duration;
    if (dur == Duration.zero) return;

    if (pos >= dur - const Duration(seconds: 1) && !_fadeOutStarted) {
      _fadeOutStarted = true;
      _fadeOutCtrl.forward();
    }
    if (pos >= dur) _navigate();
  }

  void _skip() {
    if (_isSkipped) return;
    _isSkipped = true;
    _videoCtrl.pause();
    _videoCtrl.removeListener(_onVideoProgress);
    _fadeOutStarted = true;
    _fadeOutCtrl.forward().then((_) {
      if (mounted) _navigate();
    });
  }

  void _navigate() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listBugGroup: widget.listBugGroup,
          listDoos: widget.listDoos,
          news: widget.news,
          jjVideos: widget.jjVideos,
          thanksTo: widget.thanksTo,
        ),
        transitionDuration: const Duration(milliseconds: 700),
        transitionsBuilder: (_, anim, __, child) => FadeTransition(
          opacity: CurvedAnimation(parent: anim, curve: Curves.easeOutCubic),
          child: child,
        ),
      ),
    );
  }

  @override
  void dispose() {
    try {
      _videoCtrl.removeListener(_onVideoProgress);
      _videoCtrl.dispose();
    } catch (_) {}
    _fadeOutCtrl.dispose();
    _uiCtrl.dispose();
    _ringCtrl.dispose();
    _progressCtrl.dispose();
    _particleCtrl.dispose();
    _skipBtnCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ── Base gradient
          Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                colors: [Color(0xFF0A1220), Color(0xFF050810)],
                radius: 1.2,
              ),
            ),
          ),

          // ── Particle background
          AnimatedBuilder(
            animation: _particleCtrl,
            builder: (_, __) => CustomPaint(
              painter: _ParticlePainter(_particleCtrl.value),
              size: size,
            ),
          ),

          // ── Video
          if (_videoReady && !_isSkipped)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoCtrl.value.size.width,
                  height: _videoCtrl.value.size.height,
                  child: VideoPlayer(_videoCtrl),
                ),
              ),
            ),

          // ── Glass overlay
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: _videoReady && !_isSkipped
                      ? [
                          Colors.black.withOpacity(0.2),
                          Colors.black.withOpacity(0.6),
                          _C.bg.withOpacity(0.9),
                        ]
                      : [
                          Colors.transparent,
                          Colors.transparent,
                          _C.bg.withOpacity(0.6),
                        ],
                  stops: const [0.0, 0.65, 1.0],
                ),
              ),
            ),
          ),

          // ── Skip button
          Positioned(
            top: 44, right: 20,
            child: FadeTransition(
              opacity: _skipBtnOpacity,
              child: SlideTransition(
                position: _skipBtnSlide,
                child: _buildSkipButton(),
              ),
            ),
          ),

          // ── Center content
          Positioned.fill(
            child: FadeTransition(
              opacity: _uiFade,
              child: SlideTransition(
                position: _uiSlide,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildLogoRing(),
                    const SizedBox(height: 44),
                    _buildTitle(),
                    const SizedBox(height: 14),
                    _buildSubtitle(),
                  ],
                ),
              ),
            ),
          ),

          // ── Bottom progress
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: FadeTransition(
              opacity: _uiFade,
              child: _buildBottomBar(),
            ),
          ),

          // ── Fade out overlay
          if (_fadeOutStarted)
            FadeTransition(
              opacity: _fadeOut,
              child: Container(color: _C.bg),
            ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  SKIP BUTTON
  // ═══════════════════════════════════════════════════════════════
  Widget _buildSkipButton() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: _skip,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color: _C.surface.withOpacity(0.7),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: _C.blueMid.withOpacity(0.35), width: 1),
            boxShadow: [
              BoxShadow(
                color: _C.blueMid.withOpacity(0.2),
                blurRadius: 16, spreadRadius: 1, offset: const Offset(0, 4)),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Skip',
                style: TextStyle(
                  color: _C.text.withOpacity(0.9),
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.6,
                ),
              ),
              const SizedBox(width: 6),
              Icon(Icons.skip_next_rounded,
                size: 18, color: _C.blueLight),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  LOGO RING
  // ═══════════════════════════════════════════════════════════════
  Widget _buildLogoRing() {
    return AnimatedBuilder(
      animation: _ringCtrl,
      builder: (_, __) {
        return SizedBox(
          width: 180, height: 180,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Outer glow
              Container(
                width: 180, height: 180,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      _C.blueMid.withOpacity(0.18),
                      _C.blueMid.withOpacity(0.05),
                      Colors.transparent,
                    ],
                    stops: const [0.3, 0.6, 1.0],
                  ),
                ),
              ),

              // Rotating gradient ring
              Transform.rotate(
                angle: _ringCtrl.value * math.pi * 2,
                child: Container(
                  width: 158, height: 158,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: _C.ringGrad,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(3),
                    child: Container(
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: _C.bg,
                      ),
                    ),
                  ),
                ),
              ),

              // Inner border ring
              Container(
                width: 142, height: 142,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: _C.steel.withOpacity(0.35), width: 1),
                ),
              ),

              // Core with logo
              Container(
                width: 118, height: 118,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.bg,
                  border: Border.all(
                    color: _C.blueLight.withOpacity(0.4), width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: _C.blueMid.withOpacity(0.5),
                      blurRadius: 40, spreadRadius: 8),
                    BoxShadow(
                      color: _C.cyan.withOpacity(0.15),
                      blurRadius: 80, spreadRadius: 12),
                  ],
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/logo.png',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Center(
                      child: Icon(Icons.water_rounded,
                        color: _C.blueLight, size: 52),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  TITLE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildTitle() {
    return ShaderMask(
      shaderCallback: (b) => _C.titleGrad.createShader(b),
      child: const Text(
        'Mortix',
        style: TextStyle(
          fontSize: 36,
          fontFamily: 'Qaxer',
          color: Colors.white,
          letterSpacing: 2.4,
          fontWeight: FontWeight.w900,
          shadows: [
            Shadow(color: Color(0xFF3A7BD5), blurRadius: 30),
            Shadow(color: Color(0xFF7AB4E8), blurRadius: 60),
          ],
        ),
      ),
    );
  }

  Widget _buildSubtitle() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
      decoration: BoxDecoration(
        color: _C.surface.withOpacity(0.4),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: _C.blueMid.withOpacity(0.2), width: 1),
      ),
      child: Text(
        '✦  Powered By @vinzzsukakmu  ✦',
        style: TextStyle(
          color: _C.textSub.withOpacity(0.9),
          fontSize: 12,
          letterSpacing: 0.8,
          fontWeight: FontWeight.w400,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  BOTTOM BAR
  // ═══════════════════════════════════════════════════════════════
  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(32, 0, 32, 56),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _LoadingDots(),
          const SizedBox(height: 22),
          AnimatedBuilder(
            animation: _progressCtrl,
            builder: (_, __) {
              final pct = (_progressCtrl.value * 100).toInt();
              final phase = _progressCtrl.value < 0.33
                  ? 'Initializing...'
                  : _progressCtrl.value < 0.66
                      ? 'Loading assets...'
                      : 'Ready...';

              return Column(
                children: [
                  // Progress bar
                  Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: Container(
                          height: 4,
                          width: double.infinity,
                          color: _C.border.withOpacity(0.5),
                        ),
                      ),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: Container(
                          height: 4,
                          width: (MediaQuery.of(context).size.width - 64) *
                              _progressCtrl.value,
                          decoration: const BoxDecoration(
                            gradient: _C.progressGrad,
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x802370BE),
                                blurRadius: 10, spreadRadius: 1),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '$pct%',
                        style: const TextStyle(
                          color: _C.textSub,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        width: 3, height: 3,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _C.textDim,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        phase,
                        style: const TextStyle(
                          color: _C.textSub,
                          fontSize: 11,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  LOADING DOTS
// ═══════════════════════════════════════════════════════════════════
class _LoadingDots extends StatefulWidget {
  const _LoadingDots();

  @override
  State<_LoadingDots> createState() => _LoadingDotsState();
}

class _LoadingDotsState extends State<_LoadingDots>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1200))..repeat();
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(3, (i) {
          final t = ((_c.value - i / 3) % 1.0).clamp(0.0, 1.0);
          final s = math.sin(t * math.pi);
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: Transform.scale(
              scale: 0.4 + s * 0.6,
              child: Container(
                width: 8, height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _C.blueLight.withOpacity(0.3 + s * 0.7),
                  boxShadow: [
                    BoxShadow(
                      color: _C.blueMid.withOpacity(s * 0.6),
                      blurRadius: 10, spreadRadius: 2),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
//  PARTICLE PAINTER
// ═══════════════════════════════════════════════════════════════════
class _ParticlePainter extends CustomPainter {
  final double t;
  _ParticlePainter(this.t);

  static final _rand = math.Random(42);
  static final _particles = List.generate(35, (i) => _Particle(
    x: _rand.nextDouble(),
    y: _rand.nextDouble(),
    size: 0.8 + _rand.nextDouble() * 2.5,
    speed: 0.03 + _rand.nextDouble() * 0.12,
    phase: _rand.nextDouble(),
    opacity: 0.1 + _rand.nextDouble() * 0.4,
    driftAmount: 0.5 + _rand.nextDouble() * 2.0,
  ));

  @override
  void paint(Canvas canvas, Size size) {
    // Grid subtle
    final grid = Paint()
      ..color = _C.border.withOpacity(0.15)
      ..strokeWidth = 0.3;
    const step = 50.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // Central glow
    final center = Offset(size.width / 2, size.height * 0.35);
    final glow = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.blueMid.withOpacity(0.12 + math.sin(t * math.pi * 2) * 0.05),
          _C.steel.withOpacity(0.05),
          Colors.transparent,
        ],
        radius: 0.7,
        stops: const [0.0, 0.4, 1.0],
      ).createShader(
        Rect.fromCircle(center: center, radius: size.width * 0.8));
    canvas.drawCircle(center, size.width * 0.8, glow);

    // Floating particles
    for (final p in _particles) {
      final px = p.x * size.width;
      final rawY = p.y + (t * p.speed) % 1.0;
      final py = (rawY % 1.0) * size.height;
      final driftX = math.sin((t + p.phase) * math.pi * 2) * p.driftAmount;
      final driftY = math.cos((t * 0.7 + p.phase) * math.pi * 2) * p.driftAmount * 0.6;
      final osc = math.sin((t * 2 + p.phase) * math.pi);
      final opacity = p.opacity * (0.4 + osc * 0.6);

      // Glow
      canvas.drawCircle(
        Offset(px + driftX, py + driftY),
        p.size * 3,
        Paint()..color = _C.blueMid.withOpacity(opacity * 0.15),
      );

      // Core
      canvas.drawCircle(
        Offset(px + driftX, py + driftY),
        p.size,
        Paint()..color = _C.blueLight.withOpacity(opacity),
      );
    }
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => old.t != t;
}

class _Particle {
  final double x, y, size, speed, phase, opacity, driftAmount;
  const _Particle({
    required this.x, required this.y, required this.size,
    required this.speed, required this.phase, required this.opacity,
    required this.driftAmount,
  });
}
