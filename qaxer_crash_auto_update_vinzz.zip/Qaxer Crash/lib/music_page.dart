import 'dart:math' as math;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'splash.dart';

/// Shared player: music stays alive when the intro page is replaced by Splash/Dashboard.
class NightCoreMusic {
  NightCoreMusic._();
  static final AudioPlayer _player = AudioPlayer();
  static final ValueNotifier<bool> playing = ValueNotifier<bool>(false);
  static final ValueNotifier<int> track = ValueNotifier<int>(0);
  static const List<String> assets = [
    'music/soundrara2.mp3',
    'music/sound_rara_imut.mp3',
  ];
  static const List<String> titles = ['Sound Rara 2', 'Sound Rara Imut'];
  static bool _loaded = false;

  static Future<void> start() async {
    try {
      if (!_loaded) {
        await _player.setReleaseMode(ReleaseMode.loop);
        await _player.setSource(AssetSource(assets[track.value]));
        _loaded = true;
      }
      await _player.resume();
      playing.value = true;
    } catch (_) {
      playing.value = false;
    }
  }

  static Future<void> pause() async {
    try { await _player.pause(); } catch (_) {}
    playing.value = false;
  }

  static Future<void> toggle() async {
    if (playing.value) {
      await pause();
    } else {
      await start();
    }
  }

  static Future<void> nextTrack() async {
    final wasPlaying = playing.value;
    final next = (track.value + 1) % assets.length;
    track.value = next;
    try {
      await _player.stop();
      await _player.setReleaseMode(ReleaseMode.loop);
      await _player.setSource(AssetSource(assets[next]));
      _loaded = true;
      if (wasPlaying) {
        await _player.resume();
        playing.value = true;
      } else {
        playing.value = false;
      }
    } catch (_) {
      playing.value = false;
    }
  }
}

class MusicIntroPage extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listBugGroup, listDoos;
  final List<dynamic> news, jjVideos, thanksTo;

  const MusicIntroPage({super.key, required this.username, required this.password,
    required this.role, required this.expiredDate, required this.sessionKey,
    required this.listBug, required this.listBugGroup, required this.listDoos,
    required this.news, required this.jjVideos, required this.thanksTo});

  @override
  State<MusicIntroPage> createState() => _MusicIntroPageState();
}

class _MusicIntroPageState extends State<MusicIntroPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _spin = AnimationController(
    vsync: this, duration: const Duration(seconds: 7))..repeat();

  @override
  void dispose() { _spin.dispose(); super.dispose(); }

  void _continue() {
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => SplashScreen(
      username: widget.username, password: widget.password, role: widget.role,
      expiredDate: widget.expiredDate, sessionKey: widget.sessionKey,
      listBug: widget.listBug, listBugGroup: widget.listBugGroup,
      listDoos: widget.listDoos, news: widget.news, jjVideos: widget.jjVideos,
      thanksTo: widget.thanksTo,
    )));
  }

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF9B6DFF);
    return Scaffold(
      backgroundColor: const Color(0xFF080511),
      body: Container(
        decoration: const BoxDecoration(gradient: RadialGradient(
          center: Alignment(-0.2, -0.5), radius: 1.3,
          colors: [Color(0xFF28104A), Color(0xFF10091E), Color(0xFF07050D)],
        )),
        child: SafeArea(child: Center(child: SingleChildScrollView(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('NIGHT CORE', style: TextStyle(color: Colors.white,
              fontSize: 29, fontWeight: FontWeight.w900, letterSpacing: 4)),
            const SizedBox(height: 8),
            const Text('MUSIC EXPERIENCE', style: TextStyle(color: purple,
              fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 3)),
            const SizedBox(height: 38),
            AnimatedBuilder(animation: _spin, builder: (_, __) => Transform.rotate(
              angle: _spin.value * 2 * math.pi,
              child: Container(width: 218, height: 218,
                decoration: BoxDecoration(shape: BoxShape.circle,
                  gradient: const SweepGradient(colors: [Color(0xFF2B1745), Color(0xFF9B6DFF), Color(0xFF171022), Color(0xFFFF354D), Color(0xFF2B1745)]),
                  boxShadow: [BoxShadow(color: purple.withOpacity(.35), blurRadius: 32, spreadRadius: 3)],
                  border: Border.all(color: purple.withOpacity(.7), width: 2)),
                child: Center(child: Container(width: 86, height: 86,
                  decoration: const BoxDecoration(shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [Color(0xFF9B6DFF), Color(0xFF2B1745)])),
                  child: const Icon(Icons.graphic_eq_rounded, color: Colors.white, size: 42))),
              ),
            )),
            const SizedBox(height: 30),
            ValueListenableBuilder<int>(valueListenable: NightCoreMusic.track,
              builder: (_, index, __) => Text(NightCoreMusic.titles[index],
                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold))),
            const SizedBox(height: 8),
            const Text('Musik tetap berjalan saat masuk Dashboard', textAlign: TextAlign.center,
              style: TextStyle(color: Color(0xFFB9ADC9), fontSize: 12)),
            const SizedBox(height: 24),
            ValueListenableBuilder<bool>(valueListenable: NightCoreMusic.playing,
              builder: (_, isPlaying, __) => Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Switch.adaptive(value: isPlaying, activeColor: purple,
                  onChanged: (_) => NightCoreMusic.toggle()),
                Text(isPlaying ? 'MUSIC ON' : 'MUSIC OFF', style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
              ])),
            const SizedBox(height: 8),
            OutlinedButton.icon(onPressed: NightCoreMusic.nextTrack,
              icon: const Icon(Icons.skip_next_rounded), label: const Text('GANTI MUSIK'),
              style: OutlinedButton.styleFrom(foregroundColor: purple,
                side: const BorderSide(color: purple), padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 13))),
            const SizedBox(height: 28),
            SizedBox(width: double.infinity, height: 54, child: FilledButton.icon(
              onPressed: _continue, icon: const Icon(Icons.arrow_forward_rounded),
              label: const Text('LANJUT KE SPLASH', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              style: FilledButton.styleFrom(backgroundColor: purple, foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
            )),
          ]),
        ))),
      ),
    );
  }
}

/// Compact dashboard control. Audio is managed by the shared singleton, not this widget.
class DashboardMusicControl extends StatelessWidget {
  const DashboardMusicControl({super.key});
  Widget _circleButton({required Widget icon, required String tooltip,
      required VoidCallback onPressed}) => Material(
    color: const Color(0xFF1B1230).withOpacity(.94),
    shape: const CircleBorder(),
    child: Container(
      decoration: BoxDecoration(shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFF9B6DFF), width: 1.2),
        boxShadow: [BoxShadow(color: const Color(0xFF9B6DFF).withOpacity(.22), blurRadius: 14)]),
      child: IconButton(tooltip: tooltip, onPressed: onPressed, icon: icon),
    ),
  );
  @override
  Widget build(BuildContext context) => Positioned(
    right: 14, bottom: 92,
    child: ValueListenableBuilder<bool>(valueListenable: NightCoreMusic.playing,
      builder: (_, isPlaying, __) => Row(mainAxisSize: MainAxisSize.min, children: [
        _circleButton(tooltip: 'Ganti musik', onPressed: NightCoreMusic.nextTrack,
          icon: const Icon(Icons.skip_next_rounded, color: Color(0xFFB79CFF), size: 23)),
        const SizedBox(width: 8),
        _circleButton(tooltip: isPlaying ? 'Matikan musik' : 'Nyalakan musik',
          onPressed: NightCoreMusic.toggle,
          icon: Icon(isPlaying ? Icons.music_note_rounded : Icons.music_off_rounded,
            color: isPlaying ? const Color(0xFFB79CFF) : Colors.white, size: 23)),
      ]),
    ),
  );
}
