import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'Qaxer/.dart';

class StoryFeed extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;
  const StoryFeed({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  State<StoryFeed> createState() => _StoryFeedState();
}

class _StoryFeedState extends State<StoryFeed> {
  final ImagePicker _picker = ImagePicker();
  final TextEditingController _text = TextEditingController();
  List<Map<String, dynamic>> _stories = [];
  bool _loading = true;
  bool _posting = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await http.get(Uri.parse('${Api.api}/api/stories?username=${Uri.encodeComponent(widget.username)}')).timeout(const Duration(seconds: 10));
      final d = jsonDecode(r.body);
      if (d['success'] == true && mounted) {
        setState(() => _stories = List<Map<String, dynamic>>.from(d['stories'] ?? const []));
      }
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _post({XFile? media, String? mediaType}) async {
    if ((media == null) && _text.text.trim().isEmpty) return;
    setState(() => _posting = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('${Api.api}/api/stories'));
      req.fields.addAll({
        'username': widget.username,
        'sessionKey': widget.sessionKey,
        'text': _text.text.trim(),
      });
      if (media != null) {
        final field = (mediaType == 'video') ? 'video' : 'image';
        req.files.add(await http.MultipartFile.fromPath(field, media.path));
        req.fields['mediaType'] = mediaType ?? 'image';
      }
      final res = await req.send().timeout(const Duration(seconds: 45));
      if (res.statusCode >= 200 && res.statusCode < 300) {
        _text.clear();
        await _load();
      } else {
        _snack('Gagal membuat story.');
      }
    } catch (_) {
      _snack('Tidak dapat terhubung ke server.');
    } finally {
      if (mounted) setState(() => _posting = false);
    }
  }

  Future<void> _pick(bool video) async {
    final file = video
        ? await _picker.pickVideo(source: ImageSource.gallery)
        : await _picker.pickImage(source: ImageSource.gallery, imageQuality: 88);
    if (file != null) await _post(media: file, mediaType: video ? 'video' : 'image');
  }

  Future<void> _like(String id) async {
    try {
      final r = await http.post(
        Uri.parse('${Api.api}/api/stories/$id/like'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'username': widget.username, 'sessionKey': widget.sessionKey}),
      );
      if (r.statusCode == 200) await _load();
    } catch (_) {}
  }

  void _comments(Map<String, dynamic> story) {
    final controller = TextEditingController();
    final comments = List<Map<String, dynamic>>.from(story['comments'] ?? const []);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF0B1220),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setSheet) {
          Future<void> send() async {
            final text = controller.text.trim();
            if (text.isEmpty) return;
            try {
              final r = await http.post(
                Uri.parse('${Api.api}/api/stories/${story['id']}/comments'),
                headers: {'Content-Type': 'application/json'},
                body: jsonEncode({
                  'username': widget.username,
                  'sessionKey': widget.sessionKey,
                  'text': text,
                }),
              );
              if (r.statusCode == 200) {
                final d = jsonDecode(r.body);
                if (d['comment'] != null) {
                  setSheet(() => comments.add(Map<String, dynamic>.from(d['comment'])));
                  controller.clear();
                }
              }
            } catch (_) {}
          }

          return SafeArea(
            child: Padding(
              padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
              child: SizedBox(
                height: MediaQuery.of(ctx).size.height * .72,
                child: Column(
                  children: [
                    const SizedBox(height: 10),
                    Container(width: 42, height: 4, decoration: BoxDecoration(
                      color: Colors.white24, borderRadius: BorderRadius.circular(20))),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 16, 12, 10),
                      child: Row(children: [
                        const Expanded(child: Text('Komentar',
                          style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800))),
                        IconButton(onPressed: () => Navigator.pop(ctx),
                          icon: const Icon(Icons.close, color: Colors.white54)),
                      ]),
                    ),
                    Expanded(
                      child: comments.isEmpty
                          ? const Center(child: Text('Belum ada komentar',
                              style: TextStyle(color: Colors.white38)))
                          : ListView.builder(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              itemCount: comments.length,
                              itemBuilder: (_, i) {
                                final c = comments[i];
                                return ListTile(
                                  leading: CircleAvatar(
                                    backgroundColor: const Color(0xFF7C5CFC),
                                    child: Text((c['username'] ?? '?').toString()[0].toUpperCase(),
                                      style: const TextStyle(color: Colors.white)),
                                  ),
                                  title: Text(c['username'] ?? '',
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                                  subtitle: Text(c['text'] ?? '',
                                    style: const TextStyle(color: Colors.white70)),
                                );
                              },
                            ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
                      child: Row(children: [
                        Expanded(child: TextField(
                          controller: controller,
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: 'Tulis komentar...',
                            hintStyle: const TextStyle(color: Colors.white38),
                            filled: true, fillColor: Colors.white.withOpacity(.06),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(18),
                              borderSide: BorderSide.none),
                          ),
                        )),
                        const SizedBox(width: 8),
                        IconButton(onPressed: send,
                          icon: const Icon(Icons.send_rounded, color: Color(0xFF9B8CFF))),
                      ]),
                    ),
                  ],
                ),
              ),
            ),
          );
        });
      },
    );
  }

  void _snack(String s) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  }

  Widget _avatar(Map<String, dynamic> s, {double size = 46}) {
    final url = s['profileImageUrl']?.toString() ?? '';
    return Container(
      width: size, height: size,
      padding: const EdgeInsets.all(2),
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(colors: [Color(0xFF8B5CF6), Color(0xFF9B6DFF)]),
      ),
      child: ClipOval(
        child: url.isNotEmpty
            ? Image.network(url, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _fallback(size))
            : _fallback(size),
      ),
    );
  }

  Widget _fallback(double size) => Container(
    color: const Color(0xFF121C2D),
    alignment: Alignment.center,
    child: const Icon(Icons.person_rounded, color: Colors.white54),
  );

  Widget _storyMedia(Map<String, dynamic> s) {
    final url = s['mediaUrl']?.toString() ?? '';
    if (url.isEmpty) return const SizedBox.shrink();
    if (s['mediaType'] == 'video') {
      return _StoryVideo(url: url);
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: AspectRatio(
        aspectRatio: 1.15,
        child: Image.network(url, fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(color: Colors.white10,
            child: const Icon(Icons.broken_image_rounded, color: Colors.white38))),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 18),
      decoration: BoxDecoration(
        color: const Color(0xFF0B1220).withOpacity(.94),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Colors.white.withOpacity(.08)),
        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 24, offset: Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 8),
            child: Row(children: [
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  gradient: const LinearGradient(colors: [Color(0xFF7C5CFC), Color(0xFF9B6DFF)]),
                ),
                child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              const Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('MOMENTS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 1.6)),
                  Text('Bagikan sesuatu ke semua user', style: TextStyle(color: Colors.white38, fontSize: 11)),
                ],
              )),
              if (_loading) const SizedBox(width: 16, height: 16,
                child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF9B8CFF))),
              IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded, color: Colors.white54)),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 12),
            child: Row(children: [
              Expanded(child: TextField(
                controller: _text,
                minLines: 1, maxLines: 3,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'Tulis story teks...',
                  hintStyle: const TextStyle(color: Colors.white30),
                  filled: true, fillColor: Colors.white.withOpacity(.055),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
              )),
              const SizedBox(width: 8),
              IconButton(onPressed: _posting ? null : () => _post(),
                icon: Icon(Icons.send_rounded,
                  color: _posting ? Colors.white24 : const Color(0xFF9B8CFF))),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 14),
            child: Row(children: [
              _postButton(Icons.photo_rounded, 'Foto', () => _pick(false)),
              const SizedBox(width: 8),
              _postButton(Icons.movie_rounded, 'Video', () => _pick(true)),
            ]),
          ),
          SizedBox(
            height: 112,
            child: _stories.isEmpty
                ? const Center(child: Text('Belum ada story. Jadilah yang pertama.',
                    style: TextStyle(color: Colors.white38, fontSize: 12)))
                : ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    scrollDirection: Axis.horizontal,
                    itemCount: _stories.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (_, i) {
                      final s = _stories[i];
                      return GestureDetector(
                        onTap: () => _openStory(s),
                        child: SizedBox(width: 72, child: Column(children: [
                          _avatar(s, size: 62),
                          const SizedBox(height: 6),
                          Text(s['username'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.white70, fontSize: 10)),
                        ])),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 4),
        ],
      ),
    );
  }

  Widget _postButton(IconData icon, String label, VoidCallback onTap) => Expanded(
    child: InkWell(
      onTap: _posting ? null : onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.045),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withOpacity(.07)),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: const Color(0xFF9B6DFF), size: 18),
          const SizedBox(width: 7),
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w700)),
        ]),
      ),
    ),
  );

  void _openStory(Map<String, dynamic> s) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF050A12),
      builder: (ctx) {
        return SafeArea(
          child: SizedBox(
            height: MediaQuery.of(ctx).size.height * .88,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  _avatar(s, size: 46), const SizedBox(width: 10),
                  Expanded(child: Text(s['username'] ?? '',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
                  IconButton(onPressed: () => Navigator.pop(ctx),
                    icon: const Icon(Icons.close, color: Colors.white54)),
                ]),
                const SizedBox(height: 12),
                if ((s['text'] ?? '').toString().isNotEmpty)
                  Padding(padding: const EdgeInsets.only(bottom: 12),
                    child: Text(s['text'], style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.45))),
                _storyMedia(s),
                const SizedBox(height: 10),
                Row(children: [
                  IconButton(onPressed: () { Navigator.pop(ctx); _like(s['id'].toString()); },
                    icon: Icon(
                      (s['likedByMe'] == true) ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                      color: const Color(0xFFFF5C8A))),
                  Text('${s['likesCount'] ?? 0}', style: const TextStyle(color: Colors.white70)),
                  const SizedBox(width: 10),
                  IconButton(onPressed: () { Navigator.pop(ctx); _comments(s); },
                    icon: const Icon(Icons.chat_bubble_outline_rounded, color: Color(0xFF9B6DFF))),
                  Text('${(s['comments'] as List?)?.length ?? 0}', style: const TextStyle(color: Colors.white70)),
                ]),
              ]),
            ),
          ),
        );
      },
    );
  }
}

class _StoryVideo extends StatefulWidget {
  final String url;
  const _StoryVideo({required this.url});
  @override
  State<_StoryVideo> createState() => _StoryVideoState();
}

class _StoryVideoState extends State<_StoryVideo> {
  late final VideoPlayerController _controller;
  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        if (mounted) setState(() {});
      });
  }
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (!_controller.value.isInitialized) {
      return const AspectRatio(aspectRatio: 1.15,
        child: Center(child: CircularProgressIndicator(color: Color(0xFF9B6DFF))));
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: AspectRatio(
        aspectRatio: _controller.value.aspectRatio == 0 ? 1 : _controller.value.aspectRatio,
        child: Stack(alignment: Alignment.center, children: [
          VideoPlayer(_controller),
          IconButton(
            onPressed: () {
              setState(() {
                _controller.value.isPlaying ? _controller.pause() : _controller.play();
              });
            },
            icon: Icon(_controller.value.isPlaying ? Icons.pause_circle_filled : Icons.play_circle_fill,
              color: Colors.white, size: 52),
          ),
        ]),
      ),
    );
  }
}
