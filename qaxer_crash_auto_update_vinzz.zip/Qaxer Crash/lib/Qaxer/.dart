class Api {
  static const String api = "http://felixiority.xyz:4780";
}