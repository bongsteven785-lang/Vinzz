# GitHub Auto Update Setup

This project now checks the latest public GitHub Release when the dashboard opens. If the release tag is newer than the installed app version, it displays an Update / Nanti dialog and opens the GitHub Release page when Update is tapped. Android installation still requires user approval.

## Required setup

1. Create a **public** GitHub repository and upload the project.
2. In `lib/update_service.dart`, The repository is preconfigured as `bongsteven785-lang/Vinzz`. Confirm that this exact public repository exists and contains your Flutter project before building.
3. Build and install the initial APK. The current project version is `10.0.0+10`.
4. For each release, increase both version name and build number in `pubspec.yaml`, e.g. `10.0.1+11`.
5. Create a GitHub Release with a tag matching the version, e.g. `v10.0.1`, and upload the release APK as an asset. The API checks the latest published, non-draft, non-prerelease release.
6. The release APK must be signed with the same keystore as the installed APK. **Do not use a newly generated signing key for every build.**

## Important signing note

`android/app/build.gradle.kts` currently signs release builds with the debug signing configuration. That is not suitable for reliable public updates from CI, because a cloud runner's debug key may change. Before distributing updates, create and back up a private release keystore, configure Gradle to use it, and store its credentials securely as GitHub Actions secrets. Never commit the keystore or passwords to a public repository.

## Behavior

The checker does not block the app if GitHub is unreachable. It only notifies the user and opens the release page; it does not silently install an APK.
